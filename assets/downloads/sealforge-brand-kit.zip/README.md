# SealForge brand kit

One identity for the application, the public site, documents and email. The
approved mark is a seal in profile: one flipper holds a key outside its body,
the other operates a small press on a document. The key and the press stay
petrol; only the separate thin line under the press and the impression on the
sheet are copper.

This is a brand package, not a product release. The application serves committed
`wwwroot` copies of the canonical `branding/assets/` files. It never generates a
logo at runtime and contains no mail sender.

## Contents

| Path | What it is |
| --- | --- |
| `assets/` | Horizontal, stacked and symbol SVGs; one-colour files; head crops; icon PNGs, `favicon.ico`, `app-icon.svg`, `social-card.png`, `email-logo.png`, `email-signature.html` |
| `raw/master.svg` | Canonical editable artwork — edit here first |
| `raw/head.svg` | Canonical head crop used for the tiny icons |
| `raw/body.svg`, `raw/copper.svg` | Editable ink layers with identical registration |
| `raw/geometry.json` | Master/head viewBoxes and reference provenance |
| `raw/palette.json` | Light, dark and semantic colour tokens |
| `raw/approved-reference.png` | Approved Round 8 raster reference, for comparison only |
| `raw/fonts/Inter.ttf` | Source font (variable Inter) |
| `raw/fonts/OFL.txt` | SIL Open Font License 1.1 text |
| `docs/brand-guidelines.html` | Nine-page A4 brand book, editable HTML |
| `docs/letterhead.html` | One-page A4 letterhead template |
| `docs/brand-guidelines.pdf`, `docs/letterhead.pdf` | Ready-to-use A4 documents |
| `docs/fonts/inter.woff2` | Web font used by the two HTML documents |
| `manifest.json` | SHA-256 for every file in the kit |
| `sealforge-brand-kit.zip` | Ready-to-use bundle of the same files |

The wordmark inside every lockup is Inter Medium artwork. It needs no font
installed to display or print.

## Choosing a file

| Use | File |
| --- | --- |
| Light page, document, website header | `assets/logo-on-light.svg` |
| Dark interface or charcoal surface | `assets/logo-on-dark.svg` |
| One-colour print, engraving, stamp | `assets/logo-black.svg` or `assets/logo-white.svg` |
| Narrow or centred placement | `assets/logo-stacked-*.svg` |
| Avatar, loader, short space | `assets/symbol-on-*.svg` |
| Compact interface, icon source | `assets/head-on-*.svg` |
| Browser tab | `assets/favicon.ico` |
| App tile / launcher | `assets/app-icon.svg`, `icon-192.png`, `icon-512.png` |
| Email signature | `assets/email-signature.html` with `assets/email-logo.png` |
| Social preview | `assets/social-card.png` (1200 × 630) |

Horizontal lockups are drawn at 330 × 88. White artwork is invisible on a
white canvas: preview it on the dark surface.

## Marks in use

- Clear space is one quarter of the symbol's height (`H/4`) on every side; for
  a lockup, measure `H` from the symbol. Never below 6 mm in print.
- Working floors: horizontal lockup 180 px / 48 mm wide, stacked 120 px / 32 mm,
  symbol 80 px / 22 mm, tiny icon 16 px. Inspect the actual export at 100%
  before publishing.
- Tiny icons retain the same face and contour, with a smooth neck closure and
  optical stroke compensation at 16/24 px. No separate character or props are added.
- Do not recolour the seal, key or press, add outlines or shadows, or place the
  colour lockup on a mid-tone photo.

## Colour

Light: background `#f7f8f5`, surface `#ffffff`, ink `#203033`, muted `#56666a`,
primary `#316b73`, hover `#28626a`, copper `#9f542e`, line `#d8e1de`, soft
`#ebf2ef`, onPrimary `#ffffff`, inputBorder `#7a8a8c`.

Dark: background `#151b1d`, surface `#1c2426`, ink `#eef5f3`, muted `#a7bcbb`,
primary `#87c2c6`, hover `#a6d5d6`, copper `#e5ad7d`, line `#33454a`, soft
`#243033`, onPrimary `#151b1d`, inputBorder `#7e8f94`.

Semantic fills are separate from the brand palette. Light: success `#236a45`,
error `#a42c37`, warning `#865111`, info `#2b638a`, with white labels. Dark:
success `#91d2aa`, error `#f29ca5`, warning `#e2bc74`, info `#9dc6e3`, with
charcoal `#151b1d` labels. Copper is never a warning or error colour.

Normal text is 4.5:1 or better on its surface; required control outlines use
`inputBorder` and pass 3:1. The decorative `line` token is below 3:1 and is not
a control boundary. Exact measured pairs are printed in the brand book.

## Documents

Open `docs/brand-guidelines.html` or `docs/letterhead.html` in a browser and
print to A4 with margins set to none and background graphics enabled. Both use
`docs/fonts/inter.woff2` locally and reference `../assets/`; there is no
external font, script or image request. The letterhead is one page with
bracketed placeholders and no invented contact details.

## Verifying a copy

`manifest.json` lists a SHA-256 for every file. Compare an entry with:

```bash
sha256sum path/to/file
```

If a hash differs, the file was edited. Re-export from `raw/master.svg` rather
than patching an export by hand.

## Editing and regeneration

`tools/branding/mark.py` in the private product repository is the developer-only
generator. It rebuilds the committed SVG, PNG and PDF exports and re-copies the
kit. It is not part of the application runtime.

```bash
python -m pip install -r tools/branding/requirements.txt
python tools/branding/mark.py
python tools/branding/test_branding.py
```

The archive's `raw/*.svg` files are editable. In the repository, the generator
reads `tools/branding/source/master.svg` and `head.svg`; copy an edited raw master
back there before regeneration. Palette constants live in `mark.py` and match
the app's `AppTheme.cs` / CSS; `raw/palette.json` is their exported data, not a
runtime configuration file. Keep the paper joint: the sheet's upper edge is level, meets both
stem rails and passes behind the hollow stem without crossing it. Keep the
copper line separate from the petrol press base.

## Font licence

Inter is licensed under the SIL Open Font License 1.1; the full text is
`raw/fonts/OFL.txt`. The font may be used and embedded in documents; follow the
included licence when redistributing it or derivatives.

## Limits

- Masters are self-contained vector paths, not embedded rasters. The approved
  reference PNG is supplied for comparison only.
- Contrast values cover the listed opaque token pairs, not a whole-application
  WCAG audit.
- No trademark clearance or similarity search is claimed.
- The product repository is private. SealForge is not presented as open source
  or as a public installer.
- The email signature is brand-only; it contains no personal identity and the
  product provides no mail sending.
