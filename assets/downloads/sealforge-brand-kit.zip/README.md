# SealForge brand kit

One approved identity for the application, product site, documents and email.
The seal is in natural profile: one flipper holds the key outside its body,
the other operates a small press on a document. The seal, key and press stay
petrol; only the separate thin line beneath the press and the document's
impression are copper.

This is an identity package, not a product release or installer. The application
serves committed `wwwroot` copies of the canonical `branding/assets/` files.
It never generates a logo at runtime and contains no mail sender.

## Contents

| Path | Purpose |
| --- | --- |
| `assets/` | Horizontal, stacked, symbol and head artwork; light/dark/black/white SVG, PNG and PDF; icons, ICO, social card and email signature |
| `raw/master.svg` | Canonical editable master drawing |
| `raw/head.svg` | The same character's head, used for compact icons |
| `raw/body.svg`, `raw/copper.svg` | Editable ink layers with identical registration |
| `raw/geometry.json` | Master/head viewBoxes and reference provenance |
| `raw/palette.json` | Light, dark and semantic colour tokens |
| `raw/approved-reference.png` | Approved raster reference, not the vector export source |
| `raw/fonts/Inter.ttf`, `raw/fonts/OFL.txt` | Source font and its redistribution text |
| `docs/brand-guidelines.html` | Editable nine-page A4 brand guide |
| `docs/letterhead.html` | Editable one-page A4 letterhead |
| `docs/brand-guidelines.pdf`, `docs/letterhead.pdf` | Ready-to-use documents |
| `docs/fonts/` | Local document font and its redistribution text |
| `manifest.json` | SHA-256 for every other file in this kit |
| `sealforge-brand-kit.zip` | The same files in a downloadable archive |

The complete corporate set additionally includes editable Word and PowerPoint
templates, business cards, social artwork, a personal email-signature template
and generation sources. On the product site, **complete set** downloads the
expanded identity; **artwork** downloads this canonical brand kit.

## Choosing a file

| Use | File |
| --- | --- |
| Full logo on a light document or editorial surface | `assets/logo-on-light.svg` |
| Full logo on a dark surface | `assets/logo-on-dark.svg` |
| Single-ink print or engraving | `assets/logo-black.svg`, `assets/logo-white.svg` |
| Narrow or centred composition | `assets/logo-stacked-*.svg` |
| The full character without lettering | `assets/symbol-on-*.svg` |
| Compact application or website header | `assets/head-on-light.svg`, `assets/head-on-dark.svg` |
| Browser tab | `assets/favicon.ico` |
| Application tile | `assets/app-icon.svg`, `icon-192.png`, `icon-512.png` |
| Brand email signature | `assets/email-signature.html`, `assets/email-logo.png` |
| Social preview | `assets/social-card.png` — 1200 × 630 |

The full horizontal logo is drawn at 330 × 88. Its Inter Medium lettering is
outlined; no font installation is needed to display or print that artwork.
Preview white artwork on a dark background, not a white canvas.

### Compact interface headers

Do not squeeze the full lockup into a small application header. Pair the same
supplied head with modest live **SealForge** text: approximately 18–20 px Inter
and a head around 32–40 px wide. Inspect the actual screen; never stretch the
SVG or replace the character. This is a UI layout, not permission to redraw the
outlined lettering inside the full logo. Do not repeat the mark inside the
login card when the public header already identifies the application.

## Use and minimum sizes

- Keep one quarter of the symbol's height clear on every side of a full logo.
  In print, never reduce that space below 6 mm.
- Working floors: full horizontal lockup 180 px / 48 mm; stacked 120 px / 32 mm;
  full symbol 80 px / 22 mm; tiny icon 16 px. A compact header uses the supplied
  head rather than shrinking the full lockup below these floors.
- Tiny icons preserve the same face and contour. Optical stroke compensation
  at 16/24 px does not create a different character or scene.
- Do not recolour the seal, key or press, add shadows/outlines/badges, or use
  copper as a warning or error colour.
- Inspect at the real use size. A 512 px preview is not evidence of a 16 px icon.

## Colour

Light: background `#f7f8f5`, surface `#ffffff`, ink `#203033`, muted `#56666a`,
primary `#316b73`, hover `#28626a`, copper `#9f542e`, decorative line `#d8e1de`,
soft `#ebf2ef`, onPrimary `#ffffff`, inputBorder `#7a8a8c`.

Dark: background `#151b1d`, surface `#1c2426`, ink `#eef5f3`, muted `#a7bcbb`,
primary `#87c2c6`, hover `#a6d5d6`, copper `#e5ad7d`, decorative line `#33454a`,
soft `#243033`, onPrimary `#151b1d`, inputBorder `#7e8f94`.

Semantic fills remain separate. Light: success `#236a45`, error `#a42c37`,
warning `#865111`, info `#2b638a`, with white labels. Dark: success `#91d2aa`,
error `#f29ca5`, warning `#e2bc74`, info `#9dc6e3`, with `#151b1d` labels.

Listed normal-text pairs meet 4.5:1; required control outlines meet 3:1.
The decorative `line` token is not a control boundary. Measurements are in
`assets/contrast.json`; this is not whole-application accessibility certification.

## Documents

The HTML documents use local `docs/fonts/inter.woff2` and `../assets/` files.
Print to A4 with zero margins and background graphics enabled, or use the
supplied PDFs. Bracketed fields are deliberate personalisation fields, not
invented contact information.

## Verification and regeneration

`manifest.json` lists file-content SHA-256 values:

```bash
sha256sum path/to/file
```

Edit `raw/master.svg`, not a raster export. In the product repository the
canonical inputs are `tools/branding/source/master.svg` and `head.svg`;
copy an edited raw master back there before regenerating:

```bash
python -m pip install -r tools/branding/requirements.txt
python tools/branding/mark.py
python tools/branding/test_branding.py
```

The generator is developer-only tooling. Palette constants live in `mark.py`;
`raw/palette.json` is their exported data, not runtime configuration. Preserve
the paper's continuous upper edge and its joins to both press rails; the paper
passes behind the hollow stem. The separate copper line stays centred beneath
the petrol press. Do not retouch generated variants independently.

## Font redistribution and limits

Inter's SIL Open Font License text is preserved in `raw/fonts/OFL.txt`.
Keep that text with redistributed font files or derivatives. This is not a
separate software-licensing claim for the product.

- Masters are self-contained vector paths, not embedded raster artwork.
- No trademark clearance, calibrated print proof or legal assurance is claimed.
- The product repository is access-restricted; this kit does not provide product
  source code or anonymous installer access.
- Email signatures are files, not a sending service. Real mail-client delivery
  and dark-mode transformations require separate testing.
