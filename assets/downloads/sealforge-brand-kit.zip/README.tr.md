# SealForge marka paketi

[English](README.md) · Türkçe

**SealForge = Seal + Forge.** Seal, hem fok hem kimliği ve bütünlüğü
belirten mühürdür. Forge, imzalama atölyesi ve özenli zanaat fikridir.
Seal'in altındaki **Cove**, korunaklı koy çağrışımı ve seçilen 11. tur
çiziminin iç adıdır; ürün adını değiştirmez.

Tek amblem profilden bir fok başıdır: tek düz kontur, hilal göz, üç bıyık
ve kapalı sakin gülümseme. Gövde, anahtar, pres, ikinci maskot veya ek nesne
yoktur. Geometri ve Coast & Copper paleti iki dilde aynıdır.

## Dil ve içerik

| Yol | İçerik |
| --- | --- |
| `docs/tr/brand-guidelines.html`, `.pdf` | Türkçe dokuz sayfalık A4 marka kılavuzu |
| `docs/tr/letterhead.html`, `.pdf` | Türkçe tek sayfalık A4 antet |
| `docs/tr/identity-story.md` | Türkçe isim açıklaması ve kaynak sınırları |
| `docs/brand-guidelines.*`, `docs/letterhead.*` | İngilizce karşılıkları |
| `assets/tr/` | Türkçe sosyal görsel ve e-posta imzası |
| `assets/` | Ortak logo/ikonlar ve İngilizce sosyal/e-posta dosyaları |
| `raw/` | Düzenlenebilir çizim kopyaları, palet, referans ve fontlar |
| `manifest.json` | Her dosyanın SHA-256 özeti |
| `sealforge-brand-kit.zip` | Her iki dili içeren marka paketi |

Site ve HTML belgeler tarayıcı dilini tercih eder; üstten English/Türkçe
seçilebilir. Açık `?lang=en` veya `?lang=tr` seçimi önceliklidir. Elle
seçim saklanır; depolama engelliyse gezinme bağlantılarında korunur.
Türkçe HTML ayrı dosyadır ve JavaScript olmadan da okunur.
PDF ve Office belgeleri dil değiştirmez; uygun dildeki dosyayı açın.
Yazdırırken HTML belge dilini `?lang=tr` ile sabitleyebilirsiniz.

## Doğru dosya

| Kullanım | Dosya |
| --- | --- |
| Açık zemin | `assets/logo-on-light.svg` |
| Koyu zemin | `assets/logo-on-dark.svg` |
| Tek renk baskı | `assets/logo-black.svg`, `assets/logo-white.svg` |
| Dar veya ortalanmış alan | `assets/logo-stacked-*.svg` |
| Yazısız amblem | `assets/symbol-on-*.svg` |
| Kompakt arayüz başlığı | `assets/head-on-*.svg` ve canlı SealForge yazısı |
| Yalnız yazı logosu | `assets/wordmark-on-*.svg` |
| Tarayıcı/uygulama | `assets/favicon.ico`, `app-icon.svg`, `icon-*.png` |
| Türkçe e-posta | `assets/tr/email-signature.html`, ortak `assets/email-logo.png` |
| Türkçe sosyal önizleme | `assets/tr/social-card.png` — 1200 × 630 |

Yatay logo 393 × 112, dikey logo 280 × 294, amblem 1024 × 1024,
yazı logosu 273 × 80, e-posta plakası 344 × 100'dür.
Logo harfleri kontura çevrilmiştir; görüntüleme ve baskıda font gerekmez.
Beyaz çizimi beyaz değil, koyu zeminde önizleyin.

## Temel kurallar

- Her yönde amblem yüksekliğinin dörtte biri kadar koruma alanı bırakın;
  baskıda 6 mm altına inmeyin.
- Alt sınırlar: yatay logo 180 px / 48 mm, dikey logo 120 px / 32 mm,
  amblem 80 px / 22 mm, küçük ikon 16 px.
- Küçük ikon aynı çizimdir; 16 ve 32 px PNG'yi %100 ölçekte kontrol edin.
- Amblemi yeniden çizmeyin, renklendirmeyin; gölge, dış çizgi, rozet,
  anahtar, pres, belge veya gövde eklemeyin.
- Petrol açık zeminde, nane koyu zeminde; bakır yalnız ayrı yerleşim
  vurgusudur. Bakır uyarı, hata veya bağlantı rengi değildir.
- **Manrope 600** marka ve başlıklarda; **Inter 400/600** arayüz, gövde,
  tablo ve açıklamalarda kullanılır. Manrope'u yapay kalınlaştırmayın.
- Fontları yeniden dağıtırken `OFL.txt` ve `OFL-Manrope.txt` lisanslarını
  koruyun. Kurumsal şablonların statik düzenleme fontları ayrı pakettedir.

Palet ve sayısal kontrast ölçümleri `assets/palette.json` ile
`assets/contrast.json` içindedir. Normal metin çiftleri en az 4,5:1,
gerekli kontrol sınırları en az 3:1 sağlar. Dekoratif çizgiler kontrol
sınırı değildir. Bu, tüm uygulama için erişilebilirlik sertifikası değildir.

## Düzenleme ve sınırlar

HTML'den A4, sıfır kenar boşluğu ve arka plan grafikleri açık biçimde
yazdırın veya hazır PDF'leri kullanın. Köşeli ayraçlı alanları gerçek
bilgilerle değiştirin; paket kimlik veya iletişim bilgisi uydurmaz.

Ana üretim kaynağı, ayrı özel marka deposundaki
`tools/branding/source/cove/master.svg` dosyasıdır. `raw/master.svg`
dağıtılan kopyadır; değişikliği üretim kaynağına aktarmadan yeniden
üretirseniz üzerine yazılır. Çeviri kaynakları `tools/branding/locales/tr/`
altındadır; üretilmiş Türkçe HTML yerine bunları düzenleyin.

Bu paket ürün kurucusu veya uygulama kaynağı değildir. Uygulama yalnız
depolanmış statik dosyaları sunar; logo üreticisi veya e-posta gönderici
çalıştırmaz. Ürün deposu özeldir. Marka tescili araştırması, tüm uygulama
WCAG sertifikası, donanım/imza doğrulaması, yerel Microsoft Office
görünümü veya CMYK/PDF-X baskı provası iddia edilmez.
