# SealForge — identity story and repository map

## Product name, design direction and palette

These names describe different things, not successive product names:

| Name | Role |
| --- | --- |
| **SealForge** | The product and public-facing brand name |
| **Cove** | The internal name of the selected Round 11 visual direction: one seal-head emblem |
| **Coast & Copper** | The earlier identity direction and the palette retained by Cove |

The product has not been renamed to Cove, CoveForge or Cove & Forge. Use
**SealForge** in product copy. Use **Cove** when identifying artwork sources,
design history or this particular visual direction.

## Why a seal and a forge?

### Seal — identity and integrity

**Seal** carries two connected meanings. A seal is a mark of identity and
integrity; it is also the English name of the animal in the emblem. The seal
head makes the animal recognisable, while the compact, single-ink composition
recalls a stamp or carved seal. Both meanings remain present in the current
head-only logo. A body, key or press is not required to preserve them.

#### Cove, within Seal

A cove is a small, sheltered coastal inlet. Within **Seal**, it adds a quiet
sense of custody to the animal's maritime setting. This is a supporting
association and the drawing's internal name, not another half of the product
name. The explanation always starts with **Seal + Forge**.

### Forge — craft

**Forge** means a workshop and deliberate craft. SealForge is a controlled
code-signing workshop: an authorised principal signs a software artefact with
an explicitly selected certificate, the private key stays in its token/HSM,
and the result is verified before download.

The visual identity expresses this position; it is not itself proof of
security, signing success or trademark clearance.

## What changed, and what did not?

The repository records these steps on 16 November 2026:

| Commit | Recorded change |
| --- | --- |
| `5ea59a7` | Adopted Coast & Copper in place of the previous hexagonal mark: a seal holding a key and operating a press on a document |
| `63bdead` | Refined the compact header treatment and added Office, print, social and email deliverables |
| `1928f99` | Adopted selection A / Cove from Round 11: one seal head, outlined Manrope wordmarks, refreshed templates and static app assets |

Cove changes the illustration, not the product name or the meaning of
SealForge. It removes the body, key, press and document from the emblem.
The same head is used for the standalone symbol, compact headers and icons;
there is no separate full-animal companion. The Coast & Copper palette is
retained, with copper used outside the emblem as a layout accent.
Manrope 600 carries the brand and headings; Inter carries interface and body text.

The earlier Cove guide placed **Cove — shelter** beside
**Forge — craft**, displacing the explanation of **Seal**. That mixed an
internal direction label with one half of the product name. The corrected
guide restores **Seal + Forge** and keeps Cove underneath Seal.
This is a narrative correction, not a new logo selection.

The commits, source metadata and approved reference record the delivered
artwork. They do not preserve every discussion from the design rounds or
establish why the owner preferred it over every alternative.

## Where the work lives

The branding work is kept in the private
[`sealforge-branding`](https://github.com/semihkiroglu/sealforge-branding)
repository. It is separate from the private SealForge application and the
public `sealforge-site` website:

| Path and repository | Responsibility |
| --- | --- |
| `tools/branding/source/cove/` | Production master, approved reference, geometry, palette and licensed source fonts |
| `tools/branding/cove.py`, `print_docs.cjs`, `package_corporate.py` | Developer-only artwork export, PDF printing and archive packaging |
| `branding-cove/` | Current distributable kit: exported artwork, editable source copies, this story, HTML/PDF guide, licences, manifest and ZIP |
| `corporate/` | Editable Word/PowerPoint, stationery, print/social/email assets and their generation sources |
| In **SealForge**: `src/SealForge.Web/wwwroot/brand/` | The static logo, icon and font subset served by the application; not moved here |
| In **SealForge**: `src/SealForge.Web/wwwroot/` | Application favicon, touch icon and other static entry-point copies; not moved here |
| In **SealForge**: `src/SealForge.Web/Components/Shared/BrandLogo.razor` | Theme-aware application placement of the supplied emblem and SealForge text; not moved here |
| `branding/`, `tools/branding/mark.py`, earlier source files | Retained historical Coast & Copper work, not the current export pipeline |

The separate `sealforge-site` website repository is a consumer of exported
assets and downloads, not the production artwork source. Updating this
repository does not by itself publish the website.

### Application and build boundary

The application serves committed assets; it does not run the branding
generators, print PDFs, generate logos or send the supplied email signature.
The brand kit and Office templates are not application code.

Before the separation, the artwork, templates and generators also entered the
application's Docker build context through `COPY . .`. They now live outside
that checkout and its build context. Application builds need only the committed
static runtime files, not this repository.

The initial import retains all 251 brand files from the application checkout,
including the narrative correction. The application Git history is not
rewritten. New artwork changes start here, and `cove.py --sync-app APP_ROOT`
copies only the static app subset into an explicit existing SealForge checkout.
It never commits, builds or deploys the application.

## Current references

- [Brand kit and file selection](../README.md)
- [Brand guidelines — editable HTML](brand-guidelines.html)
- [Brand guidelines — PDF](brand-guidelines.pdf)
- In this branding repository: `tools/branding/README.md`, `corporate/README.md`
  and `docs/github-pages.md`

Historical files may still call their own earlier artwork “approved”.
That records their former status; it does not make them the current identity.
