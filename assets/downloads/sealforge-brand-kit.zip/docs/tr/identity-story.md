# SealForge — isim, çizim ve kaynak sınırları

[English](../identity-story.md) · Türkçe

## Ürün adı

**SealForge**, ürünün ve dışa dönük markanın adıdır. **Cove**, seçilen
11. tur çiziminin iç adı; **Coast & Copper**, önceki çizim yönü ve korunan
paletin adıdır. Bunlar birbirini izleyen ürün adları değildir.
Ürünü Cove, CoveForge veya Cove & Forge olarak adlandırmayın.

## Seal + Forge

### Seal — kimlik ve bütünlük

İngilizcede **seal** hem fok hem mühür anlamına gelir. Mühür, sahibini
tanımlar ve bütünlüğü belirtir. Tek fok başı, hayvanı tanınır kılarken
kompakt ve tek renk yapısıyla damgayı çağrıştırır. İki anlamı korumak
için gövdeye, anahtara veya prese gerek yoktur.

#### Seal'in altında Cove

**Cove**, küçük ve korunaklı kıyı koyudur. Fokun denizle bağını sakin bir
muhafaza duygusuyla destekler. Yardımcı bir çağrışım ve çizimin iç adıdır;
ürün adının diğer yarısı değildir. Açıklama her zaman **Seal + Forge**
ile başlar.

### Forge — zanaat

**Forge**, atölye ve özenli üretim anlamını taşır. SealForge, kontrollü
bir kod imzalama atölyesidir: yetkili kimlik, açıkça seçilmiş sertifikayla
dosyayı imzalar; özel anahtar token/HSM içinde kalır ve çıktı indirilmeden
önce doğrulanır.

Görsel kimlik bu yaklaşımı anlatır; tek başına güvenlik, başarılı
imzalama veya marka tesciline uygunluk kanıtı değildir.

## Değişen ve korunan

Uygulama deposu geçmişinde 16 Kasım 2026 tarihli adımlar:

| Commit | Kayıtlı değişiklik |
| --- | --- |
| `5ea59a7` | Altıgen işaret yerine anahtar tutan ve belge üzerinde pres kullanan Coast & Copper foku |
| `63bdead` | Kompakt başlık ve Office, baskı, sosyal medya, e-posta çıktıları |
| `1928f99` | 11. tur A / Cove seçimi: tek fok başı, kontura çevrilmiş Manrope yazı logosu ve yenilenmiş çıktılar |

Yeni çizim ürün adını veya anlamını değil, illüstrasyonu değiştirir.
Gövde, anahtar, pres ve belge kaldırılır. Aynı baş; sembolde, kompakt
başlıkta ve ikonda kullanılır. Ayrı tam gövdeli eşlikçi yoktur.
Coast & Copper paleti korunur; bakır amblem dışında yerleşim vurgusudur.
Manrope 600 marka ve başlıkları, Inter arayüz ve gövdeyi taşır.

Önceki kılavuz iç çizim adını, ürün adının yarısıyla aynı düzeye koyuyordu.
Güncel anlatım **Seal + Forge** sırasını geri getirir ve Cove'u Seal'in
altında tutar. Bu, yeni logo seçimi değil, anlatım düzeltmesidir.
Kaynaklar onaylı çizimi kaydeder; tüm tasarım tartışmalarının veya her
alternatife ilişkin tercihin kaydı değildir.

## Çalışmanın yeri

Marka üretimi, uygulamadan ayrı özel
[`sealforge-branding`](https://github.com/semihkiroglu/sealforge-branding)
deposundadır. Herkese açık `sealforge-site` yalnız çıktı tüketicisidir.

| Yol / depo | Sorumluluk |
| --- | --- |
| `tools/branding/source/cove/` | Ana çizim, onay referansı, geometri, palet ve lisanslı fontlar |
| `tools/branding/cove.py`, `print_docs.cjs`, `package_corporate.py` | Geliştirici için çizim üretimi, PDF baskı ve paketleme |
| `tools/branding/locales/tr/` | Türkçe çeviri kaynakları |
| `branding-cove/` | Güncel çizimler, düzenlenebilir kopyalar, iki dilde HTML/PDF, lisanslar ve paket |
| `corporate/`, `corporate/tr/` | İngilizce/Türkçe Word, PowerPoint, baskı, sosyal medya ve e-posta |
| SealForge: `src/SealForge.Web/wwwroot/` | Uygulamanın kullandığı statik logo, ikon ve fontlar |
| SealForge: `Components/Shared/BrandLogo.razor` | Uygulamanın temaya duyarlı logo yerleşimi |
| `branding/`, `tools/branding/mark.py` | Saklanan tarihsel çalışmalar; güncel üretim hattı değil |

Marka deposunun değişmesi siteyi kendiliğinden yayımlamaz. Site
deposuna çıktılar ayrıca kopyalanıp yayımlanır. Özel kaynak deposu,
bilerek yayımlanmış herkese açık indirmeleri gizlemez.

Uygulama marka üreticilerini veya PDF baskısını çalıştırmaz; e-posta
imzası göndermez. Çalışma zamanında yalnız kaydedilmiş statik dosyaları
sunar. Marka kaynakları uygulamanın Docker derleme bağlamında değildir.

İlk marka aktarımı 251 dosyayı korumuş, uygulamanın Git geçmişini
yeniden yazmamıştır. `cove.py --sync-app APP_ROOT` yalnız açıkça verilen
uygulama kopyasına statik alt kümeyi kopyalar; commit, build veya deploy
yapmaz. Bu dil/anlatım çalışması uygulamanın dosyalarını değiştirmez.

## Başvuru

- [Türkçe marka paketi](../../README.tr.md)
- [Türkçe kılavuz — HTML](brand-guidelines.html?lang=tr)
- [Türkçe kılavuz — PDF](brand-guidelines.pdf)
- İngilizce kaynak kılavuzlar: `tools/branding/README.md`,
  `corporate/README.md`, `docs/github-pages.md`

Tarihsel dosyalardaki “onaylı” ifadesi o dönemi kaydeder;
eski çizimi güncel kimlik yapmaz.
