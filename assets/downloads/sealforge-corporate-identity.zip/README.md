# SealForge corporate identity

The approved profile seal, ready-to-use assets and editable sources in one set.
This is an identity package, not the product installer or application source code.

## Start here

- `branding/README.md`: variants, colours, compact headers and file selection.
- `branding/docs/brand-guidelines.pdf`: the nine-page brand guide.
- `branding/docs/letterhead.pdf`: A4 stationery; editable HTML is alongside it.
- `corporate/office/`: editable Word letterhead/report and PowerPoint presentation.
- `corporate/print/`: business-card SVG sources and print PDFs.
- `corporate/digital/`: avatar, cover, post and personal email-signature template.
- `corporate/digital/product/`: current component-preview PNG/WebP files and capture provenance.
- `corporate/README.md`: template usage and actual verification limits.
- `corporate/source/`: reproducible template generation and dependencies.
- `tools/branding/`: canonical artwork export and identity packaging tools.

Full artwork belongs in documents and editorial applications. Compact application
and website headers use the same head with modest live SealForge text. They do not
repeat it inside the login card or modify the full outlined logo artwork.

## Editing

The master is `branding/raw/master.svg`; the same head is `branding/raw/head.svg`.
Full logo lettering is outlined. To edit native Office files and live SVG text
consistently, install `branding/raw/fonts/Inter.ttf`. Keep its supplied OFL text
when redistributing font files.

Bracketed and double-braced fields are deliberate personalisation fields, not
real identities or contact details. Fill them before sending documents to others.
Business cards are RGB designs, not a calibrated CMYK, PDF/X or press-proof claim.

## Regeneration

These tools run only on a developer machine, never in the application runtime.

```bash
python -m pip install -r tools/branding/requirements.txt
# Document PDFs also require Node, Playwright and Chromium.
python tools/branding/mark.py
# Follow corporate/source/ instructions for the additional template dependencies.
python tools/branding/package_corporate.py --help
```

## Integrity and limits

The root `manifest.json` hashes every other file in this archive.
`branding/manifest.json` describes only the canonical artwork subtree.
Archives do not contain redundant ZIP-inside-ZIP bundles.

Native Office package validation is different from rendering in an Office
application. The actual checks and limitations are documented in
`corporate/README.md`. No real customer, sales or production-activity claim is made.
