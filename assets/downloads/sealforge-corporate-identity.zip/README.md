# SealForge corporate identity

The owner-selected Cove emblem, production vector exports, native templates and
editable sources. One seal-head symbol throughout; no full-animal companion.
This is an identity package, not a product installer or application source.

SealForge remains the product name. Cove is the internal name of the selected
visual direction. Within Seal, its sheltered-coast association supports the
animal and stamp meanings; Forge describes the signing workshop.

English files keep their existing paths. Turkish copies are under the matching
tr/ directories; logos and icons are shared. See README.tr.md for Turkish.

## Start here

- `branding-cove/docs/identity-story.md`: name, Cove transition and repository map.
- `branding-cove/README.md`: artwork selection, colours, typography and limits.
- `branding-cove/docs/brand-guidelines.pdf`: the nine-page brand guide.
- `branding-cove/docs/letterhead.pdf`: A4 stationery; editable HTML is alongside it.
- `corporate/office/`: editable Word letterhead/report and widescreen PowerPoint.
- `corporate/print/`: business-card SVG sources and RGB print PDFs.
- `corporate/digital/`: social assets and email signatures. UI captures are deferred.
- `corporate/README.md`: usage and actual Office/print verification limits.
- `corporate/source/`: reproducible template generation sources.
- `tools/branding/cove.py`: canonical artwork exporter, for developer use only.

## Typography and editing

Manrope SemiBold 600 carries the brand wordmark and display voice. Inter carries
long text and the application UI. Font files and both OFL notices are supplied in
`branding-cove/raw/fonts/`. Exported logo lettering is outlined, so SVG/PNG/PDF
consumers do not require fonts. Editable native text does.

`branding-cove/raw/master.svg` is the single traced Cove master; `raw/head.svg`
contains the same geometry for compact consumers. It was traced from the owner's
approved Round 11 drawing, not a stock-logo trace. No trademark-clearance claim.

Bracketed and double-braced fields are deliberate personalisation fields, not
real people or contact details. Fill them before sending a document.
Business cards are RGB: no calibrated CMYK, PDF/X or commercial press-proof claim.

## Regeneration

These tools run only on a developer machine, never in the application runtime.

```bash
python -m pip install -r tools/branding/requirements.txt
python tools/branding/cove.py
# Follow corporate/source/ for additional native-document dependencies.
python tools/branding/package_corporate.py --help
```

Document PDFs additionally require Node, Playwright and Chromium. The root
`manifest.json` hashes every other file in this archive; the brand manifest covers
only `branding-cove/`. There are no nested ZIP bundles. A valid OOXML package is
not proof of native Microsoft Office rendering; consult `corporate/README.md`.
