# SealForge brand kit — Cove

One approved identity for the application, product site, documents and email.
**Cove** is a single compact emblem: a seal head in profile, drawn as one flat
contour with a crescent eye, three whisker strokes and a closed smile. It has no
body, no tools and no second object. Earlier prop-based and full-animal drawings
are superseded.

The identity is selection A of approval round 11. The palette is unchanged from
the previous kit; the typography contract is **Manrope 600** for the brand,
wordmark and headings, and **Inter** for interface, body and long text.

This is an identity package, not a product release or installer. The application
serves committed `wwwroot` copies of the canonical files; it never generates a
logo at runtime and contains no mail sender.

## Contents

| Path | Purpose |
| --- | --- |
| `assets/` | Horizontal, stacked, emblem and head artwork; light/dark/black/white SVG, PNG and PDF; icons, ICO, social card and email assets |
| `raw/master.svg` | Editable copy of the canonical traced source drawing |
| `raw/head.svg` | The same emblem geometry, used by the compact interface mark and the icons |
| `raw/geometry.json` | Identity Cove, selection A, approval round 11, viewBoxes and reference hashes |
| `raw/palette.json` | Light, dark and semantic colour tokens, plus the typography contract |
| `raw/approved-reference.png` | Approved raster reference, not the vector export source |
| `raw/fonts/Manrope.ttf`, `raw/fonts/OFL-Manrope.txt` | Source font for the outlined wordmark and its redistribution text |
| `raw/fonts/Inter.ttf`, `raw/fonts/OFL.txt` | Source body font and its redistribution text |
| `docs/brand-guidelines.html` | Editable nine-page A4 brand guide |
| `docs/letterhead.html` | Editable one-page A4 letterhead |
| `docs/brand-guidelines.pdf`, `docs/letterhead.pdf` | Ready-to-use documents |
| `docs/fonts/` | Local `manrope.woff2` / `inter.woff2` for rendering, with both OFL texts |
| `manifest.json` | SHA-256 for every other file in this kit |
| `sealforge-brand-kit.zip` | The same files in a downloadable archive (written by a full generator run) |

The complete corporate set lives in the product repository under
`corporate/`: editable Word and PowerPoint templates, business cards, social
artwork, a personal email-signature template and generation sources.

## Choosing a file

| Use | File |
| --- | --- |
| Full logo on a light document or editorial surface | `assets/logo-on-light.svg` |
| Full logo on a dark surface | `assets/logo-on-dark.svg` |
| Single-ink print or engraving | `assets/logo-black.svg`, `assets/logo-white.svg` |
| Narrow or centred composition | `assets/logo-stacked-*.svg` |
| The emblem without lettering | `assets/symbol-on-*.svg` |
| Compact application or website header | `assets/head-on-light.svg`, `assets/head-on-dark.svg` |
| Wordmark only | `assets/wordmark-on-*.svg` |
| Browser tab | `assets/favicon.ico` |
| Application tile | `assets/app-icon.svg`, `icon-192.png`, `icon-512.png` |
| Brand email signature | `assets/email-signature.html`, `assets/email-logo.png` |
| Social preview | `assets/social-card.png` — 1200 × 630 |

Sizes: horizontal lockup 393 × 112, stacked 280 × 294, emblem and head
1024 × 1024, wordmark 273 × 80, email plate 344 × 100. The wordmark lettering is
outlined Manrope 600, so no font installation is needed to display or print that
artwork. Preview white artwork on a dark background, not a white canvas.

### Compact interface headers

Do not squeeze the full lockup into a small application header. Pair the supplied
head with modest live **SealForge** text: the application uses a 32 px emblem box,
19 px Manrope 600 text and a 0.55 rem gap, switching artwork with the
`html[data-theme-mode]` attribute. Inspect the actual screen; never stretch the
SVG or replace the emblem. This is a UI layout, not permission to redraw the
outlined lettering inside the full logo. When a header already identifies the
application, do not repeat the emblem inside a login card.

## Use and minimum sizes

- Keep one quarter of the emblem's height clear on every side of a lockup. In
  print, never reduce that space below 6 mm.
- Working floors: horizontal lockup 180 px / 48 mm; stacked 120 px / 32 mm;
  emblem 80 px / 22 mm; tiny icon 16 px. Use the supplied head rather than
  shrinking the full lockup below these floors.
- Tiny icons are the same emblem at every size. Nothing is added or redrawn at
  16/24 px. Inspect the exported PNG at 100%; a 512 px preview is not evidence of
  a 16 px icon.
- Do not recolour the emblem, add a key/press/document/body back into it, add
  shadows, outlines or badges, or use copper as a warning or error colour.

## Colour

Light: background `#f7f8f5`, surface `#ffffff`, ink `#203033`, muted `#56666a`,
primary `#316b73`, hover `#28626a`, copper `#9f542e`, decorative line `#d8e1de`,
soft `#ebf2ef`, onPrimary `#ffffff`, inputBorder `#7a8a8c`.

Dark: background `#151b1d`, surface `#1c2426`, ink `#eef5f3`, muted `#a7bcbb`,
primary `#87c2c6`, hover `#a6d5d6`, copper `#e5ad7d`, decorative line `#33454a`,
soft `#243033`, onPrimary `#151b1d`, inputBorder `#7e8f94`.

Semantic fills remain separate. Light: success `#236a45`, error `#a42c37`,
warning `#865111`, info `#2b638a`, with white labels. Dark: success `#91d2aa`,
error `#f29ca5`, warning `#e2bc74`, info `#9dc6e3`, with `#151b1d` labels.

Listed normal-text pairs meet 4.5:1; required control outlines meet 3:1. The
decorative `line` token is not a control boundary. Measurements are in
`assets/contrast.json`; this is not whole-application accessibility certification.

## Typography

- **Manrope 600** — wordmark (outlined), brand/document headings, display statements and live
  brand text. Never set it in synthetic bold and never use it for body copy.
- **Inter 400 / 600** — interface text, body copy, captions, tables and code
  labels. Body measure stays at 150 mm or less in A4 documents.

Both families are used under the SIL Open Font License 1.1; the licence texts
ship in `raw/fonts/` and `docs/fonts/`. The outlined letters inside the logo are
part of the artwork, so the logo needs no installed font. The corporate templates
ship static Manrope SemiBold/Inter faces so office applications do not synthesise
a weight; see `corporate/README.md`.

## Documents

The HTML documents use local `docs/fonts/manrope.woff2` and `inter.woff2` plus
`../assets/` artwork. Print to A4 with zero margins and background graphics
enabled, or use the supplied PDFs. Bracketed fields are deliberate
personalisation fields, not invented contact information.

## Verification and regeneration

`manifest.json` lists file-content SHA-256 values:

```bash
sha256sum path/to/file
```

The kit is generated from the traced master by the developer-only tool; it never
runs in the application:

```bash
python -m pip install -r tools/branding/requirements.txt
python tools/branding/cove.py --assets-only   # artwork and font inputs only
python tools/branding/cove.py                 # full kit: documents, manifest, ZIP
```

A full run reprints `docs/brand-guidelines.pdf` and `docs/letterhead.pdf` from
the committed HTML through `tools/branding/print_docs.cjs`, then rewrites
`manifest.json` and `sealforge-brand-kit.zip`. The editable production input is
`tools/branding/source/cove/master.svg`; `raw/master.svg` is its shipped editable
copy. If you edit that copy, transfer the change to the production input before
regenerating, otherwise it will be overwritten. Re-check the actual tiny exports
after any artwork change. Generation code is in the complete/editable-source
download, not the artwork-only ZIP.

## Limitations

- The master is real vector artwork: one organic trace of the approved reference,
  with no embedded raster image.
- Minimum sizes are working floors taken from the exports, not a measured
  legibility study.
- Contrast values cover the listed opaque token pairs, not the whole application.
- No trademark clearance or similarity search is claimed; that remains the
  owner's call.
- The product repository is private. Do not describe SealForge as open source or
  as a public installer.
