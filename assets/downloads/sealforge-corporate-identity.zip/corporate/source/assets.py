"""Print, social and email assets derived from the approved brand files."""
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont
from pypdf import PdfReader, PdfWriter
from pypdf.generic import RectangleObject

from brand import Brand

MM = 25.4 / 72.0  # points -> millimetres for SVG user units


def _pt(mm_value: float) -> float:
    return round(mm_value, 3)


def _svg_shell(body: str) -> str:
    return (
        '<svg xmlns="http://www.w3.org/2000/svg" width="91mm" height="61mm" '
        'viewBox="0 0 91 61">' + body + "</svg>"
    )


def _card_front(brand: Brand, guides: bool) -> str:
    light = lambda k: brand.c("light", k)
    parts = [
        f'<rect width="91" height="61" fill="{light("background")}"/>',
        brand.nested_svg("assets/logo-stacked-on-light.svg", (91 - 36) / 2, 11, 36, 36 * 224 / 260),
        f'<text x="45.5" y="50.6" text-anchor="middle" font-family="Inter, Arial, sans-serif" '
        f'font-size="2.54" fill="{light("muted")}">Self-hosted code signing.</text>',
    ]
    if guides:
        parts.append(_guides())
    return _svg_shell("".join(parts))


def _card_back(brand: Brand, guides: bool) -> str:
    dark = lambda k: brand.c("dark", k)
    contact = dark("ink")
    label = dark("primary")
    parts = [
        f'<rect width="91" height="61" fill="{dark("background")}"/>',
        brand.nested_svg("assets/logo-on-dark.svg", 8, 8, 48, 48 * 88 / 330),
        f'<text x="8" y="31" font-family="Inter, Arial, sans-serif" '
        f'font-size="3.70" font-weight="600" fill="{dark("ink")}">{{{{name}}}}</text>',
        f'<text x="8" y="35.8" font-family="Inter, Arial, sans-serif" '
        f'font-size="2.54" fill="{dark("muted")}">{{{{role}}}}</text>',
        f'<line x1="8" y1="38.8" x2="40" y2="38.8" stroke="{dark("line")}" '
        f'stroke-width="0.3"/>',
    ]
    lines = [
        ("E", "{{email}}", 44),
        ("T", "{{phone}}", 48),
        ("W", "{{website}}", 52),
    ]
    for tag, value, y in lines:
        parts.append(
            f'<text x="8" y="{y}" font-family="Inter, Arial, sans-serif" '
            f'font-size="2.47" fill="{contact}"><tspan fill="{label}" '
            f'font-weight="600">{tag}</tspan>  {value}</text>'
        )

    if guides:
        parts.append(_guides())
    return _svg_shell("".join(parts))


def _guides() -> str:
    return (
        '<g id="guides" fill="none">'
        '<rect x="0" y="0" width="91" height="61" stroke="#00a0ff" stroke-width="0.18" '
        'stroke-dasharray="0.8 0.6"/>'
        '<rect x="3" y="3" width="85" height="55" stroke="#ff00ff" stroke-width="0.25" '
        'stroke-dasharray="1.2 0.8"/>'
        '<rect x="6" y="6" width="79" height="49" stroke="#00a0ff" stroke-width="0.2" '
        'stroke-dasharray="0.8 0.6"/>'
        '<text x="3.2" y="2.35" font-family="Inter, Arial, sans-serif" font-size="1.5" '
        'fill="#ff00ff">TRIM 85×55 · BLEED 3 mm</text>'
        '<text x="6.3" y="5.35" font-family="Inter, Arial, sans-serif" font-size="1.4" '
        'fill="#00a0ff">SAFE 79×49</text>'
        "</g>"
    )


def _run(cmd: list[str]):
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(f"command failed: {' '.join(cmd)}\n{result.stderr}")
    return result


def build_business_card(brand: Brand, out_dir: Path):
    out_dir.mkdir(parents=True, exist_ok=True)
    front = out_dir / "business-card-front.svg"
    back = out_dir / "business-card-back.svg"
    front_g = out_dir / "business-card-front-guides.svg"
    back_g = out_dir / "business-card-back-guides.svg"
    front.write_text(_card_front(brand, False), "utf-8")
    back.write_text(_card_back(brand, False), "utf-8")
    front_g.write_text(_card_front(brand, True), "utf-8")
    back_g.write_text(_card_back(brand, True), "utf-8")

    # Two clean pages at trim+bleed size; no crop marks or guide layer.
    tmp = out_dir / ".build"
    tmp.mkdir(exist_ok=True)
    _run(["rsvg-convert", "-f", "pdf", "-o", str(tmp / "front.pdf"), str(front)])
    _run(["rsvg-convert", "-f", "pdf", "-o", str(tmp / "back.pdf"), str(back)])
    writer = PdfWriter()
    for pdf in (tmp / "front.pdf", tmp / "back.pdf"):
        reader = PdfReader(str(pdf))
        writer.add_page(reader.pages[0])
        page = writer.pages[-1]
        page.trimbox = RectangleObject([v * 72 / 25.4 for v in (3, 3, 88, 58)])
        page.bleedbox = RectangleObject(page.mediabox)
    writer.add_metadata({
        "/Title": "SealForge business card 85 × 55 mm (RGB, 3 mm bleed)",
        "/Author": "SealForge",
        "/Subject": "Editable template; replace {{name}}, {{role}}, {{email}}, "
                    "{{phone}}, {{website}} before printing.",
        "/Creator": "SealForge corporate identity extension",
        "/CreationDate": "D:20261116090000+00'00'",
        "/ModDate": "D:20261116090000+00'00'",
    })
    pdf_path = out_dir / "business-card-85x55-RGB.pdf"
    with pdf_path.open("wb") as fh:
        writer.write(fh)
    shutil.rmtree(tmp, ignore_errors=True)
    return [front, back, front_g, back_g, pdf_path]


def _pil_font(brand: Brand, size: int, weight: str):
    font = ImageFont.truetype(str(brand.path("raw/fonts/Inter.ttf")), size)
    font.set_variation_by_name(weight)
    return font


def _flatten_square(brand: Brand, rel: str, size: int, bg: str) -> Image.Image:
    art = Image.open(brand.path(rel)).convert("RGBA")
    art = art.resize((size, size), Image.LANCZOS)
    canvas = Image.new("RGBA", (size, size), bg)
    canvas.alpha_composite(art)
    return canvas.convert("RGB")


def build_social(brand: Brand, out_dir: Path):
    out_dir.mkdir(parents=True, exist_ok=True)
    dark = lambda k: brand.c("dark", k)

    avatar = _flatten_square(brand, "assets/icon-1024.png", 400, dark("background"))
    avatar_path = out_dir / "avatar-400.png"
    avatar.save(avatar_path, "PNG", optimize=True)

    post_path = out_dir / "post-1200x630.png"
    shutil.copyfile(brand.path("assets/social-card.png"), post_path)

    # Cover: solid brand field, approved logo and symbol placed at fixed sizes.
    cover = Image.new("RGB", (1500, 500), dark("background"))
    draw = ImageDraw.Draw(cover)
    logo = Image.open(brand.path("assets/logo-on-dark.png")).convert("RGBA")
    logo = logo.resize((430, round(430 * logo.height / logo.width)), Image.LANCZOS)
    cover.paste(logo, (90, 88), logo)
    symbol = Image.open(brand.path("assets/symbol-on-dark.png")).convert("RGBA")
    sh = 340
    symbol = symbol.resize((round(sh * symbol.width / symbol.height), sh), Image.LANCZOS)
    cover.paste(symbol, (1500 - symbol.width - 70, 78), symbol)
    draw.rectangle((90, 360, 180, 363), fill=dark("primary"))
    draw.text((90, 250), "Your signing workshop.", font=_pil_font(brand, 54, "SemiBold"),
              fill=dark("ink"), anchor="ls")
    draw.text((90, 326), "Self-hosted code signing.", font=_pil_font(brand, 24, "Regular"),
              fill=dark("muted"), anchor="ls")
    cover_path = out_dir / "cover-1500x500.png"
    cover.save(cover_path, "PNG", optimize=True)
    return [avatar_path, cover_path, post_path]


def build_email(brand: Brand, out_dir: Path):
    out_dir.mkdir(parents=True, exist_ok=True)
    light = lambda k: brand.c("light", k)
    html = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>SealForge email signature template</title></head>
<body>
<!-- Template: replace {{{{name}}}}, {{{{role}}}}, {{{{contact}}}} and {{{{logo_url}}}}.
     No address, phone, registration or social profile is supplied by the brand kit. -->
<table role="presentation" cellpadding="0" cellspacing="0" border="0"
       style="border-collapse:collapse;font-family:Inter,'Segoe UI',Arial,Helvetica,sans-serif;
              color:{light('ink')};background:{light('surface')};width:520px;max-width:520px">
  <tr><td style="padding:0 0 12px 0">
    <img src="{{{{logo_url}}}}" width="220" height="60" alt="SealForge"
         style="display:block;border:0;outline:none;width:220px;height:60px">
  </td></tr>
  <tr><td style="border-top:2px solid {light('primary')};padding:12px 0 0 0">
    <div style="font-size:16px;line-height:22px;font-weight:600;color:{light('ink')}">{{{{name}}}}</div>
    <div style="font-size:13px;line-height:20px;color:{light('muted')}">{{{{role}}}}</div>
    <div style="font-size:13px;line-height:20px;color:{light('ink')};padding-top:7px">
      {{{{contact}}}}
    </div>
    <div style="font-size:12px;line-height:18px;color:{light('muted')};padding-top:12px">
      Self-hosted code signing.<br>Your keys. Your signature. Your signing workshop.
    </div>
  </td></tr>
</table>
</body></html>
"""
    html_path = out_dir / "sealforge-email-signature.html"
    html_path.write_text(html, "utf-8")
    txt = """{{name}}
{{role}}
{{contact}}

SealForge — Self-hosted code signing.
Your keys. Your signature. Your signing workshop.
"""
    txt_path = out_dir / "sealforge-email-signature.txt"
    txt_path.write_text(txt, "utf-8")
    logo_path = out_dir / "email-logo.png"
    shutil.copyfile(brand.path("assets/email-logo.png"), logo_path)
    return [html_path, txt_path, logo_path]
