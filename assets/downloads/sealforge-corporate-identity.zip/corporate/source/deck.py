"""Editable native 16:9 PowerPoint template with seven useful layouts."""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

from lxml import etree
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, MSO_AUTO_SIZE, PP_ALIGN
from pptx.opc.constants import RELATIONSHIP_TYPE as RT
from pptx.oxml.ns import qn
from pptx.util import Inches, Pt

from brand import Brand

FONT = "Inter"
A_NS = "http://schemas.openxmlformats.org/drawingml/2006/main"
SLIDE_W, SLIDE_H = 13.333, 7.5


def _rgb(hex_value: str) -> RGBColor:
    return RGBColor.from_string(hex_value.lstrip("#").upper())


def _set_font(run, size, color, bold=False, italic=False):
    run.font.name = FONT
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.italic = italic
    run.font.color.rgb = _rgb(color)


def _text(slide, x, y, w, h, text, size, color, bold=False, italic=False,
          align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP, line=1.0,
          margins=(0, 0, 0, 0)):
    box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = box.text_frame
    tf.clear()
    tf.word_wrap = True
    tf.auto_size = MSO_AUTO_SIZE.NONE
    tf.vertical_anchor = anchor
    tf.margin_left, tf.margin_right = Inches(margins[0]), Inches(margins[1])
    tf.margin_top, tf.margin_bottom = Inches(margins[2]), Inches(margins[3])
    p = tf.paragraphs[0]
    p.alignment = align
    p.line_spacing = line
    p.space_after = Pt(0)
    run = p.add_run()
    run.text = text
    _set_font(run, size, color, bold, italic)
    return box


def _text_blocks(slide, x, y, w, h, blocks, anchor=MSO_ANCHOR.TOP,
                 margins=(0, 0, 0, 0), line=1.0):
    """blocks: [(text, size, color, bold, space_after_pt, align)]"""
    box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = box.text_frame
    tf.clear()
    tf.word_wrap = True
    tf.auto_size = MSO_AUTO_SIZE.NONE
    tf.vertical_anchor = anchor
    tf.margin_left, tf.margin_right = Inches(margins[0]), Inches(margins[1])
    tf.margin_top, tf.margin_bottom = Inches(margins[2]), Inches(margins[3])
    for i, (text, size, color, bold, after, align) in enumerate(blocks):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = align
        p.line_spacing = line
        p.space_after = Pt(after)
        run = p.add_run()
        run.text = text
        _set_font(run, size, color, bold)
    return box


def _bullets(slide, x, y, w, h, items, size, color, bullet_color,
             space_after=9, line=1.05):
    box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = box.text_frame
    tf.clear()
    tf.word_wrap = True
    tf.auto_size = MSO_AUTO_SIZE.NONE
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    for i, item in enumerate(items):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.line_spacing = line
        p.space_after = Pt(space_after)
        ppr = p._p.get_or_add_pPr()
        ppr.set("marL", str(int(Inches(0.28))))
        ppr.set("indent", str(int(-Inches(0.22))))
        bu_clr = etree.SubElement(ppr, qn("a:buClr"))
        srgb = etree.SubElement(bu_clr, qn("a:srgbClr"))
        srgb.set("val", bullet_color.lstrip("#").upper())
        bu_font = etree.SubElement(ppr, qn("a:buFont"))
        bu_font.set("typeface", "Arial")
        bu_char = etree.SubElement(ppr, qn("a:buChar"))
        bu_char.set("char", "•")
        run = p.add_run()
        run.text = item
        _set_font(run, size, color)
    return box


def _no_style(shape):
    """Drop the theme shape style so no inherited effect/shadow leaks through."""
    style = shape._element.find(qn("p:style"))
    if style is not None:
        shape._element.remove(style)


def _rule(slide, x, y, w, color, thickness=0.014):
    shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(x), Inches(y),
                                   Inches(w), Inches(thickness))
    shape.fill.solid()
    shape.fill.fore_color.rgb = _rgb(color)
    shape.line.fill.background()
    shape.shadow.inherit = False
    _no_style(shape)
    return shape


def _card(slide, x, y, w, h, fill, border, blocks, padding=0.24,
          anchor=MSO_ANCHOR.TOP, line=1.05):
    shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x),
                                   Inches(y), Inches(w), Inches(h))
    shape.adjustments[0] = 0.055
    shape.fill.solid()
    shape.fill.fore_color.rgb = _rgb(fill)
    shape.line.color.rgb = _rgb(border)
    shape.line.width = Pt(0.75)
    shape.shadow.inherit = False
    _no_style(shape)
    tf = shape.text_frame
    tf.clear()
    tf.word_wrap = True
    tf.auto_size = MSO_AUTO_SIZE.NONE
    tf.vertical_anchor = anchor
    tf.margin_left = tf.margin_right = Inches(padding)
    tf.margin_top = tf.margin_bottom = Inches(padding * 0.85)
    for i, (text, size, color, bold, after, align) in enumerate(blocks):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = align
        p.line_spacing = line
        p.space_after = Pt(after)
        run = p.add_run()
        run.text = text
        _set_font(run, size, color, bold)
    return shape


def _logo(slide, brand: Brand, rel: str, x: float, y: float, w: float):
    return slide.shapes.add_picture(str(brand.path(rel)), Inches(x), Inches(y),
                                    width=Inches(w))


def _slide_number(slide, index: int, color: str):
    box = slide.shapes.add_textbox(Inches(12.25), Inches(7.02), Inches(0.5),
                                   Inches(0.22))
    tf = box.text_frame
    tf.clear()
    tf.word_wrap = False
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.RIGHT
    fld = etree.SubElement(p._p, qn("a:fld"))
    fld.set("id", "{5B7F3E2A-4C19-4D8E-9B21-7A6C0D4E8F10}")
    fld.set("type", "slidenum")
    rpr = etree.SubElement(fld, qn("a:rPr"))
    rpr.set("lang", "en-GB")
    rpr.set("sz", "800")
    fill = etree.SubElement(rpr, qn("a:solidFill"))
    srgb = etree.SubElement(fill, qn("a:srgbClr"))
    srgb.set("val", color.lstrip("#").upper())
    t = etree.SubElement(fld, qn("a:t"))
    t.text = str(index)


def _footer(slide, index: int, light: dict):
    _rule(slide, 0.6, 6.96, 12.13, light["line"], 0.012)
    _text(slide, 0.6, 7.0, 3.0, 0.22, "SealForge", 7.5, light["muted"])
    _text(slide, 10.7, 7.0, 1.3, 0.22, "Corporate template", 7.5,
          light["muted"], align=PP_ALIGN.RIGHT)
    _slide_number(slide, index, light["muted"])


def _notes(slide, text: str):
    slide.notes_slide.notes_text_frame.text = text


def _theme(prs, light, dark):
    """Set theme colours and Inter as the major/minor typeface."""
    part = prs.slide_masters[0].part.part_related_by(RT.THEME)
    root = etree.fromstring(part.blob)
    clr = root.find(f".//{{{A_NS}}}clrScheme")
    values = {
        "dk1": light["ink"], "lt1": light["background"],
        "dk2": light["primary"], "lt2": light["soft"],
        "accent1": light["primary"], "accent2": light["copper"],
        "accent3": light["muted"], "accent4": light["line"],
        "accent5": dark["background"], "accent6": dark["primary"],
        "hlink": light["primary"], "folHlink": light["hover"],
    }
    for child in list(clr):
        name = etree.QName(child).localname
        if name in values:
            for sub in list(child):
                child.remove(sub)
            srgb = etree.SubElement(child, qn("a:srgbClr"))
            srgb.set("val", values[name].lstrip("#").upper())
    for font_tag in ("majorFont", "minorFont"):
        node = root.find(f".//{{{A_NS}}}{font_tag}")
        for tag in ("latin", "ea", "cs"):
            el = node.find(f"{{{A_NS}}}{tag}")
            if el is not None:
                el.set("typeface", FONT)
    part._blob = etree.tostring(root, xml_declaration=True, encoding="UTF-8",
                                standalone=True)


def build_deck(brand: Brand, out: Path):
    light = {k: brand.c("light", k) for k in
             ("background", "surface", "ink", "muted", "primary", "copper", "line", "soft", "hover", "onPrimary")}
    dark = {k: brand.c("dark", k) for k in
            ("background", "surface", "ink", "muted", "primary", "copper", "line", "soft", "hover", "onPrimary")}

    prs = Presentation()
    prs.slide_width = Inches(SLIDE_W)
    prs.slide_height = Inches(SLIDE_H)
    _theme(prs, light, dark)
    blank = prs.slide_layouts[6]

    def new(bg: str):
        slide = prs.slides.add_slide(blank)
        slide.background.fill.solid()
        slide.background.fill.fore_color.rgb = _rgb(bg)
        return slide

    # 1 — cover ---------------------------------------------------------
    s = new(dark["background"])
    _logo(s, brand, "assets/logo-on-dark.png", 0.7, 0.7, 2.6)
    _logo(s, brand, "assets/symbol-on-dark.png", 9.15, 1.35, 3.15)
    _text(s, 0.75, 2.3, 6.0, 0.25, "SEALFORGE · CORPORATE TEMPLATE", 8,
          dark["primary"], bold=True)
    _text(s, 0.75, 2.62, 7.5, 1.1, "Presentation title", 40, dark["ink"], bold=True)
    _text(s, 0.78, 3.82, 6.8, 0.85,
          "A short subtitle that states the purpose and the audience.", 15,
          dark["muted"], line=1.2)
    _rule(s, 0.78, 4.85, 0.9, dark["primary"], 0.02)
    _text(s, 0.78, 6.72, 6.0, 0.22,
          "16:9 · editable native slides · Inter", 7.5, dark["muted"])
    _notes(s, "Cover. Replace the title and subtitle with the real subject. The lockup is 2.6 in wide and the mascot 3.15 in; keep them at this scale rather than enlarging them. Put the date, client and presenter in the first content slide, not here.")

    # 2 — statement -----------------------------------------------------
    s = new(light["background"])
    _logo(s, brand, "assets/logo-on-light.png", 0.6, 0.55, 1.9)
    _text(s, 0.62, 1.55, 4.0, 0.22, "01 · POSITIONING", 8, light["primary"], bold=True)
    _text(s, 0.6, 1.92, 8.6, 1.9,
          "Your keys. Your signature. Your signing workshop.", 34, light["ink"],
          bold=True, line=1.06)
    _text(s, 0.63, 4.25, 7.2, 1.15,
          "A self-hosted signing workshop keeps the key with its owner and the "
          "document with a verifiable mark. Use this page for the one idea the "
          "audience should remember.", 13, light["muted"], line=1.25)
    _logo(s, brand, "assets/symbol-on-light.png", 10.0, 4.55, 2.55)
    _footer(s, 2, light)
    _notes(s, "Statement. One idea only. The sentence is the approved tagline; replace the paragraph with the specific argument for this audience.")

    # 3 — agenda --------------------------------------------------------
    s = new(light["background"])
    _logo(s, brand, "assets/logo-on-light.png", 0.6, 0.55, 1.9)
    _text(s, 0.6, 1.3, 8.0, 0.6, "Agenda", 30, light["ink"], bold=True)
    _text(s, 0.62, 1.95, 8.0, 0.3, "Four moves, one page each.", 12, light["muted"])
    cards = [
        ("01", "Context", "What the reader needs to know before the proposal."),
        ("02", "Approach", "The sequence and the decisions it unlocks."),
        ("03", "Scope", "What is included, excluded and delivered."),
        ("04", "Next step", "The single action requested at the end."),
    ]
    for i, (num, title, body) in enumerate(cards):
        x = 0.6 + (i % 2) * 6.15
        y = 2.45 + (i // 2) * 2.0
        _card(s, x, y, 5.95, 1.75, light["surface"], light["line"], [
            (num, 20, light["primary"], True, 4, PP_ALIGN.LEFT),
            (title, 15, light["ink"], True, 3, PP_ALIGN.LEFT),
            (body, 10.5, light["muted"], False, 0, PP_ALIGN.LEFT),
        ])
    _footer(s, 3, light)
    _notes(s, "Agenda. Keep four items; rename them to the real sections. The cards are native rounded rectangles with editable text.")

    # 4 — content with side panel ---------------------------------------
    s = new(light["background"])
    _logo(s, brand, "assets/logo-on-light.png", 0.6, 0.55, 1.9)
    _text(s, 0.6, 1.3, 8.4, 0.7, "What the document covers", 30, light["ink"], bold=True)
    _text(s, 0.62, 2.08, 7.4, 0.32,
          "Five points, in the order the reader needs them.", 12, light["muted"])
    _bullets(s, 0.62, 2.75, 7.2, 3.8, [
        "The problem in one sentence.",
        "The decision the reader is asked to make.",
        "The approach and its trade-offs.",
        "Scope, timing and ownership.",
        "The next step and the date it is needed.",
    ], 14, light["ink"], light["primary"], space_after=13)
    _card(s, 8.35, 2.2, 4.35, 3.4, light["soft"], light["soft"], [
        ("KEY POINT", 8, light["primary"], True, 8, PP_ALIGN.LEFT),
        ("Replace this panel with the one sentence that should survive the meeting.",
         15, light["ink"], False, 0, PP_ALIGN.LEFT),
    ], padding=0.38, anchor=MSO_ANCHOR.TOP, line=1.2)
    _footer(s, 4, light)
    _notes(s, "Content with a side panel. The panel is the takeaway; keep it to one sentence. The five bullets are a starting outline, not final copy.")

    # 5 — three columns --------------------------------------------------
    s = new(light["background"])
    _logo(s, brand, "assets/logo-on-light.png", 0.6, 0.55, 1.9)
    _text(s, 0.6, 1.3, 9.0, 0.7, "Three ways to use this template", 30,
          light["ink"], bold=True)
    _text(s, 0.62, 2.08, 8.6, 0.32,
          "Pick the page that matches the conversation; delete the rest.",
          12, light["muted"])
    cols = [
        ("01", "Report", "A short written record with a cover, sections and sign-off."),
        ("02", "Proposal", "A decision page, scope and commercial basis."),
        ("03", "Briefing", "A meeting deck with one idea per slide."),
    ]
    for i, (num, title, body) in enumerate(cols):
        x = 0.6 + i * 4.12
        _rule(s, x, 2.55, 0.36, light["primary"], 0.018)
        _text(s, x, 2.72, 0.6, 0.22, num, 9, light["primary"], bold=True)
        _text(s, x, 3.0, 3.55, 0.45, title, 17, light["ink"], bold=True)
        _text(s, x, 3.55, 3.55, 1.65, body, 11.5, light["muted"], line=1.25)
    _footer(s, 5, light)
    _notes(s, "Three-column layout. Each column has a rule, a number, a heading and one short paragraph. Use it for three options, capabilities or workstreams.")

    # 6 — process -------------------------------------------------------
    s = new(light["background"])
    _logo(s, brand, "assets/logo-on-light.png", 0.6, 0.55, 1.9)
    _text(s, 0.6, 1.3, 9.0, 0.7, "A simple four-step process", 30,
          light["ink"], bold=True)
    _text(s, 0.62, 2.08, 8.6, 0.32,
          "Rename the steps; keep one output per step.", 12, light["muted"])
    _rule(s, 0.9, 3.85, 11.5, light["line"], 0.022)
    steps = [
        ("01", "Discover", "Confirm the problem and the people."),
        ("02", "Design", "Compare the viable options."),
        ("03", "Deliver", "Execute and review at each gate."),
        ("04", "Close", "Hand over the output and the record."),
    ]
    for i, (num, title, body) in enumerate(steps):
        cx = 1.6 + i * 3.3
        circ = s.shapes.add_shape(MSO_SHAPE.OVAL, Inches(cx - 0.3), Inches(3.55),
                                  Inches(0.6), Inches(0.6))
        circ.fill.solid()
        circ.fill.fore_color.rgb = _rgb(light["primary"])
        circ.line.fill.background()
        circ.shadow.inherit = False
        _no_style(circ)
        tf = circ.text_frame
        tf.clear()
        tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
        tf.vertical_anchor = MSO_ANCHOR.MIDDLE
        p = tf.paragraphs[0]
        p.alignment = PP_ALIGN.CENTER
        run = p.add_run()
        run.text = num
        _set_font(run, 9, light["onPrimary"], True)
        _text(s, cx - 1.15, 4.33, 2.3, 0.28, title, 13, light["ink"], bold=True,
              align=PP_ALIGN.CENTER)
        _text(s, cx - 1.15, 4.65, 2.3, 1.2, body, 10.5, light["muted"],
              align=PP_ALIGN.CENTER, line=1.2)
    _footer(s, 6, light)
    _notes(s, "Process. Four steps on one line. If you need five, shorten the labels rather than shrinking the type below 9 pt.")

    # 7 — closing -------------------------------------------------------
    s = new(dark["background"])
    _logo(s, brand, "assets/logo-on-dark.png", 0.6, 0.6, 2.3)
    _logo(s, brand, "assets/symbol-on-dark.png", 9.4, 2.1, 2.9)
    _text(s, 0.7, 2.55, 7.4, 1.0, "Thank you.", 40, dark["ink"], bold=True)
    _text(s, 0.72, 3.72, 6.6, 0.9,
          "Replace this line with the next step, the owner and the date.",
          14, dark["muted"], line=1.2)
    _text(s, 0.72, 5.05, 5.5, 0.3, "{{contact}}", 11, dark["primary"])
    _rule(s, 0.6, 6.96, 12.13, dark["line"], 0.012)
    _text(s, 0.6, 7.0, 3.0, 0.22, "SealForge", 7.5, dark["muted"])
    _text(s, 10.7, 7.0, 1.3, 0.22, "Corporate template", 7.5,
          dark["muted"], align=PP_ALIGN.RIGHT)
    _slide_number(s, 7, dark["muted"])
    _notes(s, "Closing. Replace {{contact}} with a real, approved contact route. Do not add a phone number, address or registration detail that the brand kit does not contain.")

    cp = prs.core_properties
    cp.title = "SealForge presentation template (16:9)"
    cp.subject = "Editable corporate presentation template"
    cp.author = "SealForge"
    cp.last_modified_by = "SealForge"
    cp.keywords = "SealForge, brand template, 16:9, Inter"
    cp.category = "Brand template"
    cp.comments = ("Seven native layouts: cover, statement, agenda, content with side panel, "
                   "three columns, process and closing. Replace sample text.")
    cp.created = datetime(2026, 11, 16, 9, 0, 0)
    cp.modified = datetime(2026, 11, 16, 9, 0, 0)
    out.parent.mkdir(parents=True, exist_ok=True)
    prs.save(out)
    return out
