"""Editable native Word templates: A4 letterhead and report/proposal."""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

from docx import Document
from docx.enum.table import WD_ALIGN_VERTICAL, WD_ROW_HEIGHT_RULE
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_UNDERLINE
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Mm, Pt, RGBColor

from brand import Brand

FONT = "Inter"


# ---------------------------------------------------------------------------
# low-level helpers

def _rgb(hex_value: str) -> RGBColor:
    return RGBColor.from_string(hex_value.lstrip("#").upper())


def _force_run_font(run, size=None, color=None, bold=None, italic=None):
    run.font.name = FONT
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.insert(0, rfonts)
    for attr in ("ascii", "hAnsi", "cs", "eastAsia"):
        rfonts.set(qn(f"w:{attr}"), FONT)
    for attr in ("asciiTheme", "hAnsiTheme", "cstheme", "eastAsiaTheme"):
        rfonts.attrib.pop(qn(f"w:{attr}"), None)
    if size is not None:
        run.font.size = Pt(size)
    if color is not None:
        run.font.color.rgb = _rgb(color)
    if bold is not None:
        run.font.bold = bold
    if italic is not None:
        run.font.italic = italic


def _force_style_font(style, size=None, color=None, bold=None):
    style.font.name = FONT
    rpr = style.element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.insert(0, rfonts)
    for attr in ("ascii", "hAnsi", "cs", "eastAsia"):
        rfonts.set(qn(f"w:{attr}"), FONT)
    for attr in ("asciiTheme", "hAnsiTheme", "cstheme", "eastAsiaTheme"):
        rfonts.attrib.pop(qn(f"w:{attr}"), None)
    if size is not None:
        style.font.size = Pt(size)
    if color is not None:
        style.font.color.rgb = _rgb(color)
        colour = rpr.find(qn("w:color"))
        if colour is not None:
            for attr in ("themeColor", "themeShade", "themeTint"):
                colour.attrib.pop(qn(f"w:{attr}"), None)
    if bold is not None:
        style.font.bold = bold


def _para_border(paragraph, edge="bottom", color="316b73", size=8, space=4):
    ppr = paragraph._p.get_or_add_pPr()
    pbdr = ppr.find(qn("w:pBdr"))
    if pbdr is None:
        pbdr = OxmlElement("w:pBdr")
        ppr.insert_element_before(
            pbdr, "w:shd", "w:tabs", "w:spacing", "w:ind", "w:jc", "w:rPr",
        )
    el = OxmlElement(f"w:{edge}")
    el.set(qn("w:val"), "single")
    el.set(qn("w:sz"), str(size))
    el.set(qn("w:space"), str(space))
    el.set(qn("w:color"), color)
    pbdr.append(el)


def _edge_border(table, edge, color, size=4):
    tblpr = table._tbl.tblPr
    old = tblpr.find(qn("w:tblBorders"))
    if old is not None:
        tblpr.remove(old)
    borders = OxmlElement("w:tblBorders")
    for name in ("top", "left", "bottom", "right", "insideH", "insideV"):
        el = OxmlElement(f"w:{name}")
        if name == edge:
            el.set(qn("w:val"), "single")
            el.set(qn("w:sz"), str(size))
            el.set(qn("w:space"), "0")
            el.set(qn("w:color"), color)
        else:
            el.set(qn("w:val"), "nil")
        borders.append(el)
    tblpr.insert_element_before(
        borders, "w:shd", "w:tblLayout", "w:tblCellMar",
        "w:tblLook", "w:tblCaption", "w:tblDescription",
    )


def _header_table(container, brand, right_text, line_color):
    """Masthead as a borderless table: compact head/name left, metadata right.

    A tab stop is not reliable here because the built-in Header style carries
    centre tabs; an explicit table keeps the two ends where they belong.
    """
    p0 = container.paragraphs[0]
    p0._p.getparent().remove(p0._p)
    table = container.add_table(rows=1, cols=2, width=Mm(162))
    table.autofit = False
    _fixed_layout(table, [112, 50])
    _cell_margins(table, top=0, left=0, bottom=0, right=0)
    _edge_border(table, "bottom", line_color, 8)
    left = table.cell(0, 0).paragraphs[0]
    left.paragraph_format.space_before = Pt(0)
    left.paragraph_format.space_after = Pt(0)
    left.add_run().add_picture(str(brand.path('assets/head-on-light.png')), width=Mm(10))
    _force_run_font(left.add_run('  SealForge'), size=12, color='203033', bold=True)
    right = table.cell(0, 1).paragraphs[0]
    right.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    right.paragraph_format.space_before = Pt(0)
    right.paragraph_format.space_after = Pt(0)
    _add_tokens(right, right_text, 7.5, "56666a")
    end = container.add_paragraph()
    end.paragraph_format.space_before = Pt(0)
    end.paragraph_format.space_after = Pt(0)
    end.paragraph_format.line_spacing = Pt(1)


def _footer_table(container, left_text, line_color):
    p0 = container.paragraphs[0]
    p0._p.getparent().remove(p0._p)
    table = container.add_table(rows=1, cols=2, width=Mm(162))
    table.autofit = False
    _fixed_layout(table, [112, 50])
    _cell_margins(table, top=40, left=0, bottom=0, right=0)
    _edge_border(table, "top", line_color, 4)
    left = table.cell(0, 0).paragraphs[0]
    left.paragraph_format.space_before = Pt(0)
    left.paragraph_format.space_after = Pt(0)
    _add_tokens(left, left_text, 7.5, "56666a")
    right = table.cell(0, 1).paragraphs[0]
    right.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    right.paragraph_format.space_before = Pt(0)
    right.paragraph_format.space_after = Pt(0)
    run = right.add_run("Page ")
    _force_run_font(run, size=7.5, color="56666a")
    _add_field(right, "PAGE", "1", size=7.5)
    of = right.add_run(" of ")
    _force_run_font(of, size=7.5, color="56666a")
    _add_field(right, "NUMPAGES", "1", size=7.5)
    end = container.add_paragraph()
    end.paragraph_format.space_before = Pt(0)
    end.paragraph_format.space_after = Pt(0)
    end.paragraph_format.line_spacing = Pt(1)


def _add_field(paragraph, instruction: str, placeholder: str, size=7.5, color="56666a"):
    begin = paragraph.add_run()
    _force_run_font(begin, size=size, color=color)
    fld = OxmlElement("w:fldChar")
    fld.set(qn("w:fldCharType"), "begin")
    begin._r.append(fld)

    instr = paragraph.add_run()
    _force_run_font(instr, size=size, color=color)
    it = OxmlElement("w:instrText")
    it.set(qn("xml:space"), "preserve")
    it.text = instruction
    instr._r.append(it)

    sep = paragraph.add_run()
    _force_run_font(sep, size=size, color=color)
    fld = OxmlElement("w:fldChar")
    fld.set(qn("w:fldCharType"), "separate")
    sep._r.append(fld)

    text = paragraph.add_run(placeholder)
    _force_run_font(text, size=size, color=color)

    end = paragraph.add_run()
    _force_run_font(end, size=size, color=color)
    fld = OxmlElement("w:fldChar")
    fld.set(qn("w:fldCharType"), "end")
    end._r.append(fld)


def _add_tokens(paragraph, text: str, size: float, color: str, bold=False):
    """Split {{tokens}} into a muted dotted run so they read as placeholders."""
    import re

    for part in re.split(r"(\{\{[^}]+\}\})", text):
        if not part:
            continue
        run = paragraph.add_run(part)
        if part.startswith("{{") and part.endswith("}}"):
            _force_run_font(run, size=size, color="56666a", bold=bold)
            run.font.underline = WD_UNDERLINE.DOTTED
        else:
            _force_run_font(run, size=size, color=color, bold=bold)


def _para(container, text="", size=10, color="203033", bold=False, italic=False,
          align=None, before=0, after=4, line=1.35, style=None, keep=False,
          tokens=True, border=None):
    p = container.add_paragraph(style=style) if style else container.add_paragraph()
    pf = p.paragraph_format
    pf.space_before = Pt(before)
    pf.space_after = Pt(after)
    pf.line_spacing = line
    pf.keep_with_next = keep
    if align is not None:
        p.alignment = align
    if border:
        _para_border(p, border[0], border[1], border[2], border[3])
    if style and style.lower().startswith("heading"):
        # Let the named style own size, colour and weight; forcing run
        # formatting here would flatten every heading back to body text.
        pf.space_before = Pt(16)
        pf.space_after = Pt(6)
        pf.line_spacing = 1.05
        pf.keep_with_next = True
        if text:
            p.add_run(text)
        return p
    if text:
        if tokens:
            _add_tokens(p, text, size, color, bold)
        else:
            run = p.add_run(text)
            _force_run_font(run, size=size, color=color, bold=bold, italic=italic)
    return p


def _shade(cell, fill: str):
    tcpr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), fill)
    tcpr.append(shd)


def _cell_margins(table, top=80, left=120, bottom=80, right=120):
    tblpr = table._tbl.tblPr
    old = tblpr.find(qn("w:tblCellMar"))
    if old is not None:
        tblpr.remove(old)
    mar = OxmlElement("w:tblCellMar")
    for edge, value in (("top", top), ("left", left), ("bottom", bottom), ("right", right)):
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:w"), str(value))
        el.set(qn("w:type"), "dxa")
        mar.append(el)
    tblpr.insert_element_before(mar, "w:tblLook", "w:tblCaption", "w:tblDescription")


def _table_borders(table, color="d8e1de", size=4):
    tblpr = table._tbl.tblPr
    old = tblpr.find(qn("w:tblBorders"))
    if old is not None:
        tblpr.remove(old)
    borders = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), str(size))
        el.set(qn("w:space"), "0")
        el.set(qn("w:color"), color)
        borders.append(el)
    tblpr.insert_element_before(
        borders, "w:shd", "w:tblLayout", "w:tblCellMar",
        "w:tblLook", "w:tblCaption", "w:tblDescription",
    )


def _fixed_layout(table, widths_mm):
    tblpr = table._tbl.tblPr
    old = tblpr.find(qn("w:tblLayout"))
    if old is not None:
        tblpr.remove(old)
    layout = OxmlElement("w:tblLayout")
    layout.set(qn("w:type"), "fixed")
    tblpr.insert_element_before(layout, "w:tblCellMar", "w:tblLook",
                                "w:tblCaption", "w:tblDescription")
    tblw = tblpr.find(qn("w:tblW"))
    if tblw is None:
        tblw = OxmlElement("w:tblW")
        tblpr.insert_element_before(tblw, "w:jc", "w:tblCellSpacing",
                                    "w:tblInd", "w:tblBorders")
    tblw.set(qn("w:type"), "dxa")
    tblw.set(qn("w:w"), str(int(sum(widths_mm) * 56.6929)))
    for idx, width in enumerate(widths_mm):
        table.columns[idx].width = Mm(width)
        for cell in table.columns[idx].cells:
            cell.width = Mm(width)


def _cell_text(cell, text, size=9, color="203033", bold=False, align=None,
               line=1.2, after=0):
    p = cell.paragraphs[0]
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(after)
    p.paragraph_format.line_spacing = line
    if align is not None:
        p.alignment = align
    _add_tokens(p, text, size, color, bold)
    cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER


def _make_table(doc, widths_mm, rows, header=True, font_size=8.6):
    table = doc.add_table(rows=len(rows), cols=len(widths_mm))
    table.autofit = False
    table.allow_autofit = False
    _table_borders(table)
    _fixed_layout(table, widths_mm)
    _cell_margins(table)
    for r_idx, row in enumerate(rows):
        trpr = table.rows[r_idx]._tr.get_or_add_trPr()
        cant = OxmlElement("w:cantSplit")
        trpr.append(cant)
        if header and r_idx == 0:
            repeat = OxmlElement("w:tblHeader")
            repeat.set(qn("w:val"), "true")
            trpr.append(repeat)
        for c_idx, value in enumerate(row):
            cell = table.cell(r_idx, c_idx)
            if header and r_idx == 0:
                _shade(cell, "ebf2ef")
                _cell_text(cell, value, size=font_size, color="316b73", bold=True)
            else:
                _cell_text(cell, value, size=font_size)
    return table


def _setup_styles(doc, ink="203033", muted="56666a", primary="316b73"):
    normal = doc.styles["Normal"]
    _force_style_font(normal, size=10, color=ink)
    normal.paragraph_format.space_after = Pt(4)
    normal.paragraph_format.line_spacing = 1.35
    rpr = normal.element.get_or_add_rPr()
    lang = OxmlElement("w:lang")
    lang.set(qn("w:val"), "en-GB")
    lang.set(qn("w:eastAsia"), "en-GB")
    rpr.append(lang)

    h1 = doc.styles["Heading 1"]
    _force_style_font(h1, size=18, color=primary, bold=True)
    h1.paragraph_format.space_before = Pt(26)
    h1.paragraph_format.space_after = Pt(9)
    h1.paragraph_format.keep_with_next = True
    h1.paragraph_format.line_spacing = 1.05

    h2 = doc.styles["Heading 2"]
    _force_style_font(h2, size=11.5, color=ink, bold=True)
    h2.paragraph_format.space_before = Pt(14)
    h2.paragraph_format.space_after = Pt(4)
    h2.paragraph_format.keep_with_next = True
    h2.paragraph_format.line_spacing = 1.1

    for name in ("List Bullet", "List Number"):
        st = doc.styles[name]
        _force_style_font(st, size=10, color=ink)


def _core(doc, title: str, subject: str, comments: str):
    cp = doc.core_properties
    cp.author = "SealForge"
    cp.last_modified_by = "SealForge"
    cp.title = title
    cp.subject = subject
    cp.comments = comments
    cp.category = "Brand template"
    cp.keywords = "SealForge, brand template, A4, Inter"
    cp.created = datetime(2026, 11, 16, 9, 0, 0)
    cp.modified = datetime(2026, 11, 16, 9, 0, 0)
    cp.revision = 1


def _first_page_blank(header_or_footer):
    header_or_footer.is_linked_to_previous = False
    p = header_or_footer.paragraphs[0]
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(0)


# ---------------------------------------------------------------------------
# letterhead

def build_letterhead(brand: Brand, out: Path):
    light = lambda key: brand.c("light", key)
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Mm(210), Mm(297)
    sec.top_margin, sec.bottom_margin = Mm(24), Mm(16)
    sec.left_margin = sec.right_margin = Mm(24)
    sec.header_distance, sec.footer_distance = Mm(10), Mm(8)
    sec.different_first_page_header_footer = True
    _setup_styles(doc, light("ink"), light("muted"), light("primary"))

    # First page masthead only; later pages keep the footer, not the lockup.
    hdr = sec.first_page_header
    hdr.is_linked_to_previous = False
    _header_table(hdr, brand, "Letterhead · A4",
                  light("primary"))

    _footer_table(sec.first_page_footer, "SealForge · a signing workshop", light("line"))
    _first_page_blank(sec.header)
    _footer_table(sec.footer, "SealForge · a signing workshop", light("line"))

    _para(doc, "{{date}}", size=9, color=light("muted"), after=18)
    for line, after in (("{{recipient_name}}", 0), ("{{organisation}}", 0),
                        ("{{address}}", 0), ("{{postcode_city}}", 22)):
        _para(doc, line, size=9.5, color=light("ink"), after=after, line=1.25)
    _para(doc, "{{subject}}", size=10.5, color=light("ink"), bold=True, after=14)
    _para(doc, "Dear {{recipient_name}},", size=10, after=10)
    _para(doc,
          "This letterhead template is ready for your text. Replace every dotted token "
          "with real details before sending. The kit contains no personal or company "
          "contact data.", size=10, after=10)
    _para(doc,
          "SealForge is a signing workshop: the key stays with its owner, and the document "
          "leaves with a verifiable mark. The compact head and name sit at the top left, a single petrol "
          "hairline closes the header, and the page below is written text.", size=10, after=10)
    _para(doc,
          "Body copy is set in Inter at 10 pt. Keep the measure at 150 mm or less, leave the "
          "signature room to breathe, and let the footer carry the page number. If the letter "
          "runs to a second page, only the footer repeats.", size=10, after=10)
    _para(doc, "Keep the closing short. The mark does not need to appear again.", size=10, after=0)

    _para(doc, "", size=10, after=0)
    _para(doc, "{{sender_name}}", size=9.5, after=0, line=1.25)
    _para(doc, "SealForge", size=9.5, bold=True, after=0, line=1.25, tokens=False)
    _para(doc, "{{sender_role}}", size=9.5, after=18, line=1.25)

    _para(doc,
          "Template note: replace every dotted token, then delete this line. The masthead "
          "appears on page 1 only; the footer repeats on later pages.",
          size=7.5, color=light("muted"), after=0, line=1.3)

    _core(doc, "SealForge letterhead (A4 template)",
          "Editable A4 letterhead with approved SealForge lockup",
          "Replace {{tokens}} before use. Masthead on first page only.")
    out.parent.mkdir(parents=True, exist_ok=True)
    doc.save(out)
    return out


# ---------------------------------------------------------------------------
# report / proposal

def build_report(brand: Brand, out: Path):
    light = lambda key: brand.c("light", key)
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Mm(210), Mm(297)
    sec.top_margin, sec.bottom_margin = Mm(23), Mm(17)
    sec.left_margin = sec.right_margin = Mm(24)
    sec.header_distance, sec.footer_distance = Mm(9), Mm(8)
    sec.different_first_page_header_footer = True
    _setup_styles(doc, light("ink"), light("muted"), light("primary"))

    # Cover: no running head, but the mascot anchors the bottom-right corner.
    _first_page_blank(sec.first_page_header)
    sec.first_page_footer.is_linked_to_previous = False
    fp = sec.first_page_footer.paragraphs[0]
    fp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    fp.paragraph_format.space_before = Pt(0)
    fp.paragraph_format.space_after = Pt(0)
    fp.add_run().add_picture(str(brand.path("assets/symbol-on-light.png")), width=Mm(32))
    fp.add_run().add_break()
    tag = fp.add_run("Your signing workshop.")
    _force_run_font(tag, size=7.5, color=light("muted"))

    hdr = sec.header
    hdr.is_linked_to_previous = False
    _header_table(hdr, brand, "{{project_name}}",
                  light("line"))

    _footer_table(sec.footer, "SealForge · {{project_name}}", light("line"))

    # --- cover ---------------------------------------------------------
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(0)
    p.add_run().add_picture(str(brand.path("assets/logo-on-light.png")), width=Mm(48))

    _para(doc, "", size=10, after=0)
    _para(doc, "", size=10, after=0)
    _para(doc, "", size=10, after=0)
    _para(doc, "", size=10, after=0)
    _para(doc, "REPORT / PROPOSAL", size=8, color=light("primary"), bold=True,
          after=12, border=("bottom", light("primary"), 8, 6))
    _para(doc, "Report or proposal title", size=26, color=light("ink"), bold=True,
          after=8, line=1.05, keep=True, tokens=False)
    _para(doc, "A short subtitle that states the purpose and the decision requested.",
          size=12, color=light("muted"), after=34, line=1.3, tokens=False)

    meta_rows = [
        ("Prepared for", "{{client}}"),
        ("Prepared by", "{{author}}"),
        ("Date", "{{date}}"),
        ("Version", "{{version}}"),
    ]
    table = doc.add_table(rows=len(meta_rows), cols=2)
    table.autofit = False
    _fixed_layout(table, [32, 100])
    _cell_margins(table, top=30, left=0, bottom=30, right=0)
    for i, (label, value) in enumerate(meta_rows):
        c0, c1 = table.cell(i, 0), table.cell(i, 1)
        _cell_text(c0, label, size=8, color=light("muted"))
        _cell_text(c1, value, size=9.5, color=light("ink"))

    doc.add_page_break()

    # --- body ----------------------------------------------------------
    _para(doc, "1. Executive summary", style="Heading 1", tokens=False)
    _para(doc, "This report sets out the purpose of {{project_name}}, the decision "
               "requested and the outcome the reader should expect. Replace this paragraph "
               "with a two- or three-sentence summary; keep it to one page.", after=8)
    _para(doc, "Use the second paragraph for the recommendation. Add the commercial or "
               "operational context only when the reader needs it before the detail.", after=8)

    _para(doc, "2. Context and objectives", style="Heading 1", tokens=False)
    _para(doc, "Describe the situation that prompted this document, who is affected and "
               "what is already known. State the objective in one sentence before listing "
               "the constraints.", after=6)
    for bullet in (
        "Objective: the single outcome this work must achieve.",
        "Constraint: the budget, timing, regulation or dependency that shapes the options.",
        "Success measure: how the reader will know the outcome was reached.",
    ):
        _para(doc, bullet, style="List Bullet", after=2)

    _para(doc, "3. Proposed approach", style="Heading 1", tokens=False)
    _para(doc, "The sequence below is a starting point. Rename the phases to match the "
               "work and keep one output per phase so the review points stay clear.", after=6, keep=True)
    _make_table(doc, [22, 92, 48], [
        ["Phase", "What happens", "Output"],
        ["01 Discovery", "Confirm the problem, stakeholders and constraints.",
         "Agreed brief and success measures."],
        ["02 Design", "Develop and compare the viable options.",
         "Recommended option and outline plan."],
        ["03 Delivery", "Execute the agreed plan and review at each gate.",
         "Delivered scope and close-out note."],
    ])

    _para(doc, "4. Scope and deliverables", style="Heading 1", tokens=False)
    _para(doc, "List what the work includes, what it explicitly excludes and the artefacts "
               "the reader receives. Keep each row short enough to scan.", after=6, keep=True)
    _make_table(doc, [55, 55, 52], [
        ["In scope", "Out of scope", "Deliverable"],
        ["{{in_scope_1}}", "{{out_of_scope_1}}", "{{deliverable_1}}"],
        ["{{in_scope_2}}", "{{out_of_scope_2}}", "{{deliverable_2}}"],
        ["{{in_scope_3}}", "{{out_of_scope_3}}", "{{deliverable_3}}"],
    ])

    _para(doc, "5. Timeline", style="Heading 1", tokens=False)
    _para(doc, "Set dates only after the scope is agreed. The table is deliberately "
               "generic and contains no assumed schedule.", after=6, keep=True)
    _make_table(doc, [42, 40, 80], [
        ["Phase", "Timing", "Owner"],
        ["Discovery", "{{discovery_timing}}", "{{owner}}"],
        ["Design", "{{design_timing}}", "{{owner}}"],
        ["Delivery", "{{delivery_timing}}", "{{owner}}"],
    ])

    _para(doc, "6. Investment", style="Heading 1", tokens=False)
    _para(doc, "State the commercial basis and currency before quoting a figure. No "
               "amounts are assumed in this template.", after=6, keep=True)
    _make_table(doc, [62, 50, 50], [
        ["Item", "Basis", "Amount"],
        ["Discovery", "Fixed fee", "To be completed"],
        ["Design", "Fixed fee", "To be completed"],
        ["Delivery", "Time and materials", "To be completed"],
    ])

    _para(doc, "7. Next steps", style="Heading 1", tokens=False)
    for item in (
        "Confirm the scope and name one owner for each side.",
        "Agree the start date, review points and decision date.",
        "Replace every placeholder, set the document version and circulate for sign-off.",
    ):
        _para(doc, item, style="List Number", after=3)

    _para(doc, "Sign-off", style="Heading 2", tokens=False)
    _make_table(doc, [50, 42, 40, 30], [
        ["Name", "Role", "Signature", "Date"],
        ["{{client_signer}}", "{{client_role}}", "", "{{date}}"],
        ["{{author}}", "{{author_role}}", "", "{{date}}"],
    ])

    _core(doc, "SealForge report / proposal (A4 template)",
          "Editable A4 report and proposal template",
          "Replace {{tokens}}. Cover title and subtitle are sample text; running head and page numbers are native fields.")
    out.parent.mkdir(parents=True, exist_ok=True)
    doc.save(out)
    return out
