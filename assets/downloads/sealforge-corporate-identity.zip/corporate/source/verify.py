"""Structural, layout and print checks for the generated package."""
from __future__ import annotations

import hashlib
import json
import posixpath
import re
import shutil
import subprocess
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import unquote

from PIL import Image, ImageFont
from pypdf import PdfReader
from docx import Document
from pptx import Presentation

from brand import Brand, sha256

W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
A_NS = "http://schemas.openxmlformats.org/drawingml/2006/main"


def _run(cmd, log=None):
    result = subprocess.run(cmd, capture_output=True, text=True)
    if log is not None:
        log.append(f"$ {' '.join(cmd)}\n{result.stdout}{result.stderr}")
    return result


def _rels_ok(zf: zipfile.ZipFile):
    names = set(zf.namelist())
    missing = []
    for rels in [n for n in names if n.endswith(".rels")]:
        p = Path(rels)
        base = p.parent.parent.as_posix() if p.parent.name == "_rels" else p.parent.as_posix()
        if base == ".":
            base = ""
        try:
            # Local, generated package parts only; entities are not resolved.
            from lxml import etree as lxml_etree
            root = lxml_etree.fromstring(zf.read(rels),
                                         parser=lxml_etree.XMLParser(resolve_entities=False))
        except Exception as exc:  # noqa: BLE001
            missing.append(f"{rels}: unreadable ({exc})")
            continue
        for rel in root:
            if rel.get("TargetMode") == "External":
                continue
            target = unquote(rel.get("Target", ""))
            if not target:
                continue
            resolved = (target[1:] if target.startswith("/")
                        else posixpath.normpath(posixpath.join(base, target)))
            if resolved not in names:
                missing.append(f"{rels} -> {resolved}")
    return missing


def _zip_report(path: Path, required: list[str]):
    with zipfile.ZipFile(path) as zf:
        bad = zf.testzip()
        names = set(zf.namelist())
        return {
            "zip_ok": bad is None,
            "bad_member": bad,
            "required_parts_present": all(n in names for n in required),
            "missing_required": [n for n in required if n not in names],
            "relationship_targets_missing": _rels_ok(zf),
            "parts": len(names),
        }


def validate_docx(path: Path, brand: Brand):
    report = _zip_report(path, [
        "[Content_Types].xml", "_rels/.rels", "word/document.xml",
        "word/styles.xml", "word/settings.xml",
    ])
    doc = Document(path)
    sec = doc.sections[0]
    all_text = []
    for p in doc.paragraphs:
        all_text.append(p.text)
    for t in doc.tables:
        for row in t.rows:
            for cell in row.cells:
                all_text.append(cell.text)
    for s in doc.sections:
        for part in (s.header, s.footer, s.first_page_header, s.first_page_footer):
            for p in part.paragraphs:
                all_text.append(p.text)
    tokens = sorted(set(re.findall(r"\{\{[^}]+\}\}", "\n".join(all_text))))
    images = len(doc.inline_shapes)
    drawings = sum(len(p._element.findall(".//" + "{" + W_NS + "}drawing"))
                   for p in doc.paragraphs)
    first_header_drawings = len(
        sec.first_page_header._element.findall(".//" + "{" + W_NS + "}drawing")
    )
    first_footer_drawings = len(
        sec.first_page_footer._element.findall(".//" + "{" + W_NS + "}drawing")
    )
    footer_fields = len(
        sec.footer._element.findall(".//" + "{" + W_NS + "}fldChar")
    )
    report.update({
        "path": path.name,
        "sections": len(doc.sections),
        "paragraphs": len(doc.paragraphs),
        "tables": len(doc.tables),
        "inline_images": images,
        "body_drawings": drawings,
        "first_page_header_drawings": first_header_drawings,
        "first_page_footer_drawings": first_footer_drawings,
        "footer_field_chars": footer_fields,
        "page_mm": [round(sec.page_width.mm, 1), round(sec.page_height.mm, 1)],
        "margins_mm": [round(sec.top_margin.mm, 1), round(sec.right_margin.mm, 1),
                       round(sec.bottom_margin.mm, 1), round(sec.left_margin.mm, 1)],
        "tokens": tokens,
        "different_first_page": sec.different_first_page_header_footer,
        "ok": True,
    })
    report["ok"] = (
        report["zip_ok"] and report["required_parts_present"]
        and not report["relationship_targets_missing"]
        and report["page_mm"] == [210.0, 297.0]
        and (report["first_page_header_drawings"]
             + report["first_page_footer_drawings"]
             + report["body_drawings"]) >= 1
        and report["footer_field_chars"] >= 6
    )
    return report


def _font(size_pt: int, bold: bool, brand: Brand):
    f = ImageFont.truetype(str(brand.path("raw/fonts/Inter.ttf")),
                           max(8, int(round(size_pt * 96 / 72))))
    f.set_variation_by_name("SemiBold" if bold else "Regular")
    return f


def _wrap_lines(text: str, font, width_px: float):
    lines = 0
    for chunk in text.split("\n"):
        words = chunk.split()
        if not words:
            lines += 1
            continue
        line = words[0]
        count = 1
        for word in words[1:]:
            probe = f"{line} {word}"
            if font.getlength(probe) <= width_px:
                line = probe
            else:
                count += 1
                line = word
        lines += count
    return lines


def _fit_ratio(shape, brand: Brand):
    tf = shape.text_frame
    if not tf.text.strip():
        return None
    if not tf.word_wrap:
        return None
    avail_w = max(1, (shape.width or 0) - (tf.margin_left or 0) - (tf.margin_right or 0))
    avail_h = max(1, (shape.height or 0) - (tf.margin_top or 0) - (tf.margin_bottom or 0))
    width_px = avail_w / 914400 * 96
    height_px = avail_h / 914400 * 96
    total = 0.0
    for para in tf.paragraphs:
        text = "".join(r.text for r in para.runs)
        size = max([(r.font.size.pt if r.font.size else 18) for r in para.runs] or [18])
        bold = any(bool(r.font.bold) for r in para.runs)
        if text.strip():
            lines = _wrap_lines(text, _font(int(round(size)), bold, brand), width_px)
            total += lines * size * 1.24 * 96 / 72
        after = para.space_after.pt if para.space_after else 0
        total += after * 96 / 72
    return round(total / height_px, 3)


def validate_pptx(path: Path, brand: Brand):
    report = _zip_report(path, [
        "[Content_Types].xml", "_rels/.rels", "ppt/presentation.xml",
        "ppt/theme/theme1.xml", "ppt/slideMasters/slideMaster1.xml",
    ])
    prs = Presentation(path)
    sw, sh = prs.slide_width, prs.slide_height
    slides = []
    overflows = []
    out_of_bounds = []
    with zipfile.ZipFile(path) as zf:
        theme = zf.read("ppt/theme/theme1.xml").decode("utf-8", "replace")
    theme_fonts = re.findall(r'<a:(?:majorFont|minorFont)>.*?<a:latin typeface="([^"]+)"',
                             theme, flags=re.S)
    for idx, slide in enumerate(prs.slides, 1):
        shape_reports = []
        for shape in slide.shapes:
            if shape.left is None or shape.top is None:
                continue
            if (shape.left < 0 or shape.top < 0 or
                    shape.left + (shape.width or 0) > sw + 5000 or
                    shape.top + (shape.height or 0) > sh + 5000):
                out_of_bounds.append({
                    "slide": idx, "shape": shape.name,
                    "box_in": [round(shape.left / 914400, 2), round(shape.top / 914400, 2),
                               round((shape.width or 0) / 914400, 2),
                               round((shape.height or 0) / 914400, 2)],
                })
            if shape.has_text_frame:
                ratio = _fit_ratio(shape, brand)
                if ratio is not None and ratio > 1.05:
                    overflows.append({
                        "slide": idx, "shape": shape.name, "ratio": ratio,
                        "text": shape.text_frame.text[:80],
                    })
                shape_reports.append({
                    "name": shape.name,
                    "box_in": [round(shape.left / 914400, 2), round(shape.top / 914400, 2),
                               round((shape.width or 0) / 914400, 2),
                               round((shape.height or 0) / 914400, 2)],
                    "fit_ratio": ratio,
                    "text": shape.text_frame.text[:100],
                })
        notes = slide.notes_slide.notes_text_frame.text if slide.has_notes_slide else ""
        slides.append({
            "index": idx,
            "shapes": len(slide.shapes),
            "text_shapes": shape_reports,
            "notes_chars": len(notes),
        })
    report.update({
        "slide_count": len(prs.slides),
        "slide_size_in": [round(sw / 914400, 3), round(sh / 914400, 3)],
        "theme_fonts": theme_fonts,
        "slides": slides,
        "out_of_bounds": out_of_bounds,
        "text_overflow": overflows,
        "ok": False,
    })
    report["ok"] = (
        report["zip_ok"] and report["required_parts_present"]
        and not report["relationship_targets_missing"]
        and report["slide_count"] == 7
        and report["slide_size_in"] == [13.333, 7.5]
        and theme_fonts[:2] == ["Inter", "Inter"]
        and not out_of_bounds and not overflows
    )
    return report


def render_office(office_dir: Path, report_dir: Path):
    log = []
    soffice = shutil.which("soffice") or shutil.which("libreoffice")
    if not soffice:
        return {"rendered": False, "missing": ["soffice"], "log": log}
    work = report_dir / "work"
    work.mkdir(parents=True, exist_ok=True)
    renders = report_dir / "renders"
    (renders / "office").mkdir(parents=True, exist_ok=True)
    (renders / "slides").mkdir(parents=True, exist_ok=True)
    profile = (work / "lo-profile").as_uri()
    outputs = {}
    for path in sorted(office_dir.glob("*")):
        if path.suffix.lower() not in (".docx", ".pptx"):
            continue
        cmd = [soffice, "--headless", "--norestore", f"-env:UserInstallation={profile}",
               "--convert-to", "pdf", "--outdir", str(work), str(path)]
        result = _run(cmd, log)
        pdf = work / f"{path.stem}.pdf"
        info = _run(["pdfinfo", str(pdf)], log) if pdf.exists() else None
        outputs[path.name] = {
            "converted": pdf.exists() and result.returncode == 0,
            "pdf": pdf.name if pdf.exists() else None,
            "pdfinfo": info.stdout if info else "",
            "returncode": result.returncode,
        }
        if pdf.exists() and shutil.which("pdftoppm"):
            if path.suffix.lower() == ".docx":
                prefix = renders / "office" / path.stem.replace("SealForge-", "").lower()
            else:
                prefix = renders / "slides" / "slide"
            _run(["pdftoppm", "-png", "-r", "110", str(pdf), str(prefix)], log)
    return {"rendered": True, "missing": [], "outputs": outputs, "log": log}


def check_card_pdf(pdf: Path, print_dir: Path, renders: Path):
    renders.mkdir(parents=True, exist_ok=True)
    if shutil.which("pdftoppm"):
        for old in renders.glob("card-*.png"):
            old.unlink()
        _run(["pdftoppm", "-png", "-r", "300", str(pdf), str(renders / "card")])
    reader = PdfReader(str(pdf))
    pages = []
    cmyk_hits = 0
    rgb_hits = 0
    for page in reader.pages:
        mb = page.mediabox
        content = b""
        if page.get_contents() is not None:
            content = page.get_contents().get_data()
        text = content.decode("latin-1", "replace")
        cmyk_hits += len(re.findall(r"(?<![A-Za-z])[kK](?![A-Za-z])", text))
        rgb_hits += len(re.findall(r"(?<![A-Za-z])[rR][gG](?![A-Za-z])", text))
        pages.append({
            "size_pt": [round(float(mb.width), 2), round(float(mb.height), 2)],
            "annots": len(page.get("/Annots", []) or []),
            "content_bytes": len(content),
        })
    expected = [round(91 / 25.4 * 72, 2), round(61 / 25.4 * 72, 2)]
    fonts = _run(["pdffonts", str(pdf)]).stdout
    font_rows = []
    for line in fonts.splitlines():
        if not line.strip() or line.startswith("name") or line.startswith("---"):
            continue
        parts = line.split()
        if len(parts) >= 5:
            font_rows.append({"name": parts[0], "embedded": parts[4] == "yes"})
    guide_pixels = {"magenta": 0, "cyan": 0}
    for png in sorted(renders.glob("card-*.png")):
        img = Image.open(png).convert("RGB")
        for r, g, b in img.getdata():
            if r > 220 and b > 220 and g < 80:
                guide_pixels["magenta"] += 1
            if r < 80 and g > 140 and b > 220:
                guide_pixels["cyan"] += 1
    clean_front = (print_dir / "business-card-front.svg").read_text("utf-8")
    clean_back = (print_dir / "business-card-back.svg").read_text("utf-8")
    guide_front = (print_dir / "business-card-front-guides.svg").read_text("utf-8")
    guide_back = (print_dir / "business-card-back-guides.svg").read_text("utf-8")
    ok = (
        len(reader.pages) == 2
        and all(p["size_pt"] == expected for p in pages)
        and all(p["annots"] == 0 for p in pages)
        and cmyk_hits == 0
        and rgb_hits > 0
        and font_rows and all(f["embedded"] for f in font_rows)
        and guide_pixels == {"magenta": 0, "cyan": 0}
        and 'id="guides"' not in clean_front and 'id="guides"' not in clean_back
        and 'id="guides"' in guide_front and 'id="guides"' in guide_back
    )
    return {
        "ok": ok,
        "pages": len(reader.pages),
        "page_sizes_pt": pages,
        "expected_size_pt": expected,
        "cmyk_operator_hits": cmyk_hits,
        "rgb_operator_hits": rgb_hits,
        "fonts": font_rows,
        "guide_pixels": guide_pixels,
        "clean_svg_has_no_guides": 'id="guides"' not in clean_front and 'id="guides"' not in clean_back,
        "guide_svg_has_guides": 'id="guides"' in guide_front and 'id="guides"' in guide_back,
        "pdfinfo": _run(["pdfinfo", str(pdf)]).stdout,
        "pdffonts": fonts,
    }


def check_social(social_dir: Path, brand: Brand):
    files = {}
    for name, expected in (("avatar-400.png", (400, 400)),
                           ("cover-1500x500.png", (1500, 500)),
                           ("post-1200x630.png", (1200, 630))):
        p = social_dir / name
        with Image.open(p) as im:
            files[name] = {"size": list(im.size), "mode": im.mode,
                           "expected_size": list(expected),
                           "ok": im.size == expected}
    post_hash = sha256(social_dir / "post-1200x630.png")
    canonical = sha256(brand.path("assets/social-card.png"))
    return {
        "ok": all(v["ok"] for v in files.values()) and post_hash == canonical,
        "files": files,
        "post_hash_matches_canonical": post_hash == canonical,
    }


def check_email(email_dir: Path, brand: Brand):
    html = (email_dir / "sealforge-email-signature.html").read_text("utf-8")
    txt = (email_dir / "sealforge-email-signature.txt").read_text("utf-8")
    tokens = ["{{name}}", "{{role}}", "{{contact}}", "{{logo_url}}"]
    logo = email_dir / "email-logo.png"
    with Image.open(logo) as im:
        logo_size = list(im.size)
    logo_ok = (logo_size == [648, 176]
               and sha256(logo) == sha256(brand.path("assets/email-logo.png")))
    ok = all(t in html for t in tokens) and all(t in txt for t in tokens[:3]) and logo_ok
    fake = {
        "mailto": "mailto:" in html,
        "at_sign": "@" in html or "@" in txt,
        "url": "http://" in html or "https://" in html,
        "long_digit_run": bool(re.search(r"\+?\d[\d\s().-]{6,}", html)),
    }
    return {"ok": ok and not any(fake.values()), "tokens_present": ok,
            "logo_ok": logo_ok, "logo_size": logo_size,
            "fake_contact_markers": fake}


def forbidden_copy(deliverables: Path):
    terms = ["open source", "open-source", "free", "pricing", "price list",
             "certified", "certification", "500+", "customers", "money-back"]
    hits = []
    for p in deliverables.rglob("*"):
        # Technical Markdown documents include explicit non-certification limits;
        # this lexical check targets distributable email and marketing metadata.
        if not p.is_file() or p.suffix.lower() not in (".html", ".txt", ".json"):
            continue
        if p.name == "OFL.txt":
            continue  # mandatory licence text is not marketing copy
        text = p.read_text("utf-8", "replace").lower()
        for term in terms:
            if term in text:
                hits.append({"file": p.relative_to(deliverables).as_posix(), "term": term})
    return hits


def write_inventory(deliverables: Path, out: Path, checks: dict, brand: Brand):
    roles = {
        "office/sealforge-letterhead.docx": "Editable native Word A4 letterhead",
        "office/sealforge-report-template.docx": "Editable native Word report/proposal template",
        "office/sealforge-presentation.pptx": "Editable native 16:9 PowerPoint template",
        "print/business-card-front.svg": "Editable business-card front, artwork only, 91×61 mm page with 3 mm bleed",
        "print/business-card-back.svg": "Editable business-card back, artwork only, 91×61 mm page with 3 mm bleed",
        "print/business-card-front-guides.svg": "Editable front source with bleed, trim and safe guides",
        "print/business-card-back-guides.svg": "Editable back source with bleed, trim and safe guides",
        "print/business-card-85x55-RGB.pdf": "Print PDF, two pages, 91×61 mm, RGB, no guide marks",
        "print/print-spec.json": "Print geometry and colour-space specification",
        "digital/social/avatar-400.png": "Social avatar, 400×400, approved head art",
        "digital/social/cover-1500x500.png": "Social cover, 1500×500, approved logo and symbol",
        "digital/social/post-1200x630.png": "Social/Open Graph post image, canonical 1200×630 export",
        "digital/email/sealforge-email-signature.html": "HTML email signature template with {{name}}, {{role}}, {{contact}}, {{logo_url}}",
        "digital/email/sealforge-email-signature.txt": "Plain-text email signature template",
        "digital/email/email-logo.png": "Canonical email logo for hosting behind {{logo_url}}",
        "fonts/Inter.ttf": "Canonical Inter variable font",
        "fonts/OFL.txt": "SIL Open Font License 1.1 for Inter",
        "README.md": "Turkish inventory, usage and limitations",
        "source/README.template.md": "Turkish README source copied into the package root",
        "source/generate.py": "Reproducible build entry point",
        "source/brand.py": "Approved palette and canonical asset guards",
        "source/office.py": "Word template builder",
        "source/deck.py": "PowerPoint template builder",
        "source/assets.py": "Print, social and email asset builder",
        "source/verify.py": "Structural, render and print checks",
        "source/requirements.txt": "Pinned Python dependencies",
    }
    limits = {
        "office": "Native Word PowerPoint content; fonts are not embedded. Inter must be installed or Word substitutes it. TOC was deliberately omitted; running head and page numbers are fields.",
        "print": "RGB only. No CMYK conversion, ICC output intent or commercial proof is supplied. The print PDF contains {{tokens}} until the template is filled.",
        "social": "Derived from the approved exports; do not recolour or redraw. Platform crops vary.",
        "digital": "Email clients may strip web fonts; Arial/Helvetica fallback is intentional. {{logo_url}} must point to a hosted PNG.",
        "fonts": "Redistribute with OFL.txt. Variable font; some Office versions expose only the default instance.",
        "source": "Requires the documented Python and system tools; reads the canonical brand root, never rewrites it.",
    }
    files = []
    for p in sorted(deliverables.rglob("*")):
        if not p.is_file() or "__pycache__" in p.parts or p.suffix == ".pyc":
            continue
        rel = p.relative_to(deliverables).as_posix()
        if rel.startswith("digital/social/"):
            group = "social"
        elif rel.startswith("digital/email/"):
            group = "digital"
        else:
            group = rel.split("/")[0] if "/" in rel else "root"
        files.append({
            "path": rel,
            "type": p.suffix.lower().lstrip(".") or "file",
            "role": roles.get(rel, "Supporting file"),
            "bytes": p.stat().st_size,
            "sha256": sha256(p),
            "limits": limits.get(group, "See README.md for package-level limits."),
        })
    inventory = {
        "package": "SealForge corporate identity extension",
        "generated_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "brand_root": brand.root.name,
        "brand_manifest_verified": all(c.get("manifest_match") for c in brand.checks),
        "canonical_assets": brand.checks,
        "file_count": len(files),
        "files": files,
        "known_limits": [
            "Microsoft Office was not available in the build environment; native Office fidelity is unverified.",
            "LibreOffice 24.2.7.2 was used for visual render checks; Word and PowerPoint may reflow text differently.",
            "No CMYK conversion, ICC output intent or commercial print proof is supplied; the print PDF is RGB.",
            "No trademark clearance, certification, customer evidence or commercial claim is included.",
            "The Inter font is not embedded in DOCX/PPTX; install it or accept the documented fallback.",
            "Deliverables are byte-stable in this environment; verification logs and inventory carry timestamps. Opening and saving in Office changes package metadata and hashes.",
        ],
        "verification": {
            "summary": "../verification/checks.json",
            "renders": "../verification/renders/",
            "logs": "../verification/render.log",
        },
        "checks": checks,
    }
    out.write_text(json.dumps(inventory, indent=2, ensure_ascii=False) + "\n", "utf-8")
    return inventory
