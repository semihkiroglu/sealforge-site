# SealForge brand production

This is developer tooling. The application serves committed files; it never generates logos, starts Python, prints PDFs or sends email.

## Sources

- `source/master.svg`: approved profile seal, real key grip and small document press. The organic contour uses cleaned Bézier paths; the paper, shaft, press, separate ink line and impression circle use explicit vector geometry.
- `source/head.svg`: the same face and contour with a tangent-matched neck closure. It is not a separate mascot or a head/tool/paper scene. Keep its face synchronized when editing the master.
- `source/approved-reference.png`: the approved Round 8 raster reference, not the export source.
- `source/Inter.ttf`, `source/OFL.txt`: licensed variable Inter and its OFL license. Wordmark lettering is outlined at weight 500; consumers do not need fonts to display the logo.

All variants, PNGs and vector PDFs are generated from these SVGs. The full key and full press remain petrol; only the separate under-press line and impression are copper. Small 16/24 px derivatives receive optical stroke compensation without changing the character.

## Regenerate

Use Python 3.11+ with `requirements.txt`. PDF generation additionally needs Node.js, Playwright 1.56.0 and an installed Chromium. `NODE_PATH` may point at an existing Playwright installation; `CHROMIUM_PATH` selects its browser binary when it is outside the default Playwright cache.

```bash
python -m pip install -r tools/branding/requirements.txt
python tools/branding/mark.py --assets-only
```

The asset-only step prepares artwork and local fonts before document editing. The normal command also prints both HTML documents, validates their resources/page counts, creates the hash manifest and complete ZIP, and copies identical bytes to the existing product site:

```bash
python tools/branding/mark.py --site ../sealforge-site
python tools/branding/test_branding.py
```

Corporate templates are kept separately under `corporate/`; their generation
source and usage instructions live there. To build the complete identity and
its focused stationery, digital and editable-source archives:

```bash
python tools/branding/package_corporate.py --output /path/to/downloads --site ../sealforge-site
SEALFORGE_DOWNLOADS=/path/to/downloads python tools/branding/test_corporate.py
```

Omit `--site` when only the product kit should change. Site HTML and CSS are maintained separately; synchronization never commits or publishes either repository.

## Outputs and checks

`branding/` contains ready-to-use files, aligned editable body/copper layers, masters, palette/viewBox data, full font source/license, editable document HTML, PDFs, `manifest.json` and `sealforge-brand-kit.zip`. `wwwroot` receives only the static runtime subset. Edit canonical sources rather than generated files.

The checks cover requested formats/sizes, transparent padding, font-free/self-contained SVGs, matching theme geometry, exact ICO PNG entries, actual face continuity, paper joins and hollow-stem occlusion, centered ink, sampled contrast, full local font coverage, runtime-copy identity and ZIP/manifest byte integrity. Token/component sampling is not whole-app accessibility certification, physical signing proof, trademark clearance or calibrated CMYK prepress validation.
