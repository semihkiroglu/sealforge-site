"""Export the owner-approved Cove identity as committed static files, never at runtime.

--assets-only prepares artwork/font inputs for document authoring. A complete run
prints the supplied document sources, hashes the kit and writes the ZIP.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
from xml.etree import ElementTree as ET
import zipfile

import cairosvg
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
from PIL import ImageFont

ROOT=Path(__file__).resolve().parents[2]
SOURCE=Path(__file__).with_name('source')/'cove'
KIT=ROOT/'branding-cove'
ASSETS=KIT/'assets'
PUBLIC='https://semihkiroglu.github.io/sealforge-site/'
NS='http://www.w3.org/2000/svg'
ET.register_namespace('',NS)


def svg(width:int,height:int,body:str,viewbox:str|None=None)->str:
    return f'<svg xmlns="{NS}" width="{width}" height="{height}" viewBox="{viewbox or f"0 0 {width} {height}"}" role="img" aria-label="SealForge">{body}</svg>\n'


def geometry()->str:
    # Only the repository-owned, locally traced master is parsed, never uploaded XML.
    root=ET.fromstring((SOURCE/'master.svg').read_text())
    assert root.attrib['viewBox']=='0 0 1024 1024'
    for node in root.iter():
        if node.tag.rsplit('}',1)[-1] in {'image','text','script','foreignObject'} or any(k.endswith('href') for k in node.attrib):
            raise ValueError('Cove artwork must contain only self-contained vector geometry')
    return ''.join(ET.tostring(n,encoding='unicode') for n in root if n.tag.rsplit('}',1)[-1] not in {'title','desc'})


def luminance(colour:str)->float:
    values=[int(colour[i:i+2],16)/255 for i in (1,3,5)]
    return sum(w*(v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4) for w,v in zip((.2126,.7152,.0722),values))


def contrast(a:str,b:str)->float:
    low,high=sorted((luminance(a),luminance(b)))
    return (high+.05)/(low+.05)


def manifest()->list[Path]:
    files=sorted(p for p in KIT.rglob('*') if p.is_file() and p.suffix!='.zip' and p.name!='manifest.json')
    (KIT/'manifest.json').write_text(json.dumps({str(p.relative_to(KIT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2)+'\n')
    return files


def main()->None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--assets-only',action='store_true')
    parser.add_argument('--sync-app',action='store_true',help='Copy the approved static files into the existing app')
    parser.add_argument('--site',type=Path,help='Copy the COMPLETE kit into the existing public site')
    args=parser.parse_args()
    if args.site and (args.assets_only or not (args.site/'index.html').is_file()):
        parser.error('--site requires a complete kit and an existing site')
    for p in (ASSETS,KIT/'raw/fonts',KIT/'docs/fonts'):p.mkdir(parents=True,exist_ok=True)
    data=json.loads((SOURCE/'palette.json').read_text());palette=data['palette'];art=geometry()
    font=instantiateVariableFont(TTFont(SOURCE/'Manrope.ttf',recalcTimestamp=False),{'wght':600})
    measuring=ImageFont.truetype(str(SOURCE/'Manrope.ttf'),1000);measuring.set_variation_by_axes([600])
    tracking=-.018

    def width(text:str,size:float)->float:
        return measuring.getlength(text)*size/1000+max(0,len(text)-1)*size*tracking

    def word(text:str,size:float,x:float,y:float,colour:str)->str:
        glyphs,cmap=font.getGlyphSet(),font.getBestCmap();pen=SVGPathPen(glyphs);scale=size/font['head'].unitsPerEm
        for i,char in enumerate(text):
            start=(measuring.getlength(text[:i+1])-measuring.getlength(char))*size/1000+i*size*tracking
            glyphs[cmap[ord(char)]].draw(TransformPen(pen,(scale,0,0,-scale,x+start,y)))
        return f'<path fill="{colour}" d="{pen.getCommands()}"/>'

    def placed(x:float,y:float,size:float,colour:str)->str:
        return f'<g transform="translate({x:g} {y:g}) scale({size/1024:.8f})">{art.replace("#316b73",colour)}</g>'

    def emit(name:str,content:str,png:int=0,pdf:bool=False)->None:
        file=ASSETS/(name+'.svg');file.write_text(content)
        if png:cairosvg.svg2png(bytestring=content.encode(),write_to=str(file.with_suffix('.png')),output_width=png)
        if pdf:cairosvg.svg2pdf(bytestring=content.encode(),write_to=str(file.with_suffix('.pdf')))

    variants={'on-light':(palette['light']['primary'],palette['light']['ink']),'on-dark':(palette['dark']['primary'],palette['dark']['ink']),'black':('#000000','#000000'),'white':('#ffffff','#ffffff')}
    lockup_width=round(126+width('SealForge',54)+18)
    for name,(ink,text) in variants.items():
        symbol=svg(1024,1024,art.replace('#316b73',ink))
        emit('symbol-'+name,symbol,1024,True)
        emit('head-'+name,symbol,1024)
        emit('logo-'+name,svg(lockup_width,112,placed(0,0,112,ink)+word('SealForge',54,126,75,text)),1200,True)
        emit('logo-stacked-'+name,svg(280,294,placed(30,0,220,ink)+word('SealForge',42,(280-width('SealForge',42))/2,265,text)),1200,True)
    emit('wordmark-on-light',svg(round(width('SealForge',54)+24),80,word('SealForge',54,12,59,palette['light']['ink'])),1200,True)
    emit('wordmark-on-dark',svg(round(width('SealForge',54)+24),80,word('SealForge',54,12,59,palette['dark']['ink'])),1200,True)

    background=f'<rect width="64" height="64" rx="14" fill="{palette["dark"]["background"]}"/>'
    icon=svg(64,64,background+placed(0,0,64,palette['dark']['primary']))
    emit('app-icon',icon,1024)
    emit('app-icon-maskable',svg(64,64,f'<rect width="64" height="64" fill="{palette["dark"]["background"]}"/>'+placed(8,8,48,palette['dark']['primary'])),512)
    (ASSETS/'icon-16.svg').write_text(icon)
    for px in (16,24,32,48,64,128,180,192,256,512,1024):
        cairosvg.svg2png(bytestring=icon.encode(),write_to=str(ASSETS/f'icon-{px}.png'),output_width=px,output_height=px)
    sizes=(16,32,48,64);offset=6+16*len(sizes);directory=b'';payload=b''
    for px in sizes:
        raw=(ASSETS/f'icon-{px}.png').read_bytes();directory+=struct.pack('<BBBBHHII',px,px,0,0,1,32,len(raw),offset);payload+=raw;offset+=len(raw)
    (ASSETS/'favicon.ico').write_bytes(struct.pack('<HHH',0,1,len(sizes))+directory+payload)

    email_width=round(116+width('SealForge',46)+16)
    emit('email-logo',svg(email_width,100,f'<rect width="{email_width}" height="100" rx="8" fill="#ffffff"/>'+placed(2,0,100,palette['light']['primary'])+word('SealForge',46,116,67,palette['light']['ink'])),email_width*2)
    (ASSETS/'email-signature.html').write_text(f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><title>SealForge email signature</title></head><body>
<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="font-family:Arial,Helvetica,sans-serif;color:#203033;background:#ffffff;width:100%;max-width:380px"><tr><td style="padding:0 0 10px"><a href="{PUBLIC}"><img src="{PUBLIC}assets/brand/email-logo.png" width="260" height="{round(26000/email_width)}" alt="SealForge" style="display:block;border:0;width:260px;max-width:100%;height:auto"></a></td></tr><tr><td style="padding:0 12px 8px;font-size:13px;line-height:20px;color:#56666a">Self-hosted code signing.<br>Your keys. Your signature.</td></tr><tr><td style="padding:0 12px 12px;font-size:13px;line-height:20px"><a href="{PUBLIC}" style="color:#316b73;text-decoration:underline">Explore SealForge</a></td></tr></table></body></html>\n''')
    social=f'<rect width="1200" height="630" fill="{palette["dark"]["background"]}"/>'+word('SealForge',66,72,145,palette['dark']['ink'])+word('Your keys.',51,72,292,palette['dark']['ink'])+word('Your signature.',51,72,361,palette['dark']['primary'])+word('Self-hosted code signing',24,72,469,palette['dark']['muted'])+f'<path d="M72 516H242" fill="none" stroke="{palette["dark"]["copper"]}" stroke-width="3"/>'+placed(650,72,500,palette['dark']['primary'])
    emit('social-card',svg(1200,630,social),1200)
    (ASSETS/'palette.json').write_text(json.dumps(data,indent=2)+'\n')
    pairs=[]
    for mode,t in palette.items():
        for title,fg,bg,minimum in [('Body / page','ink','background',4.5),('Secondary / page','muted','background',4.5),('Link / page','primary','background',4.5),('Copper / page','copper','background',4.5),('Body / card','ink','surface',4.5),('Secondary / card','muted','surface',4.5),('Primary label','onPrimary','primary',4.5),('Primary hover label','onPrimary','hover',4.5),('Input / card','inputBorder','surface',3),('Input / page','inputBorder','background',3)]:
            ratio=contrast(t[fg],t[bg]);assert ratio>=minimum;pairs.append({'mode':mode,'pair':title,'foreground':t[fg],'background':t[bg],'ratio':round(ratio,4),'required':minimum})
        for role,value in data['semantic'][mode].items():
            ratio=contrast(value['label'],value['fill']);assert ratio>=4.5;pairs.append({'mode':mode,'pair':role+' filled label','foreground':value['label'],'background':value['fill'],'ratio':round(ratio,4),'required':4.5})
    (ASSETS/'contrast.json').write_text(json.dumps({'method':'WCAG sRGB token pairs, not whole-application certification','pairs':pairs},indent=2)+'\n')
    for filename in ('master.svg','approved-reference.png','geometry.json','palette.json'):shutil.copyfile(SOURCE/filename,KIT/'raw'/filename)
    shutil.copyfile(SOURCE/'master.svg',KIT/'raw/head.svg')
    for family in ('Manrope','Inter'):
        variable=TTFont(SOURCE/(family+'.ttf'),recalcTimestamp=False);variable.flavor='woff2';variable.save(ASSETS/(family.lower()+'.woff2'))
        shutil.copyfile(SOURCE/(family+'.ttf'),KIT/'raw/fonts'/(family+'.ttf'))
        shutil.copyfile(ASSETS/(family.lower()+'.woff2'),KIT/'docs/fonts'/(family.lower()+'.woff2'))
    for name in ('OFL.txt','OFL-Manrope.txt'):
        shutil.copyfile(SOURCE/name,KIT/'raw/fonts'/name);shutil.copyfile(SOURCE/name,KIT/'docs/fonts'/name)
    (ASSETS/'FONT-LICENSE.txt').write_text('Manrope\n\n'+(SOURCE/'OFL-Manrope.txt').read_text()+'\n\nInter\n\n'+(SOURCE/'OFL.txt').read_text())
    if args.sync_app:
        web=ROOT/'src/SealForge.Web/wwwroot';(web/'brand').mkdir(exist_ok=True)
        for name in ('logo-on-light.svg','logo-on-dark.svg','symbol-on-light.svg','symbol-on-dark.svg','head-on-light.svg','head-on-dark.svg','icon-192.png','icon-512.png','inter.woff2','manrope.woff2','FONT-LICENSE.txt'):shutil.copyfile(ASSETS/name,web/'brand'/name)
        for target,source in {'favicon.svg':'icon-16.svg','favicon.png':'icon-64.png','favicon.ico':'favicon.ico','apple-touch-icon.png':'icon-180.png','mark.svg':'symbol-on-light.svg'}.items():shutil.copyfile(ASSETS/source,web/target)
    files=manifest()
    if args.assets_only:
        print(json.dumps({'phase':'assets','identity':'Cove','assets':len(list(ASSETS.iterdir())),'root':str(KIT),'syncApp':args.sync_app}));return
    for name in ('brand-guidelines','letterhead'):
        if not (KIT/f'docs/{name}.html').is_file():raise SystemExit(f'Missing document source: {name}.html')
    if not (KIT/'README.md').is_file():raise SystemExit('Missing Cove README.md')
    subprocess.run(['node',str(Path(__file__).with_name('print_docs.cjs')),'--brand-root',str(KIT)],check=True,env=os.environ)
    files=manifest()
    archive=KIT/'sealforge-brand-kit.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as bundle:
        for file in files+[KIT/'manifest.json']:bundle.write(file,file.relative_to(KIT))
    if args.site:
        site=args.site.resolve();(site/'assets/brand').mkdir(exist_ok=True);(site/'assets/downloads').mkdir(exist_ok=True)
        for file in ASSETS.iterdir():shutil.copyfile(file,site/'assets/brand'/file.name)
        for target,source in {'mark.svg':'symbol-on-light.svg','favicon.svg':'icon-16.svg','favicon-32.png':'icon-32.png','apple-touch-icon.png':'icon-180.png','icon-512.png':'icon-512.png','og.png':'social-card.png','favicon.ico':'favicon.ico'}.items():shutil.copyfile(ASSETS/source,site/'assets/img'/target)
        shutil.copyfile(ASSETS/'manrope.woff2',site/'assets/fonts/manrope.woff2')
        shutil.copyfile(archive,site/'assets/downloads'/archive.name)
        for name in ('brand-guidelines','letterhead'):shutil.copyfile(KIT/f'docs/{name}.pdf',site/f'assets/downloads/sealforge-{name}.pdf')
    print(json.dumps({'identity':'Cove','files':len(files)+1,'archiveBytes':archive.stat().st_size,'site':str(args.site) if args.site else None,'syncApp':args.sync_app}))

if __name__=='__main__':main()
