"""Generate static SealForge branding from the approved editable SVG masters.

Run with --assets-only before editing/printing documents; the normal command
regenerates assets, PDFs, the manifest and the complete ZIP. Never runs in the app.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
from xml.etree import ElementTree as ET
import zipfile

import cairosvg
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
from PIL import ImageFont

ROOT=Path(__file__).resolve().parents[2]
SOURCE=Path(__file__).resolve().parent/'source'
KIT=ROOT/'branding'
ASSETS=KIT/'assets'
WEB=ROOT/'src/SealForge.Web/wwwroot'
PUBLIC='https://semihkiroglu.github.io/sealforge-site/'
NS='http://www.w3.org/2000/svg'
ET.register_namespace('',NS)
PALETTE={
 'light':{'background':'#f7f8f5','surface':'#ffffff','ink':'#203033','muted':'#56666a','primary':'#316b73','hover':'#28626a','copper':'#9f542e','line':'#d8e1de','soft':'#ebf2ef','onPrimary':'#ffffff','inputBorder':'#7a8a8c'},
 'dark':{'background':'#151b1d','surface':'#1c2426','ink':'#eef5f3','muted':'#a7bcbb','primary':'#87c2c6','hover':'#a6d5d6','copper':'#e5ad7d','line':'#33454a','soft':'#243033','onPrimary':'#151b1d','inputBorder':'#7e8f94'},
}
SEMANTIC={
 'light':{'success':'#236a45','error':'#a42c37','warning':'#865111','info':'#2b638a'},
 'dark':{'success':'#91d2aa','error':'#f29ca5','warning':'#e2bc74','info':'#9dc6e3'},
}


def svg(width: int, height: int, body: str, viewbox: str|None=None) -> str:
    return f'<svg xmlns="{NS}" width="{width}" height="{height}" viewBox="{viewbox or f"0 0 {width} {height}"}" role="img" aria-label="SealForge">{body}</svg>\n'


def geometry(name: str) -> tuple[tuple[float,...],str]:
    # Only parses the local, repository-owned canonical master; reject active/external content.
    root=ET.fromstring((SOURCE/name).read_text())
    for node in root.iter():
        if node.tag.rsplit('}',1)[-1] in {'script','image','text','foreignObject'}:
            raise ValueError(f'{name}: artwork must be self-contained vector paths')
        if any(k.endswith('href') or 'http:' in v or 'https:' in v or 'data:' in v for k,v in node.attrib.items()):
            raise ValueError(f'{name}: external references are not allowed')
    box=tuple(map(float,root.attrib['viewBox'].split()))
    body=''.join(ET.tostring(n,encoding='unicode') for n in root if n.tag.rsplit('}',1)[-1] not in {'title','desc'})
    return box,body


def placed(fragment: str, box: tuple[float,...], x: float,y: float,height: float,primary: str,copper: str) -> str:
    scale=height/box[3]
    art=fragment.replace('#316b73',primary).replace('#9f542e',copper)
    return f'<g transform="translate({x:g} {y:g}) scale({scale:.8f}) translate({-box[0]:g} {-box[1]:g})">{art}</g>'


def luminance(h: str) -> float:
    v=[int(h[i:i+2],16)/255 for i in (1,3,5)]
    return sum(w*(n/12.92 if n<=.04045 else ((n+.055)/1.055)**2.4) for w,n in zip((.2126,.7152,.0722),v))


def contrast(a: str,b: str) -> float:
    x,y=sorted((luminance(a),luminance(b)))
    return (y+.05)/(x+.05)


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--assets-only',action='store_true',help='Prepare SVG/raster/font assets before document generation')
    parser.add_argument('--site',type=Path,help='Synchronize the completed kit into the existing product site')
    args=parser.parse_args()
    if args.site and not (args.site/'index.html').is_file():parser.error('--site must point to the existing product site')
    if args.site and args.assets_only:parser.error('Site publication requires the complete kit')
    for p in (ASSETS,KIT/'raw',KIT/'docs/fonts',WEB/'brand'):p.mkdir(parents=True,exist_ok=True)
    box,mark=geometry('master.svg');hb,head=geometry('head.svg')
    font=instantiateVariableFont(TTFont(SOURCE/'Inter.ttf'),{'wght':500,'opsz':24})
    measuring=ImageFont.truetype(str(SOURCE/'Inter.ttf'),1000);measuring.set_variation_by_axes([24,500])

    def text_paths(text: str,size: float,x: float,baseline: float) -> str:
        glyphs,cmap=font.getGlyphSet(),font.getBestCmap();pen=SVGPathPen(glyphs)
        scale=size/font['head'].unitsPerEm
        for i,char in enumerate(text):
            # Pillow uses the same shaping/kerning as the approved wordmark.
            start=measuring.getlength(text[:i+1])-measuring.getlength(char)
            glyphs[cmap[ord(char)]].draw(TransformPen(pen,(scale,0,0,-scale,x+start*size/1000,baseline)))
        return pen.getCommands()

    def word(text: str,size: float,x: float,y: float,color: str) -> str:
        return f'<path fill="{color}" d="{text_paths(text,size,x,y)}"/>'

    def emit(name: str,content: str,png_width: int=0,pdf: bool=False) -> None:
        target=ASSETS/(name+'.svg');target.write_text(content)
        if png_width:cairosvg.svg2png(bytestring=content.encode(),write_to=str(target.with_suffix('.png')),output_width=png_width)
        if pdf:cairosvg.svg2pdf(bytestring=content.encode(),write_to=str(target.with_suffix('.pdf')))

    variants={
      'on-light':(PALETTE['light']['primary'],PALETTE['light']['copper'],PALETTE['light']['ink']),
      'on-dark':(PALETTE['dark']['primary'],PALETTE['dark']['copper'],PALETTE['dark']['ink']),
      'black':('#000000','#000000','#000000'),'white':('#ffffff','#ffffff','#ffffff'),
    }
    for name,(primary,copper,ink) in variants.items():
        emit('symbol-'+name,svg(round(box[2]),round(box[3]),mark.replace('#316b73',primary).replace('#9f542e',copper),' '.join(f'{v:g}' for v in box)),1024,True)
        lockup=placed(mark,box,8,5,78,primary,copper)+word('SealForge',42,128,59,ink)
        emit('logo-'+name,svg(330,88,lockup),1200,True)
        width=box[2]*140/box[3]
        text_width=measuring.getlength('SealForge')*34/1000
        stacked=placed(mark,box,(260-width)/2,12,140,primary,copper)+word('SealForge',34,(260-text_width)/2,202,ink)
        emit('logo-stacked-'+name,svg(260,224,stacked),1200,True)
        emit('head-'+name,svg(round(hb[2]),round(hb[3]),head.replace('#316b73',primary),' '.join(f'{v:g}' for v in hb)),512)

    def head_in_square(color: str,size: float,hint: float=0) -> str:
        height=size*hb[3]/hb[2]
        fragment=head.replace('#316b73',color)
        fragment=f'<g stroke="{color}" stroke-width="{hint:g}" stroke-linejoin="round">{fragment}</g>'
        return placed(fragment,hb,(64-size)/2,(64-height)/2,height,color,color)

    background=f'<rect width="64" height="64" rx="14" fill="{PALETTE["dark"]["background"]}"/>'
    emit('app-icon',svg(64,64,background+head_in_square(PALETTE['dark']['primary'],48)),1024)
    emit('app-icon-maskable',svg(64,64,f'<rect width="64" height="64" fill="{PALETTE["dark"]["background"]}"/>'+head_in_square(PALETTE['dark']['primary'],38)),512)
    for px in (16,24,32,48,64,128,180,192,256,512,1024):
        hint=26 if px==16 else 7 if px==24 else 0
        content=svg(64,64,background+head_in_square(PALETTE['dark']['primary'],48,hint))
        if px==16:(ASSETS/'icon-16.svg').write_text(content)
        cairosvg.svg2png(bytestring=content.encode(),write_to=str(ASSETS/f'icon-{px}.png'),output_width=px,output_height=px)
    sizes=(16,32,48,64);header=struct.pack('<HHH',0,1,len(sizes));offset=6+16*len(sizes);directory=b'';payload=b''
    for px in sizes:
        data=(ASSETS/f'icon-{px}.png').read_bytes();directory+=struct.pack('<BBBBHHII',px,px,0,0,1,32,len(data),offset);payload+=data;offset+=len(data)
    (ASSETS/'favicon.ico').write_bytes(header+directory+payload)

    email=svg(324,88,'<rect width="324" height="88" rx="8" fill="white"/>'+placed(mark,box,12,9,70,PALETTE['light']['primary'],PALETTE['light']['copper'])+word('SealForge',39,120,58,PALETTE['light']['ink']))
    emit('email-logo',email,648)
    (ASSETS/'email-signature.html').write_text(f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><title>SealForge email signature</title></head><body>
<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="font-family:Arial,Helvetica,sans-serif;color:#203033;background:#ffffff;max-width:380px">
<tr><td style="padding:0 0 10px"><a href="{PUBLIC}"><img src="{PUBLIC}assets/brand/email-logo.png" width="243" height="66" alt="SealForge" style="display:block;border:0;width:243px;height:66px"></a></td></tr>
<tr><td style="padding:0 12px 8px;font-size:13px;line-height:20px;color:#56666a">Self-hosted code signing.<br>Your keys. Your signature. Your signing workshop.</td></tr>
<tr><td style="padding:0 12px 12px;font-size:13px;line-height:20px"><a href="{PUBLIC}" style="color:#316b73;text-decoration:underline">Explore SealForge</a></td></tr></table></body></html>\n''')
    social=(f'<rect width="1200" height="630" fill="{PALETTE["dark"]["background"]}"/>'
            +word('SealForge',64,72,124,PALETTE['dark']['ink'])
            +word('Your signing',54,72,280,PALETTE['dark']['ink'])
            +word('workshop.',54,72,350,PALETTE['dark']['primary'])
            +word('Self-hosted code signing',24,72,450,PALETTE['dark']['muted'])
            +word('Your keys. Your signature.',24,72,498,PALETTE['dark']['muted'])
            +placed(mark,box,620,122,410,PALETTE['dark']['primary'],PALETTE['dark']['copper']))
    emit('social-card',svg(1200,630,social),1200)

    data={'status':'approved','palette':PALETTE,'semantic':{mode:{role:{'fill':color,'label':'#ffffff' if mode=='light' else '#151b1d'} for role,color in roles.items()} for mode,roles in SEMANTIC.items()},'master':'raw/master.svg','head':'raw/head.svg','note':'The full key and press stay petrol. Only the added under-press line and the impression are copper. Decorative lines and input boundaries are different tokens.'}
    (ASSETS/'palette.json').write_text(json.dumps(data,indent=2)+'\n')
    pairs=[]
    for mode,t in PALETTE.items():
        for title,fg,bg,minimum in [('Body / page','ink','background',4.5),('Secondary / page','muted','background',4.5),('Link / page','primary','background',4.5),('Copper / page','copper','background',4.5),('Body / card','ink','surface',4.5),('Secondary / card','muted','surface',4.5),('Primary label','onPrimary','primary',4.5),('Primary hover label','onPrimary','hover',4.5),('Input / card','inputBorder','surface',3),('Input / page','inputBorder','background',3)]:
            value=contrast(t[fg],t[bg]);assert value>=minimum,(mode,title,value)
            pairs.append({'mode':mode,'pair':title,'foreground':t[fg],'background':t[bg],'ratio':round(value,4),'required':minimum})
        for role,color in SEMANTIC[mode].items():
            label='#ffffff' if mode=='light' else '#151b1d';value=contrast(label,color);assert value>=4.5
            pairs.append({'mode':mode,'pair':role+' filled label','foreground':label,'background':color,'ratio':round(value,4),'required':4.5})
    (ASSETS/'contrast.json').write_text(json.dumps({'method':'WCAG sRGB relative luminance; sampled token pairs, not whole-application certification','pairs':pairs},indent=2)+'\n')
    variable=TTFont(SOURCE/'Inter.ttf',recalcTimestamp=False);variable.flavor='woff2';variable.save(ASSETS/'inter.woff2')
    shutil.copyfile(SOURCE/'OFL.txt',ASSETS/'FONT-LICENSE.txt')
    for name in ('master.svg','head.svg','approved-reference.png'):
        shutil.copyfile(SOURCE/name,KIT/'raw'/name)
    # Same registration for both editable ink layers; never re-trace individual exports.
    master_root=ET.fromstring((SOURCE/'master.svg').read_text())
    for name,is_copper in (('body',False),('copper',True)):
        layer=''.join(ET.tostring(n,encoding='unicode') for n in master_root if n.tag.endswith('g') and (n.attrib.get('id') in {'ink-line','imprint'})==is_copper)
        (KIT/f'raw/{name}.svg').write_text(svg(round(box[2]),round(box[3]),layer,' '.join(f'{v:g}' for v in box)))
    (KIT/'raw/geometry.json').write_text(json.dumps({'masterViewBox':box,'headViewBox':hb,'approvalRound':8,'method':'Clean fitted Bezier seal/face/signature with analytic paper, key shaft, press and imprint circle','referenceSha256':hashlib.sha256((SOURCE/'approved-reference.png').read_bytes()).hexdigest()},indent=2)+'\n')
    shutil.copyfile(ASSETS/'palette.json',KIT/'raw/palette.json')
    (KIT/'raw/fonts').mkdir(exist_ok=True)
    for name in ('Inter.ttf','OFL.txt'):shutil.copyfile(SOURCE/name,KIT/'raw/fonts'/name)
    shutil.copyfile(ASSETS/'inter.woff2',KIT/'docs/fonts/inter.woff2')
    shutil.copyfile(SOURCE/'OFL.txt',KIT/'docs/fonts/OFL.txt')
    for name in ('logo-on-light.svg','logo-on-dark.svg','symbol-on-light.svg','symbol-on-dark.svg','head-on-light.svg','head-on-dark.svg','icon-192.png','icon-512.png','inter.woff2'):
        shutil.copyfile(ASSETS/name,WEB/'brand'/name)
    for target,source in {'favicon.svg':'icon-16.svg','favicon.png':'icon-64.png','favicon.ico':'favicon.ico','apple-touch-icon.png':'icon-180.png','mark.svg':'symbol-on-light.svg'}.items():
        shutil.copyfile(ASSETS/source,WEB/target)
    if args.assets_only:
        print(f'Assets prepared: {len(list(ASSETS.iterdir()))}; complete bundle requires document generation.')
        return
    for name in ('brand-guidelines','letterhead'):
        if not (KIT/f'docs/{name}.html').is_file():raise SystemExit(f'Missing document source: {name}.html')
    subprocess.run(['node',str(Path(__file__).with_name('print_docs.cjs'))],check=True,env=os.environ)
    if not (KIT/'README.md').is_file():raise SystemExit('Missing package README.md')
    files=sorted(p for p in KIT.rglob('*') if p.is_file() and p.suffix!='.zip' and p.name!='manifest.json')
    manifest={str(p.relative_to(KIT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    (KIT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    archive=KIT/'sealforge-brand-kit.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as bundle:
        for p in files+[KIT/'manifest.json']:bundle.write(p,p.relative_to(KIT))
    if args.site:
        site=args.site.resolve();(site/'assets/brand').mkdir(parents=True,exist_ok=True);(site/'assets/downloads').mkdir(parents=True,exist_ok=True)
        for p in ASSETS.iterdir():
            if p.is_file():shutil.copyfile(p,site/'assets/brand'/p.name)
        for target,source in {'mark.svg':'symbol-on-light.svg','favicon.svg':'icon-16.svg','favicon-32.png':'icon-32.png','apple-touch-icon.png':'icon-180.png','icon-512.png':'icon-512.png','og.png':'social-card.png','favicon.ico':'favicon.ico'}.items():
            shutil.copyfile(ASSETS/source,site/'assets/img'/target)
        shutil.copyfile(archive,site/'assets/downloads'/archive.name)
        for name in ('brand-guidelines','letterhead'):shutil.copyfile(KIT/f'docs/{name}.pdf',site/f'assets/downloads/sealforge-{name}.pdf')
    print(json.dumps({'files':len(manifest)+1,'archiveBytes':archive.stat().st_size,'archive':str(archive),'site':str(args.site) if args.site else None}))

if __name__=='__main__':main()
