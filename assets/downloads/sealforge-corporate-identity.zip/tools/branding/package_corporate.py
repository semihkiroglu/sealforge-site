#!/usr/bin/env python3
"""Package the approved artwork and corporate templates; never runs in the app."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[2]
ARCHIVES = ('sealforge-corporate-identity.zip', 'sealforge-stationery.zip',
            'sealforge-digital-kit.zip', 'sealforge-editable-sources.zip')


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def collect(root: Path, prefix: str) -> dict[str, bytes]:
    result = {}
    for p in sorted(root.rglob('*')):
        if not p.is_file():
            continue
        relative = p.relative_to(root)
        if any(part.startswith('.') or part in {'__pycache__', 'bin', 'obj', 'node_modules'} for part in relative.parts):
            continue
        if p.suffix in {'.zip', '.pyc'}:
            continue
        if p.is_symlink():
            raise ValueError(f'Symlinks are not distributable: {relative}')
        if p.suffix in {'.cs', '.razor', '.csproj', '.pfx', '.key', '.db'}:
            raise ValueError(f'Product source or sensitive material is outside package scope: {relative}')
        result[f'{prefix}/{relative.as_posix()}'] = p.read_bytes()
    return result


def write_archive(path: Path, payload: dict[str, bytes]) -> dict:
    if 'manifest.json' in payload:
        raise ValueError('The top-level manifest is reserved')
    for name in payload:
        p = PurePosixPath(name)
        if p.is_absolute() or '..' in p.parts or '\\' in name:
            raise ValueError(f'Unsafe archive name: {name}')
    manifest = {name: digest(data) for name, data in sorted(payload.items())}
    entries = {**payload, 'manifest.json': (json.dumps(manifest, indent=2, ensure_ascii=False) + '\n').encode()}
    with zipfile.ZipFile(path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, data in sorted(entries.items()):
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    with zipfile.ZipFile(path) as z:
        if len(z.namelist()) != len(set(z.namelist())) or z.testzip() is not None:
            raise ValueError(f'Invalid ZIP: {path.name}')
        assert set(z.namelist()) == set(entries)
        for name, data in entries.items():
            assert z.read(name) == data, name
    return {'bytes': path.stat().st_size, 'files': len(entries), 'sha256': digest(path.read_bytes())}


def overview() -> bytes:
    return '''# SealForge corporate identity

The approved profile seal, ready-to-use assets and editable sources in one set.
This is an identity package, not the product installer or application source code.

## Start here

- `branding/README.md`: variants, colours, compact headers and file selection.
- `branding/docs/brand-guidelines.pdf`: the nine-page brand guide.
- `branding/docs/letterhead.pdf`: A4 stationery; editable HTML is alongside it.
- `corporate/office/`: editable Word letterhead/report and PowerPoint presentation.
- `corporate/print/`: business-card SVG sources and print PDFs.
- `corporate/digital/`: avatar, cover, post and personal email-signature template.
- `corporate/digital/product/`: current component-preview PNG/WebP files and capture provenance.
- `corporate/README.md`: template usage and actual verification limits.
- `corporate/source/`: reproducible template generation and dependencies.
- `tools/branding/`: canonical artwork export and identity packaging tools.

Full artwork belongs in documents and editorial applications. Compact application
and website headers use the same head with modest live SealForge text. They do not
repeat it inside the login card or modify the full outlined logo artwork.

## Editing

The master is `branding/raw/master.svg`; the same head is `branding/raw/head.svg`.
Full logo lettering is outlined. To edit native Office files and live SVG text
consistently, install `branding/raw/fonts/Inter.ttf`. Keep its supplied OFL text
when redistributing font files.

Bracketed and double-braced fields are deliberate personalisation fields, not
real identities or contact details. Fill them before sending documents to others.
Business cards are RGB designs, not a calibrated CMYK, PDF/X or press-proof claim.

## Regeneration

These tools run only on a developer machine, never in the application runtime.

```bash
python -m pip install -r tools/branding/requirements.txt
# Document PDFs also require Node, Playwright and Chromium.
python tools/branding/mark.py
# Follow corporate/source/ instructions for the additional template dependencies.
python tools/branding/package_corporate.py --help
```

## Integrity and limits

The root `manifest.json` hashes every other file in this archive.
`branding/manifest.json` describes only the canonical artwork subtree.
Archives do not contain redundant ZIP-inside-ZIP bundles.

Native Office package validation is different from rendering in an Office
application. The actual checks and limitations are documented in
`corporate/README.md`. No real customer, sales or production-activity claim is made.
'''.encode()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--brand-root', type=Path, default=ROOT / 'branding')
    parser.add_argument('--extension-root', type=Path, default=ROOT / 'corporate')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--site', type=Path)
    args = parser.parse_args()
    brand, extension, output = args.brand_root.resolve(), args.extension_root.resolve(), args.output.resolve()
    if output.is_relative_to(brand) or output.is_relative_to(extension):
        parser.error('--output must be outside both input trees to prevent recursive packaging')
    for file in ('manifest.json', 'sealforge-brand-kit.zip', 'raw/master.svg', 'docs/brand-guidelines.pdf'):
        if not (brand / file).is_file():
            parser.error(f'Incomplete canonical brand kit: {file}')
    for file in ('README.md', 'office/sealforge-letterhead.docx', 'office/sealforge-report-template.docx', 'office/sealforge-presentation.pptx'):
        if not (extension / file).is_file():
            parser.error(f'Missing corporate deliverable: {file}')
    if not any((extension / 'print').glob('*.pdf')) or not any((extension / 'digital').rglob('*.png')):
        parser.error('Print PDF and digital raster deliverables are required')
    if not any((extension / 'source').glob('*.py')):
        parser.error('A reproducible corporate generation source is required')
    if args.site and not (args.site / 'index.html').is_file():
        parser.error('--site must be an existing product site')
    canonical = collect(brand, 'branding')
    stated = json.loads((brand / 'manifest.json').read_text())
    actual = {name.removeprefix('branding/'): digest(data) for name, data in canonical.items() if name != 'branding/manifest.json'}
    if stated != actual:
        raise ValueError('Canonical brand manifest is stale; regenerate it before packaging')
    extra = collect(extension, 'corporate')
    tools = {}
    for name in ('mark.py', 'print_docs.cjs', 'test_branding.py', 'test_corporate.py', 'requirements.txt', 'README.md', 'package_corporate.py'):
        p = ROOT / 'tools/branding' / name
        tools[f'tools/branding/{name}'] = p.read_bytes()
    for name in ('master.svg', 'head.svg', 'approved-reference.png', 'Inter.ttf', 'OFL.txt'):
        p = ROOT / 'tools/branding/source' / name
        tools[f'tools/branding/source/{name}'] = p.read_bytes()
    full = {**canonical, **extra, **tools, 'README.md': overview()}
    common = {name: data for name, data in canonical.items() if name.startswith(('branding/raw/fonts/', 'branding/docs/fonts/'))}
    common.update({name: data for name, data in extra.items() if name.startswith('corporate/fonts/')})
    common['corporate/README.md'] = extra['corporate/README.md']
    stationery = {**common, **{name: data for name, data in full.items() if name.startswith(('corporate/office/', 'corporate/print/', 'corporate/source/', 'branding/docs/'))}}
    # Include the exact image resources referenced by the supplied HTML documents.
    stationery.update({name: data for name, data in canonical.items() if name.startswith('branding/assets/')})
    stationery['README.md'] = '''# SealForge office and stationery

`corporate/office/`: editable Word letterhead/report and PowerPoint presentation.
`corporate/print/`: business-card artwork and print PDFs.
`branding/docs/`: brand guide, A4 letterhead and editable HTML sources.
Local document images, fonts and corporate generation sources are also included.

Personalise the template fields; no real contact details are invented.
Install branding/raw/fonts/Inter.ttf for consistent Office editing.
Business cards are RGB, not calibrated CMYK, PDF/X or press-proof deliverables.
Read corporate/README.md for usage and native Office rendering limits.
manifest.json hashes every other file in this archive with SHA-256.
'''.encode()
    digital = {**common, **{name: data for name, data in full.items() if name.startswith('corporate/digital/') or name in {'branding/assets/social-card.svg', 'branding/assets/social-card.png', 'branding/assets/email-logo.png', 'branding/assets/email-logo.svg', 'branding/assets/email-signature.html'}}}
    digital['README.md'] = '''# SealForge digital assets

corporate/digital/ contains the avatar, cover, post and personal email-signature
template. branding/assets/ contains the canonical social preview and brand-only
email signature. branding/raw/fonts/ contains the editing font and its OFL text.
Fill the personal template's double-braced fields; they are not real identities.
Check the plain text and links when a mail client blocks external images.
The application does not send mail; this is not a Gmail/Outlook delivery test.
Read corporate/README.md for usage and actual verification limits.
manifest.json provides SHA-256 values for every other file in this archive.
'''.encode()
    sources = {name: data for name, data in full.items() if (PurePosixPath(name).suffix.lower() not in {'.pdf', '.png', '.ico', '.webp'} or name.endswith('approved-reference.png')) and name not in {'branding/manifest.json', 'corporate/manifest.json', 'corporate/inventory.json'}}
    sources['README.md'] = '''# SealForge editable sources

branding/raw/ and tools/branding/source/ contain the approved seal and font.
branding/docs/ contains editable brand-guide and A4 letterhead HTML.
corporate/ contains native Office templates, editable SVG/HTML and generation
code. Product C#/Razor application source is not included.

Ready-made PDF and raster exports are deliberately omitted from this subset.
Run `python -m pip install -r tools/branding/requirements.txt`, then
`python tools/branding/mark.py` to rebuild canonical outputs. Document printing
also needs Node, Playwright and Chromium. Follow corporate/README.md and
corporate/source/ for corporate generation and Office dependencies. Keep the
supplied OFL text with redistributed font files.

Personalise template fields before use. Native Office rendering is different
from XML/package validation; actual limits are in corporate/README.md.
The root manifest.json hashes only the files actually present in THIS archive.
'''.encode()
    output.mkdir(parents=True, exist_ok=True)
    inventory = {}
    for name, payload in zip(ARCHIVES, (full, stationery, digital, sources), strict=True):
        inventory[name] = write_archive(output / name, payload)
    shutil.copyfile(brand / 'sealforge-brand-kit.zip', output / 'sealforge-brand-kit.zip')
    with zipfile.ZipFile(output / 'sealforge-brand-kit.zip') as z:
        inventory['sealforge-brand-kit.zip'] = {'bytes': (output / 'sealforge-brand-kit.zip').stat().st_size, 'files': len(z.namelist()), 'sha256': digest((output / 'sealforge-brand-kit.zip').read_bytes())}
    for name in ('brand-guidelines', 'letterhead'):
        destination = output / f'sealforge-{name}.pdf'
        shutil.copyfile(brand / f'docs/{name}.pdf', destination)
        inventory[destination.name] = {'bytes': destination.stat().st_size, 'sha256': digest(destination.read_bytes())}
    info = {'artwork': 'Approved Coast & Copper profile seal; canonical master geometry unchanged', 'files': inventory}
    (output / 'sealforge-downloads.json').write_text(json.dumps(info, indent=2, ensure_ascii=False) + '\n')
    if args.site:
        downloads = args.site.resolve() / 'assets/downloads'
        downloads.mkdir(parents=True, exist_ok=True)
        for name in [*inventory, 'sealforge-downloads.json']:
            shutil.copyfile(output / name, downloads / name)
    print(json.dumps({'output': str(output), 'site': str(args.site) if args.site else None, **info}, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
