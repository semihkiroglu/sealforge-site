#!/usr/bin/env python3
"""Package current Cove artwork and native corporate templates; no app runtime code."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import zipfile

ROOT=Path(__file__).resolve().parents[2]
BRAND='branding-cove'
ARCHIVES=('sealforge-corporate-identity.zip','sealforge-stationery.zip','sealforge-digital-kit.zip','sealforge-editable-sources.zip')


def digest(data:bytes)->str:
    return hashlib.sha256(data).hexdigest()


def collect(root:Path,prefix:str)->dict[str,bytes]:
    result={}
    for p in sorted(root.rglob('*')):
        if not p.is_file():continue
        relative=p.relative_to(root)
        if any(part.startswith('.') or part in {'__pycache__','bin','obj','node_modules'} for part in relative.parts):continue
        if p.suffix in {'.zip','.pyc'}:continue
        if p.is_symlink():raise ValueError(f'Symlinks are not distributable: {relative}')
        if p.suffix in {'.cs','.razor','.csproj','.pfx','.key','.db'}:
            raise ValueError(f'Product source or sensitive material is outside package scope: {relative}')
        result[f'{prefix}/{relative.as_posix()}']=p.read_bytes()
    return result


def write_archive(path:Path,payload:dict[str,bytes])->dict:
    if 'manifest.json' in payload:raise ValueError('The top-level manifest is reserved')
    for name in payload:
        p=PurePosixPath(name)
        if p.is_absolute() or '..' in p.parts or '\\' in name:raise ValueError(f'Unsafe archive name: {name}')
    manifest={name:digest(data) for name,data in sorted(payload.items())}
    entries={**payload,'manifest.json':(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n').encode()}
    with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as bundle:
        for name,data in sorted(entries.items()):
            info=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
            bundle.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    with zipfile.ZipFile(path) as bundle:
        if len(bundle.namelist())!=len(set(bundle.namelist())) or bundle.testzip() is not None:raise ValueError(f'Invalid ZIP: {path.name}')
        assert set(bundle.namelist())==set(entries)
        for name,data in entries.items():assert bundle.read(name)==data,name
    return {'bytes':path.stat().st_size,'files':len(entries),'sha256':digest(path.read_bytes())}


def overview()->bytes:
    return b'''# SealForge corporate identity - Cove

The owner-selected Cove emblem, production vector exports, native templates and
editable sources. One seal-head symbol throughout; no full-animal companion.
This is an identity package, not a product installer or application source.

## Start here

- `branding-cove/README.md`: artwork selection, colours, typography and limits.
- `branding-cove/docs/brand-guidelines.pdf`: the nine-page brand guide.
- `branding-cove/docs/letterhead.pdf`: A4 stationery; editable HTML is alongside it.
- `corporate/office/`: editable Word letterhead/report and widescreen PowerPoint.
- `corporate/print/`: business-card SVG sources and RGB print PDFs.
- `corporate/digital/`: social assets and email signatures. UI captures are deferred.
- `corporate/README.md`: usage and actual Office/print verification limits.
- `corporate/source/`: reproducible template generation sources.
- `tools/branding/cove.py`: canonical artwork exporter, for developer use only.

## Typography and editing

Manrope SemiBold 600 carries the brand wordmark and display voice. Inter carries
long text and the application UI. Font files and both OFL notices are supplied in
`branding-cove/raw/fonts/`. Exported logo lettering is outlined, so SVG/PNG/PDF
consumers do not require fonts. Editable native text does.

`branding-cove/raw/master.svg` is the single traced Cove master; `raw/head.svg`
contains the same geometry for compact consumers. It was traced from the owner's
approved Round 11 drawing, not a stock-logo trace. No trademark-clearance claim.

Bracketed and double-braced fields are deliberate personalisation fields, not
real people or contact details. Fill them before sending a document.
Business cards are RGB: no calibrated CMYK, PDF/X or commercial press-proof claim.

## Regeneration

These tools run only on a developer machine, never in the application runtime.

```bash
python -m pip install -r tools/branding/requirements.txt
python tools/branding/cove.py
# Follow corporate/source/ for additional native-document dependencies.
python tools/branding/package_corporate.py --help
```

Document PDFs additionally require Node, Playwright and Chromium. The root
`manifest.json` hashes every other file in this archive; the brand manifest covers
only `branding-cove/`. There are no nested ZIP bundles. A valid OOXML package is
not proof of native Microsoft Office rendering; consult `corporate/README.md`.
'''


def main()->None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--brand-root',type=Path,default=ROOT/BRAND)
    parser.add_argument('--extension-root',type=Path,default=ROOT/'corporate')
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--site',type=Path)
    args=parser.parse_args()
    brand,extension,output=args.brand_root.resolve(),args.extension_root.resolve(),args.output.resolve()
    if output.is_relative_to(brand) or output.is_relative_to(extension):parser.error('--output must be outside input trees')
    for name in ('manifest.json','sealforge-brand-kit.zip','raw/master.svg','docs/brand-guidelines.pdf'):
        if not (brand/name).is_file():parser.error(f'Incomplete canonical brand kit: {name}')
    for name in ('README.md','office/sealforge-letterhead.docx','office/sealforge-report-template.docx','office/sealforge-presentation.pptx'):
        if not (extension/name).is_file():parser.error(f'Missing corporate deliverable: {name}')
    if not any((extension/'print').glob('*.pdf')) or not any((extension/'digital').rglob('*.png')):parser.error('Print PDF and digital PNG deliverables are required')
    if not any((extension/'source').glob('*.py')):parser.error('Reproducible corporate generation sources are required')
    if args.site and not (args.site/'index.html').is_file():parser.error('--site must be an existing site')
    canonical=collect(brand,BRAND)
    stated=json.loads((brand/'manifest.json').read_text())
    actual={name.removeprefix(BRAND+'/'):digest(data) for name,data in canonical.items() if name!=BRAND+'/manifest.json'}
    if stated!=actual:raise ValueError('Canonical brand manifest is stale; regenerate before packaging')
    # Preserve older files in the repository, but ship neither deferred UI previews
    # nor the legacy variable editing face alongside the three current static faces.
    extra={name:data for name,data in collect(extension,'corporate').items()
           if not name.startswith('corporate/digital/product/') and name!='corporate/fonts/Inter.ttf'}
    tools={}
    for name in ('cove.py','print_docs.cjs','test_branding.py','test_corporate.py','requirements.txt','README.md','package_corporate.py'):
        tools[f'tools/branding/{name}']=(ROOT/'tools/branding'/name).read_bytes()
    for name in ('master.svg','approved-reference.png','geometry.json','palette.json','Inter.ttf','Manrope.ttf','OFL.txt','OFL-Manrope.txt'):
        tools[f'tools/branding/source/cove/{name}']=(ROOT/'tools/branding/source/cove'/name).read_bytes()
    full={**canonical,**extra,**tools,'README.md':overview()}
    common={name:data for name,data in canonical.items() if name.startswith((BRAND+'/raw/fonts/',BRAND+'/docs/fonts/'))}
    common.update({name:data for name,data in extra.items() if name.startswith('corporate/fonts/')})
    common['corporate/README.md']=extra['corporate/README.md']
    stationery={**common,**{name:data for name,data in full.items() if name.startswith(('corporate/office/','corporate/print/','corporate/source/',BRAND+'/docs/'))}}
    stationery.update({name:data for name,data in canonical.items() if name.startswith(BRAND+'/assets/')})
    stationery['README.md']=b'''# SealForge office and stationery - Cove

Editable Word/PPT in corporate/office/, business cards in corporate/print/,
brand guide and A4 letterhead in branding-cove/docs/. Font files, both OFL
notices and actual local HTML image resources are included. Install Manrope
and Inter for native editing. Personalise template fields before sending.
RGB print design only, not calibrated CMYK/PDF-X or press proof. See
corporate/README.md for actual render checks. manifest.json hashes every file.
'''
    digital={**common,**{name:data for name,data in full.items() if name.startswith('corporate/digital/') or name in {BRAND+'/assets/'+f for f in ('social-card.svg','social-card.png','email-logo.png','email-logo.svg','email-signature.html')}}}
    digital['README.md']=b'''# SealForge digital assets - Cove

Social, avatar and email assets in corporate/digital/. UI captures are deferred.
Canonical social/email artwork in branding-cove/assets/. Manrope/Inter and
OFL notices in branding-cove/raw/fonts/. Personal signature fields are not
real identities; fill them before use. No mail-sender feature or mail-client
delivery guarantee. See corporate/README.md. manifest.json hashes every file.
'''
    sources={name:data for name,data in full.items() if (PurePosixPath(name).suffix.lower() not in {'.pdf','.png','.ico','.webp'} or name.endswith('approved-reference.png')) and name not in {BRAND+'/manifest.json','corporate/manifest.json','corporate/inventory.json'}}
    sources['README.md']=b'''# SealForge editable sources - Cove

branding-cove/raw/ and tools/branding/source/cove/ contain the approved traced
symbol and Manrope/Inter fonts. branding-cove/docs/ has editable guide and A4
letterhead HTML. corporate/ includes native Office templates, SVG/HTML and
reproducible template code. Product C#/Razor source is not distributed here.

Install tools/branding/requirements.txt, then run python tools/branding/cove.py.
Printing additionally needs Node, Playwright and Chromium. Follow corporate/
README.md and source/ for native-document dependencies. Keep both OFL notices.
Ready-made PDF/raster outputs are omitted; private application component
screenshots cannot be regenerated from this public artwork-only source set.
Personalise fields before use. Actual Office/print limits are documented.
manifest.json hashes only files present in THIS source archive.
'''
    output.mkdir(parents=True,exist_ok=True)
    inventory={name:write_archive(output/name,payload) for name,payload in zip(ARCHIVES,(full,stationery,digital,sources),strict=True)}
    shutil.copyfile(brand/'sealforge-brand-kit.zip',output/'sealforge-brand-kit.zip')
    with zipfile.ZipFile(output/'sealforge-brand-kit.zip') as archive:
        inventory['sealforge-brand-kit.zip']={'bytes':(output/'sealforge-brand-kit.zip').stat().st_size,'files':len(archive.namelist()),'sha256':digest((output/'sealforge-brand-kit.zip').read_bytes())}
    for name in ('brand-guidelines','letterhead'):
        file=output/f'sealforge-{name}.pdf';shutil.copyfile(brand/f'docs/{name}.pdf',file);inventory[file.name]={'bytes':file.stat().st_size,'sha256':digest(file.read_bytes())}
    info={'artwork':'Approved Cove single emblem; Manrope 600 wordmark and Inter body','files':inventory}
    (output/'sealforge-downloads.json').write_text(json.dumps(info,indent=2,ensure_ascii=False)+'\n')
    if args.site:
        downloads=args.site.resolve()/'assets/downloads';downloads.mkdir(parents=True,exist_ok=True)
        for name in [*inventory,'sealforge-downloads.json']:shutil.copyfile(output/name,downloads/name)
    print(json.dumps({'output':str(output),'site':str(args.site) if args.site else None,**info},indent=2))

if __name__=='__main__':main()
