'use strict';
// Print the committed HTML sources with local artwork/fonts; no app or database is started.
const fs=require('node:fs');
const path=require('node:path');
const http=require('node:http');
const assert=require('node:assert/strict');
const {chromium}=require('playwright');
const root=path.resolve(__dirname,'../..');
const mime={'.html':'text/html','.css':'text/css','.svg':'image/svg+xml','.png':'image/png','.woff2':'font/woff2','.txt':'text/plain'};

(async()=>{
 const server=http.createServer((request,response)=>{
  try {
   const uri=new URL(request.url,'http://127.0.0.1');
   if(uri.pathname==='/favicon.ico'){response.writeHead(204);response.end();return;}
   const file=path.resolve(root,'.'+decodeURIComponent(uri.pathname));
   if(!file.startsWith(root+path.sep)){response.writeHead(403);response.end();return;}
   if(!fs.existsSync(file)||!fs.statSync(file).isFile()){response.writeHead(404);response.end();return;}
   response.setHeader('Content-Type',mime[path.extname(file)]||'application/octet-stream');
   fs.createReadStream(file).pipe(response);
  } catch {response.writeHead(400);response.end();}
 });
 let browser;
 try {
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});
  const origin=`http://127.0.0.1:${server.address().port}`;
  browser=await chromium.launch({headless:true,...(process.env.CHROMIUM_PATH?{executablePath:process.env.CHROMIUM_PATH}:{})});
  const reports=[];
  for(const [name,expected] of [['brand-guidelines',9],['letterhead',1]]){
   const page=await browser.newPage({viewport:{width:1000,height:1250}});
   const errors=[];
   page.on('pageerror',e=>errors.push(String(e)));
   page.on('requestfailed',r=>errors.push(`${r.url()}: ${r.failure()?.errorText}`));
   page.on('response',r=>{if(r.status()>=400)errors.push(`${r.status()} ${r.url()}`);});
   await page.route('**/*',route=>new URL(route.request().url()).origin===origin?route.continue():route.abort('blockedbyclient'));
   await page.emulateMedia({media:'print'});
   const response=await page.goto(`${origin}/branding/docs/${name}.html`,{waitUntil:'networkidle'});
   assert.equal(response.status(),200);
   await page.evaluate(()=>document.fonts.ready);
   const state=await page.evaluate(()=>{
    const pages=[...document.querySelectorAll('.page')];
    return {
     pages:pages.length,
     images:[...document.images].map(i=>({src:i.getAttribute('src'),loaded:i.complete&&i.naturalWidth>0})),
     fonts:[...document.fonts].map(f=>({family:f.family,status:f.status})),
     overflow:pages.filter(p=>p.scrollHeight>p.clientHeight+2||p.scrollWidth>p.clientWidth+2).length,
    };
   });
   assert.equal(state.pages,expected,`${name}: explicit A4 sheet count`);
   assert.equal(state.overflow,0,`${name}: page content must not be clipped`);
   assert.ok(state.images.length>0&&state.images.every(i=>i.loaded),`${name}: all real artwork must load`);
   assert.ok(state.fonts.some(f=>f.status==='loaded'),`${name}: the local Inter font must load`);
   assert.deepEqual(errors,[],`${name}: resource/script errors`);
   const target=path.join(root,'branding/docs',name+'.pdf');
   await page.pdf({path:target,printBackground:true,preferCSSPageSize:true,margin:{top:0,right:0,bottom:0,left:0}});
   const pdf=fs.readFileSync(target);
   assert.equal((pdf.toString('latin1').match(/\/Type\s*\/Page\b/g)||[]).length,expected,`${name}: actual PDF page count`);
   reports.push({name,pages:expected,images:state.images.length,localFonts:state.fonts.filter(f=>f.status==='loaded').length,bytes:pdf.length,errors:errors.length});
   await page.close();
  }
  console.log(JSON.stringify({documents:reports}));
 } finally {
  if(browser)await browser.close();
  await new Promise(resolve=>server.close(resolve));
 }
})().catch(error=>{console.error(error);process.exitCode=1;});
