"""Contract checks for the actual committed brand outputs, not a second drawing implementation."""
from io import BytesIO
from pathlib import Path
import hashlib
import json
import os
import re
import struct
import unittest
from xml.etree import ElementTree as ET
import zipfile

import cairosvg
from fontTools.ttLib import TTFont
from PIL import Image

ROOT=Path(__file__).resolve().parents[2]
KIT=ROOT/'branding'
ASSETS=KIT/'assets'
WEB=ROOT/'src/SealForge.Web/wwwroot'
NS={'s':'http://www.w3.org/2000/svg'}


class BrandAssetsTests(unittest.TestCase):
    def read(self,path):
        self.assertTrue(path.is_file(),f'Missing required asset: {path.relative_to(ROOT)}')
        return path.read_bytes()

    def test_requested_format_and_variant_matrix(self):
        for stem in ('logo','logo-stacked','symbol'):
            for treatment in ('on-light','on-dark','black','white'):
                for ext in ('svg','png','pdf'):
                    self.assertGreater(len(self.read(ASSETS/f'{stem}-{treatment}.{ext}')),100)
        for px in (16,24,32,48,64,128,180,192,256,512,1024):
            with Image.open(BytesIO(self.read(ASSETS/f'icon-{px}.png'))) as im:self.assertEqual(im.size,(px,px))
        self.assertEqual(Image.open(BytesIO(self.read(ASSETS/'social-card.png'))).size,(1200,630))

    def test_artwork_is_self_contained_vector_without_live_fonts(self):
        self.read(ASSETS/'logo-on-light.svg')
        paths=list(ASSETS.glob('*.svg'))+list((KIT/'raw').glob('*.svg'))
        self.assertGreaterEqual(len(paths),22)
        for p in paths:
            root=ET.fromstring(p.read_bytes()) # Locally generated, repository-owned SVG only.
            self.assertEqual(len(root.attrib['viewBox'].split()),4)
            ids=[]
            for node in root.iter():
                self.assertNotIn(node.tag.rsplit('}',1)[-1],('image','text','script','foreignObject'),p.name)
                self.assertFalse(any(k.endswith('href') for k in node.attrib),p.name)
                if 'id' in node.attrib:ids.append(node.attrib['id'])
            self.assertEqual(len(ids),len(set(ids)),p.name)

    def test_light_and_dark_keep_the_same_transparent_geometry(self):
        for stem in ('logo','logo-stacked','symbol','head'):
            light=Image.open(BytesIO(self.read(ASSETS/f'{stem}-on-light.png'))).convert('RGBA')
            dark=Image.open(BytesIO(self.read(ASSETS/f'{stem}-on-dark.png'))).convert('RGBA')
            self.assertEqual(light.size,dark.size)
            self.assertEqual(light.getchannel('A').tobytes(),dark.getchannel('A').tobytes(),stem)
            alpha=light.getchannel('A');bbox=alpha.getbbox();self.assertIsNotNone(bbox)
            self.assertTrue(bbox[0]>0 and bbox[1]>0 and bbox[2]<light.width and bbox[3]<light.height,stem)
            self.assertEqual(alpha.getpixel((0,0)),0)

    def test_ico_preserves_each_real_optical_png(self):
        data=self.read(ASSETS/'favicon.ico');reserved,kind,count=struct.unpack_from('<HHH',data)
        self.assertEqual((reserved,kind,count),(0,1,4))
        seen=[]
        for n in range(count):
            w,h,_,_,planes,bpp,length,offset=struct.unpack_from('<BBBBHHII',data,6+16*n)
            self.assertEqual((w,h,planes,bpp),(w,w,1,32))
            self.assertEqual(data[offset:offset+length],self.read(ASSETS/f'icon-{w}.png'))
            seen.append(w)
        self.assertEqual(seen,[16,32,48,64])

    def test_tiny_icon_has_the_same_head_and_visible_ink(self):
        source=ET.fromstring(self.read(KIT/'raw/head.svg'))
        self.assertIsNotNone(source.find('.//s:g[@id="head-contour"]',NS))
        icon=self.read(ASSETS/'icon-16.svg').decode()
        self.assertIn('head-contour',icon)
        for prop in ('id="paper"','id="key"','id="press"','id="imprint"'):self.assertNotIn(prop,icon)
        im=Image.open(BytesIO(self.read(ASSETS/'icon-16.png'))).convert('RGBA')
        ink=sum(1 for r,g,b,a in im.get_flattened_data() if a>200 and g>130 and r>80 and b>130)
        self.assertGreater(ink,20)

    def test_master_keeps_centered_ink_and_unbroken_paper_joins(self):
        root=ET.fromstring(self.read(KIT/'raw/master.svg'))
        plate=root.find('.//s:g[@id="press"]/s:ellipse',NS)
        self.assertIsNotNone(plate)
        line=root.find('.//s:g[@id="ink-line"]/s:path',NS)
        values=list(map(float,re.findall(r'-?\d+(?:\.\d+)?',line.attrib['d'])))
        self.assertAlmostEqual((values[0]+values[-2])/2,float(plate.attrib['cx']))
        self.assertEqual(line.attrib['stroke-width'],'4')
        self.assertEqual(root.find('.//s:g[@id="press"]/s:ellipse',NS).attrib['stroke-width'],'4')
        stem=root.find('.//s:g[@id="press"]/s:path',NS);self.assertEqual(stem.attrib['stroke-width'],'12')
        root.set('viewBox','0 0 1469 1071');root.set('width','1469');root.set('height','1071')
        image=Image.open(BytesIO(cairosvg.svg2png(bytestring=ET.tostring(root)))).convert('RGBA')
        alpha=image.getchannel('A')
        for y in (633,634,635):
            for x in list(range(1060,1141))+list(range(1163,1241)):
                self.assertGreaterEqual(alpha.getpixel((x,y)),240,f'Paper gap at {x},{y}')
            self.assertEqual(alpha.getpixel((1153,y)),0,'Paper must hide behind the hollow stem')
        self.assertEqual(alpha.getpixel((1153,645)),0)
        for y in (720,780,860,920):self.assertGreaterEqual(alpha.getpixel((1027,y)),240)

    def test_head_retains_master_face_above_the_neck_closure(self):
        images=[]
        for name in ('master','head'):
            root=ET.fromstring(self.read(KIT/f'raw/{name}.svg'))
            root.set('viewBox','0 0 1469 1071');root.set('width','1469');root.set('height','1071')
            image=Image.open(BytesIO(cairosvg.svg2png(bytestring=ET.tostring(root)))).getchannel('A').crop((520,0,1190,310))
            images.append([v>=128 for v in image.get_flattened_data()])
        intersection=sum(a and b for a,b in zip(*images));union=sum(a or b for a,b in zip(*images))
        self.assertGreater(intersection/union,.96)

    def test_token_contrast_is_computed_and_semantics_remain_separate(self):
        data=json.loads(self.read(ASSETS/'contrast.json'));self.assertEqual(len(data['pairs']),28)
        def luma(color):
            channels=[int(color[i:i+2],16)/255 for i in (1,3,5)]
            return sum(w*(v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4) for w,v in zip((.2126,.7152,.0722),channels))
        for p in data['pairs']:
            light,dark=sorted((luma(p['foreground']),luma(p['background'])),reverse=True)
            ratio=(light+.05)/(dark+.05)
            self.assertAlmostEqual(ratio,p['ratio'],places=3)
            self.assertGreaterEqual(ratio,p['required'])
        palette=json.loads(self.read(ASSETS/'palette.json'))
        for mode in ('light','dark'):
            copper=palette['palette'][mode]['copper']
            for role in ('warning','error'):self.assertNotEqual(copper,palette['semantic'][mode][role]['fill'])

    def test_raw_sources_fonts_and_layers_are_editable(self):
        for name in ('master.svg','head.svg','body.svg','copper.svg','geometry.json','palette.json','approved-reference.png','fonts/Inter.ttf','fonts/OFL.txt'):
            self.assertGreater(len(self.read(KIT/'raw'/name)),20)
        ttf=TTFont(BytesIO(self.read(KIT/'raw/fonts/Inter.ttf')))
        web=TTFont(BytesIO(self.read(ASSETS/'inter.woff2')))
        self.assertEqual(set(ttf.getBestCmap()),set(web.getBestCmap()))
        self.assertTrue(all(ord(c) in web.getBestCmap() for c in 'İıŞşĞğÇçÖöÜü'))
        self.assertIn(b'SIL OPEN FONT LICENSE',self.read(KIT/'raw/fonts/OFL.txt'))

    def test_app_serves_the_canonical_bytes(self):
        for name in ('logo-on-light.svg','logo-on-dark.svg','symbol-on-light.svg','symbol-on-dark.svg','head-on-light.svg','head-on-dark.svg','icon-192.png','icon-512.png','inter.woff2'):
            self.assertEqual(self.read(ASSETS/name),self.read(WEB/'brand'/name))
        for destination,source in {'favicon.svg':'icon-16.svg','favicon.png':'icon-64.png','favicon.ico':'favicon.ico','apple-touch-icon.png':'icon-180.png','mark.svg':'symbol-on-light.svg'}.items():
            self.assertEqual(self.read(ASSETS/source),self.read(WEB/destination))

    def test_email_is_an_asset_not_a_sender_or_fake_contact(self):
        html=self.read(ASSETS/'email-signature.html').decode()
        self.assertIn('<table',html);self.assertIn('email-logo.png',html)
        for forbidden in ('localhost','127.0.0.1','<svg','<script','mailto:','example.com'):
            self.assertNotIn(forbidden,html)


class BrandBundleTests(unittest.TestCase):
    read=BrandAssetsTests.read

    def test_complete_documents_and_archive_are_exact(self):
        for name,count in (('brand-guidelines',9),('letterhead',1)):
            self.read(KIT/f'docs/{name}.html')
            data=self.read(KIT/f'docs/{name}.pdf')
            self.assertEqual(len(re.findall(rb'/Type\s*/Page\b',data)),count,name)
            self.assertTrue(data.startswith(b'%PDF-'));self.assertIn(b'%%EOF',data[-100:])
        manifest=json.loads(self.read(KIT/'manifest.json'))
        actual={str(p.relative_to(KIT)) for p in KIT.rglob('*') if p.is_file() and p.name!='manifest.json' and p.suffix!='.zip'}
        self.assertEqual(set(manifest),actual)
        for name,digest in manifest.items():self.assertEqual(hashlib.sha256(self.read(KIT/name)).hexdigest(),digest,name)
        with zipfile.ZipFile(BytesIO(self.read(KIT/'sealforge-brand-kit.zip'))) as archive:
            self.assertEqual(set(archive.namelist()),set(manifest)|{'manifest.json'})
            for name in archive.namelist():self.assertEqual(archive.read(name),self.read(KIT/name),name)
        if os.environ.get('SEALFORGE_SITE'):
            site=Path(os.environ['SEALFORGE_SITE'])
            for p in ASSETS.iterdir():self.assertEqual(p.read_bytes(),(site/'assets/brand'/p.name).read_bytes(),p.name)
            self.assertEqual((KIT/'sealforge-brand-kit.zip').read_bytes(),(site/'assets/downloads/sealforge-brand-kit.zip').read_bytes())

if __name__=='__main__':unittest.main()
