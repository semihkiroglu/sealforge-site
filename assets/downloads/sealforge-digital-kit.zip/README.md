# SealForge digital assets - Cove

Social, avatar and email assets in corporate/digital/. UI captures are deferred.
Canonical social/email artwork in branding-cove/assets/. Manrope/Inter and
OFL notices in branding-cove/raw/fonts/. Personal signature fields are not
real identities; fill them before use. No mail-sender feature or mail-client
delivery guarantee. See corporate/README.md. manifest.json hashes every file.
