# SealForge digital assets

corporate/digital/ contains the avatar, cover, post and personal email-signature
template. branding/assets/ contains the canonical social preview and brand-only
email signature. branding/raw/fonts/ contains the editing font and its OFL text.
Fill the personal template's double-braced fields; they are not real identities.
Check the plain text and links when a mail client blocks external images.
The application does not send mail; this is not a Gmail/Outlook delivery test.
Read corporate/README.md for usage and actual verification limits.
manifest.json provides SHA-256 values for every other file in this archive.
