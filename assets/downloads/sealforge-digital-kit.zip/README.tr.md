# SealForge kimlik dosyaları

[English](README.md) · Türkçe

**SealForge = Seal + Forge:** kimliği ve bütünlüğü belirten mühür ile
imzalama atölyesi. Seal aynı zamanda foktur; tek fok başı iki anlamı
birleştirir. Cove yalnız Seal'in altında korunaklı koy çağrışımı ve
seçilen çizimin iç adıdır.

Bu paket **Türkçe ve İngilizce** dosyaları birlikte taşır. İngilizce
dosyalar mevcut yollarında, Türkçe çıktılar ilgili `tr/` klasörlerindedir.
Logo ve ikonlar iki dilde ortaktır. Seçtiğiniz indirme kategorisi aşağıdaki
dosyaların ilgili alt kümesini içerir:

- `branding-cove/docs/` ve `docs/tr/`: marka kılavuzu, A4 antet ve isim açıklaması.
- `branding-cove/assets/` ve `assets/tr/`: ortak çizimler ve dile özgü sosyal/e-posta dosyaları.
- `corporate/office/` ve `corporate/tr/office/`: Word ve PowerPoint şablonları.
- `corporate/print/` ve `corporate/tr/print/`: kartvizit SVG/PDF.
- `corporate/digital/` ve `corporate/tr/digital/`: sosyal medya ve e-posta.
- `branding-cove/README.tr.md`, `corporate/tr/README.md`: Türkçe kullanım ve sınırlar.

Marka/kaynak paketindeki HTML belgelerde üstten dil seçilebilir; PDF ve
Office dosyalarında uygun dildeki kopyayı açın. Kaynak paketinde hazır
PDF ve raster çıktılar bulunmaz; üretim araçları ve çeviri sözlükleri bulunur.
Üretilmiş Türkçe HTML yerine `tools/branding/locales/tr/` sözlüklerini düzenleyin.

Yerel belge düzenlemeden önce verilen Manrope SemiBold ve Inter fontlarını
kurun; iki SIL OFL lisansını koruyun. Köşeli ayraçlı ve `{{token}}` alanları
gerçek bilgilerle doldurun. Değişken adlarını çevirmeyin.

Bu, uygulama kurucusu veya ürün kaynak kodu değildir. Dosyalar RGB'dir;
CMYK/PDF-X, ticari baskı provası, Microsoft Office görünüm garantisi,
marka tesciline uygunluk veya donanım/imza sertifikası sunulmaz.
Son kişiselleştirilmiş dosyayı yayımlamadan önce inceleyin.

Kökteki `manifest.json`, bu arşivdeki diğer dosyaların SHA-256 özetlerini
listeler. İç içe ZIP yoktur. Özel çalışma deposu, bilerek yayımlanmış
herkese açık indirmelerin görünürlüğünü değiştirmez.
