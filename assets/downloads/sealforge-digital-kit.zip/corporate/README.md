# SealForge corporate templates

**SealForge = Seal + Forge.** Seal keeps the animal and stamp meanings; Forge is
the signing workshop. **Cove** is a supporting coastal association within Seal
and the internal name of the selected drawing, not a product rename. The story
and repository map are in `branding-cove/docs/identity-story.md` in the private
branding repository and the complete identity set.

English files remain at the existing paths. Turkish copies are in `tr/`, with
their [Turkish usage guide](tr/README.md). Both languages use the same artwork,
fonts and template geometry. Keep `{{tokens}}` unchanged when personalising.

The approved Cove identity applied to documents, presentations, stationery,
social artwork and email. One compact seal-head emblem, an unchanged palette,
and a two-font contract: **Manrope 600** carries the brand, headings and live
wordmark; **Inter** carries interface, body and long text. The generator reads
the canonical brand kit and writes only its selected output and report
directories.

This is an identity package, not a product installer. Current UI screenshots
are deliberately not included: the owner deferred recapture until the interface
is final. Earlier compiled-component fixture images may remain under
`digital/product/` in the repository, but are excluded from the current identity
archives and are not evidence of the final Cove interface or live signing.

## Contents

| Path | Purpose |
| --- | --- |
| `office/sealforge-letterhead.docx` | Editable A4 letterhead; first-page masthead and repeating footer |
| `office/sealforge-report-template.docx` | Cover, seven report/proposal sections, editable tables and sign-off |
| `office/sealforge-presentation.pptx` | Seven editable widescreen presentation slides |
| `print/business-card-front.svg`, `business-card-back.svg` | Editable clean artwork, with bleed but no guide marks |
| `print/business-card-*-guides.svg` | Editing copies with bleed, trim and safe-area guides |
| `print/business-card-85x55-RGB.pdf` | Two-page RGB print template, front then back |
| `print/print-spec.json` | Physical dimensions, font list and colour-space specification |
| `digital/social/` | Avatar, cover and canonical social-preview image |
| `digital/email/` | Personal email-signature HTML/TXT template and its image |
| `fonts/` | The three static editing faces and both SIL OFL texts |
| `source/` | Reproducible generation code and pinned dependencies |

## Word

Both documents are A4. The running header pairs the supplied emblem with live
**SealForge** text set in Manrope 600, rather than shrinking the full lockup. The
report cover uses the full artwork at 48 mm and the emblem alone in its footer.
The letterhead has a masthead on its first page only; subsequent pages repeat the
footer. The report cover has no running header or numbered footer.

Replace every `{{token}}` before use, along with the report's sample cover title
and explanatory body text. Dates, recipients, addresses, schedule, owners and
commercial amounts are intentionally not supplied. Page numbers are native
fields, updated by the document application. Do not confuse sample copy with a
real proposal or a committed project schedule.

The templates have explicit A4 sections and page breaks. Current builds check
both languages structurally; native rendering is skipped when LibreOffice is
unavailable. Editing content or changing fonts can alter pagination.

### Fonts

Install the three faces in `fonts/` before editing:

| File | Family in an office application | Role |
| --- | --- | --- |
| `Manrope-SemiBold.ttf` | Manrope SemiBold | Brand, headings, live wordmark |
| `Inter-Regular.ttf` | Inter | Body, interface and long text |
| `Inter-SemiBold.ttf` | Inter SemiBold | Labels and table heads |

The native files name those exact families, so no application has to synthesise
a bold weight. They are static instances derived from the canonical Manrope and
Inter variable sources by `source/fonts.py`; `OFL.txt` and `OFL-Manrope.txt` must
travel with them, and both licences permit redistribution. DOCX/PPTX do not embed
fonts: without the faces installed the office application substitutes them, so
check your final PDF before publishing or printing. The outlined lettering inside
the logo artwork needs no installed font.

## PowerPoint

The presentation contains seven native, editable slides: cover, statement,
agenda, content with side panel, three-column content, process and closing. Text,
cards, rules and numbering are actual PowerPoint objects, not flattened slide
screenshots. The theme sets Manrope SemiBold as the major typeface and Inter as
the minor one; every run names a concrete family. Speaker notes explain each
example. Duplicate the slide matching your content and remove unused examples.
The file does not add new entries to PowerPoint's Slide Master layout gallery.

## Business cards

- Trim: **85 × 55 mm**. Bleed: **3 mm** on each edge. Artwork page: **91 × 61 mm**.
- Safe area: **79 × 49 mm**, inset 3 mm from trim.
- The front uses one 32 mm stacked logo; the reverse uses one 48 mm horizontal
  logo. The emblem is not redundantly repeated in each composition.
- Guide SVGs show trim/bleed/safe regions. Clean SVGs and the print PDF do not.
- The PDF has explicit trim and bleed boxes; it contains front then back, and
  embeds static Manrope SemiBold and Inter subsets.
- The artwork is **RGB**, with no CMYK conversion, ICC output intent, PDF/X or
  commercial press-proof claim. Ask your printer for its required conversion and
  proof.
- SVG contact fields are deliberate `{{name}}`, `{{role}}`, `{{email}}`,
  `{{phone}}`, `{{website}}` tokens. Fill them in a vector editor, then export
  new PDFs while preserving the stated dimensions and bleed. The supplied PDF is
  an unfilled template, not a personalised card ready to send to a printer.
- `source/generate.py` regenerates the original unfilled templates; it does not
  preserve manual edits to its output SVGs. Keep personalised copies separately.

## Social and email

The avatar is 400 × 400, the cover 1500 × 500 and the post 1200 × 630. The post is
byte-identical to the canonical social card. Platforms crop differently; check
the final placement rather than enlarging the artwork indiscriminately.

The personal email signature uses a table and inline styles. Fill `{{name}}`,
`{{role}}`, `{{contact}}` and `{{logo_url}}`. The name line asks for Manrope
SemiBold first and falls back to Inter/Arial, because mail clients routinely strip
or ignore font requests. Host the supplied `email-logo.png` at an absolute URL for
`{{logo_url}}`; relative paths and data URLs are not reliable across mail clients.
Actual Gmail/Outlook sending and client dark-mode transformations are separate
checks. There are no invented real contact details or mail-sending features.

## Verification and regeneration

The generators write an inventory, SHA-256 sums and verification reports beneath
their selected report directory. Structural checks reopen the native documents,
check relationship targets, page/slide dimensions, shape bounds and the concrete
font families used. Text-fit estimates complement, but do not replace, rendered
inspection.

When available, LibreOffice renders through a private user profile and isolated
`FONTCONFIG_FILE`. Consult the current verification report for whether it ran;
structural/text-fit checks alone are not a native reflow test. Print checks cover
physical page size, embedded fonts, RGB colour operators and absence of guides.

From the corporate directory, using a dedicated Python environment:

```bash
python -m pip install -r source/requirements.txt
python source/generate.py \
  --brand-root /path/to/branding-cove \
  --output . \
  --report-dir /path/to/verification-output \
  --font-python /path/to/python-with-fonttools
```

`--font-python` is used once, by `source/fonts.py`, to derive the static faces
from the canonical variable fonts; fontTools is pinned in
`source/requirements.txt`. Nothing is installed system-wide: the font directory,
fontconfig file and LibreOffice profile all live under the report directory. The
brand kit must already have a valid manifest, approved Cove artwork, unchanged
palette, approved geometry, both source fonts and both OFL texts. `rsvg-convert`
is required for the card PDF. Existing LibreOffice and `pdftoppm` installations
are optional rendering tools; the script reports a skipped render when they are
absent. It does not install system packages. Output/report paths cannot overlap
the read-only brand kit.

The generator reproduces the native templates, print/social/email files, font
copies and this README. Generation sources remain beside it.

## Limits

No Microsoft Office native validation, hardware/signing certification, trademark
clearance or CMYK proof is claimed. Unfilled template fields must be personalised.
Saving a native Office document changes its metadata and hashes. The brand guide
and letterhead HTML/PDF live in the brand kit under `docs/` and are not rebuilt by
this extension.
