# SealForge corporate templates

The approved SealForge identity applied to documents, presentations, stationery,
social artwork and email. The mascot's geometry and colours are unchanged.
The generator reads the canonical brand kit and writes only its selected output
and report directories.

## Contents

| Path | Purpose |
| --- | --- |
| `office/sealforge-letterhead.docx` | Editable A4 letterhead; compact first-page masthead and repeating footer |
| `office/sealforge-report-template.docx` | Cover, seven report/proposal sections, editable tables and sign-off |
| `office/sealforge-presentation.pptx` | Seven editable widescreen presentation slides |
| `print/business-card-front.svg`, `business-card-back.svg` | Editable clean artwork, with bleed but no guide marks |
| `print/business-card-*-guides.svg` | Editing copies with bleed, trim and safe-area guides |
| `print/business-card-85x55-RGB.pdf` | Two-page RGB print template, front then back |
| `print/print-spec.json` | Physical dimensions and print boundaries |
| `digital/social/` | Avatar, cover and canonical social-preview image |
| `digital/email/` | Personal email-signature HTML/TXT template and its image |
| `fonts/Inter.ttf`, `fonts/OFL.txt` | Canonical editing font and required redistribution text |
| `source/` | Reproducible generation code and pinned dependencies |

## Word

Both documents are A4. Small running headers use the same seal head beside live
SealForge text, rather than shrinking the full illustrated lockup. The report
cover uses the full artwork at 48 mm. The letterhead has a masthead on its first
page only; subsequent pages repeat the footer. The report cover has no running
header or numbered footer.

Replace every `{{token}}` before use, along with the report's sample cover title
and explanatory body text. Dates, recipients, addresses, schedule, owners and
commercial amounts are intentionally not supplied. Page numbers are native
fields, updated by the document application. Do not confuse sample copy with a
real proposal or a committed project schedule.

The supplied template renders as one letterhead page and three report pages in
the checked LibreOffice environment. Editing content or changing fonts can alter
pagination.

### Fonts

Install `fonts/Inter.ttf` before editing: use the normal font installer on
Windows/macOS, or your user's font directory and font cache on Linux. Restart
the document application afterwards. Keep the supplied OFL text with any
redistributed font files.

DOCX/PPTX files do not embed Inter. An Office application may substitute a font
when Inter is absent; variable-font support and synthetic bold also vary.
Check your final PDF before publishing or printing.

## PowerPoint

The presentation contains seven native, editable slides: cover, statement,
agenda, content with side panel, three-column content, process and closing.
Text, cards, rules and numbering are actual PowerPoint objects, not flattened
slide screenshots. Speaker notes explain each example. Duplicate the slide
matching your content and remove unused examples. The file does not add new
entries to PowerPoint's Slide Master layout gallery.

## Business cards

- Trim: **85 × 55 mm**. Bleed: **3 mm** on each edge. Artwork page: **91 × 61 mm**.
- Safe area: **79 × 49 mm**, inset 3 mm from trim.
- The front uses one 36 mm stacked logo; the reverse uses one 48 mm horizontal
  logo. The mascot is not redundantly repeated in each composition.
- Guide SVGs show trim/bleed/safe regions. Clean SVGs and the print PDF do not.
- The PDF has explicit trim and bleed boxes; it contains front then back.
- The artwork is **RGB**, with no CMYK conversion, ICC output intent, PDF/X or
  commercial press-proof claim. Ask your printer for its required conversion
  and proof.
- SVG contact fields are deliberate `{{name}}`, `{{role}}`, `{{email}}`,
  `{{phone}}`, `{{website}}` tokens. Fill them in a vector editor, then export
  new PDFs while preserving the stated dimensions and bleed. The supplied PDF
  is an unfilled template, not a personalised card ready to send to a printer.
- `source/generate.py` regenerates the original unfilled templates; it does not
  preserve manual edits to its output SVGs. Keep personalised copies separately.

## Social and email

The avatar is 400 × 400, the cover 1500 × 500 and the post 1200 × 630. The post
is byte-identical to the canonical social card. Platforms crop differently;
check the final placement rather than enlarging the artwork indiscriminately.

The personal email signature uses a table and inline styles. Fill `{{name}}`,
`{{role}}`, `{{contact}}` and `{{logo_url}}`. Host the supplied `email-logo.png`
at an absolute URL for `{{logo_url}}`; relative paths and data URLs are not
reliable across mail clients. Actual Gmail/Outlook sending and client dark-mode
transformations are separate checks. There are no invented real contact details
or mail-sending features.

## Verification and regeneration

The release archives' root `manifest.json` contains SHA-256 values for their
actual contents. The generator also writes an inventory and verification
reports beneath its selected report directory. Structural checks reopen the
native documents, check relationship targets, page/slide dimensions and shape
bounds. Text-fit estimates complement, but do not replace, rendered inspection.

Native files were rendered through LibreOffice and inspected. This is not a
Microsoft Word/PowerPoint native reflow test. Print checks cover physical page
size, embedded fonts, RGB colour operators and the absence of guide marks.

From the corporate directory, using a dedicated Python environment:

```bash
python -m pip install -r source/requirements.txt
python source/generate.py \
  --brand-root ../branding \
  --output . \
  --report-dir /path/to/verification-output
```

The brand kit must already have a valid manifest, approved artwork, palette,
geometry and source font. `rsvg-convert` is required for the card PDF. Existing
LibreOffice and `pdftoppm` installations are optional rendering tools; the
script reports a skipped render when they are absent. It does not install
system packages. Output/report paths cannot overlap the read-only brand kit.

The generator reproduces the native templates, print/social/email files, font
copies and this README. Generation sources remain beside it. Any separately
included product-preview media is a captured snapshot, not a generated signing
result; its own provenance explains the fixture and capture limits.

## Limits

No Microsoft Office native validation, hardware/signing certification,
trademark clearance or CMYK proof is claimed. Unfilled template fields must be
personalised. Saving a native Office document changes its metadata and hashes.
