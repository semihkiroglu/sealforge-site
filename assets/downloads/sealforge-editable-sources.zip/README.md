# SealForge editable sources - Cove

branding-cove/raw/ and tools/branding/source/cove/ contain the approved traced
symbol and Manrope/Inter fonts. branding-cove/docs/ has editable guide and A4
letterhead HTML. corporate/ includes native Office templates, SVG/HTML and
reproducible template code. Product C#/Razor source is not distributed here.

Install tools/branding/requirements.txt, then run python tools/branding/cove.py.
Printing additionally needs Node, Playwright and Chromium. Follow corporate/
README.md and source/ for native-document dependencies. Keep both OFL notices.
Ready-made PDF/raster outputs are omitted; private application component
screenshots cannot be regenerated from this public artwork-only source set.
Personalise fields before use. Actual Office/print limits are documented.
manifest.json hashes only files present in THIS source archive.
