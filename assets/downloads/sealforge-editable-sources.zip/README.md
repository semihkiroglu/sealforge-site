# SealForge editable sources

branding/raw/ and tools/branding/source/ contain the approved seal and font.
branding/docs/ contains editable brand-guide and A4 letterhead HTML.
corporate/ contains native Office templates, editable SVG/HTML and generation
code. Product C#/Razor application source is not included.

Ready-made PDF and raster exports are deliberately omitted from this subset.
Run `python -m pip install -r tools/branding/requirements.txt`, then
`python tools/branding/mark.py` to rebuild canonical outputs. Document printing
also needs Node, Playwright and Chromium. Follow corporate/README.md and
corporate/source/ for corporate generation and Office dependencies. Keep the
supplied OFL text with redistributed font files.

Personalise template fields before use. Native Office rendering is different
from XML/package validation; actual limits are in corporate/README.md.
The root manifest.json hashes only the files actually present in THIS archive.
