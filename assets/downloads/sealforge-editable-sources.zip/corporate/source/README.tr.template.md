# SealForge kurumsal şablonları

[English](../README.md) · Türkçe

**SealForge = Seal + Forge.** Seal, İngilizcede hem fok hem mühürdür;
kimliği ve bütünlüğü anlatır. Forge, özenli üretim yapılan imzalama atölyesidir.

Bu klasör Türkçe çıktıları içerir. İngilizce karşılıkları bir üst klasördedir.
Logo, palet ve geometri iki dilde aynıdır. Paket ürün kurucusu veya uygulama
kaynağı değildir. Son arayüz ekran görüntüleri bu teslimata dahil değildir.

## İçerik

| Yol | İçerik |
| --- | --- |
| `office/sealforge-letterhead.docx` | Düzenlenebilir A4 antet |
| `office/sealforge-report-template.docx` | Kapak, yedi bölüm, tablolar ve onay alanı olan rapor/teklif |
| `office/sealforge-presentation.pptx` | Yedi düzenlenebilir 16:9 slayt |
| `print/business-card-*.svg` | 85 × 55 mm kartvizit; 3 mm taşma alanı |
| `print/business-card-*-guides.svg` | Kesim, taşma ve güvenli alan kılavuzlu düzenleme kopyaları |
| `print/business-card-85x55-RGB.pdf` | Ön ve arka olmak üzere iki sayfalık RGB baskı şablonu |
| `digital/social/` | 400 × 400 avatar, 1500 × 500 kapak, 1200 × 630 paylaşım görseli |
| `digital/email/` | Kişisel e-posta imzası HTML/TXT ve logo görseli |

## Düzenleme

Önce ortak `../fonts/` klasöründeki **Manrope SemiBold**, **Inter** ve
**Inter SemiBold** fontlarını kurun. Manrope 600 marka ve başlıklar; Inter
gövde ve arayüz; Inter SemiBold etiket ve tablo başları içindir. Fontlar
DOCX/PPTX içine gömülü değildir; kurulmazsa uygulama başka font kullanır.
Logo çiziminin harfleri konturdur; logo için font kurulumu gerekmez.
Fontlarla birlikte iki SIL OFL lisansını da dağıtın.

Tüm `{{token}}` alanlarını, örnek kapak başlığını ve açıklama metinlerini
gerçek içerikle değiştirin. Değişken adlarını çevirmeyin. Gerçek kişi,
iletişim bilgisi, takvim veya ticari tutar varsayılmamıştır.

Word belgeleri A4'tür. Antetin üst başlığı yalnız ilk sayfadadır; alt bilgi
sonraki sayfalarda yinelenir. Rapor kapağı numarasızdır; sayfa numaraları
belge uygulamasının güncellediği yerel alanlardır. Font ve içerik değişimi
sayfa akışını değiştirebilir.

PowerPoint metinleri, kartları, çizgileri ve numaraları düzenlenebilir yerel
nesnelerdir. Slayt düzenleri: kapak, ana fikir, gündem, yan panelli içerik,
üç sütun, süreç ve kapanış. Konuşmacı notları örnekleri açıklar.
İhtiyacınız olan slaytı çoğaltın, diğerlerini kaldırın. Dosya, uygulamanın
Slayt Ana Görünümü galerisine yeni düzen girdileri eklemez.

## Baskı ve dijital kullanım

Kartvizit kesimi **85 × 55 mm**, taşma payı **3 mm**, çizim sayfası
**91 × 61 mm**, güvenli alanı **79 × 49 mm**'dir. Temiz SVG ve PDF'lerde
kılavuz işareti yoktur. PDF'nin kesim/taşma kutuları tanımlıdır ve font
alt kümeleri gömülüdür. Kişisel bilgileri SVG kopyasında doldurup bu
ölçüleri koruyarak yeniden PDF üretin; verilen PDF boş şablondur.

Dosyalar **RGB**'dir; CMYK dönüşümü, ICC çıktı profili, PDF/X veya ticari
baskı provası sunulmaz. Dönüşümü ve provayı matbaanızla doğrulayın.
Üretici, kişiselleştirilmiş çıktıları korumaz; bunları ayrı kopyada tutun.

E-posta şablonunda `{{name}}`, `{{role}}`, `{{contact}}` ve `{{logo_url}}`
alanlarını doldurun. `email-logo.png` görselini mutlak HTTPS adresinde
barındırın. E-posta istemcileri fontları yok sayabilir veya görselleri
engelleyebilir. Gerçek Gmail/Outlook gönderimi ve koyu tema dönüşümü
ayrıca kontrol edilmelidir; pakette e-posta gönderme özelliği yoktur.

## Üretim ve doğrulama

İngilizce kaynaklar ve katı Türkçe sözlükler aynı üretim hattını kullanır.
Kaynaklar `../source/`, ortak çeviri yardımcıları tam/kaynak paketindeki
`tools/branding/localize.py` ve `locales/tr/` altındadır.
Eksik çeviri üretimi durdurur; kod ve `{{token}}` alanları korunur.
Marka kılavuzu ve HTML antet, marka paketinin `docs/tr/` klasöründedir.

Yapısal kontroller iki dilde yerel dosyaları yeniden açar; ilişkileri,
sayfa/slayt ölçülerini, nesne sınırlarını, fontları ve tahmini metin sığmasını
denetler. Baskıda ölçü, font gömme, RGB ve kılavuz yokluğu kontrol edilir.
LibreOffice yoksa yerel görüntüleme açıkça atlanır. Yapısal kontrol,
Microsoft Word veya PowerPoint görünüm doğrulaması değildir.

Marka tescili uygunluğu, donanım/imza sertifikasyonu veya CMYK provası
iddia edilmez. Son kişiselleştirilmiş dosyayı yayımlamadan önce inceleyin.
