"""Approved SealForge brand inputs: palette, assets and SVG helpers.

Read-only. Nothing here regenerates or recolours the mark; the canonical
exports from the brand kit are the source of truth.
"""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

# Typography contract: Manrope 600 carries the brand, headings and wordmark;
# Inter carries interface, body and long text. The generated native files ask
# for these exact static families, so no application has to synthesise a weight.
BRAND_FONT = "Manrope SemiBold"
BODY_FONT = "Inter"
BODY_STRONG = "Inter SemiBold"

# Final approved identity values. Any drift is a hard error: these documents
# must not silently pick up a different palette.
EXPECTED = {
    ("light", "background"): "#f7f8f5",
    ("light", "surface"): "#ffffff",
    ("light", "ink"): "#203033",
    ("light", "muted"): "#56666a",
    ("light", "primary"): "#316b73",
    ("light", "copper"): "#9f542e",
    ("light", "line"): "#d8e1de",
    ("dark", "background"): "#151b1d",
    ("dark", "surface"): "#1c2426",
    ("dark", "ink"): "#eef5f3",
    ("dark", "primary"): "#87c2c6",
    ("dark", "copper"): "#e5ad7d",
}

# Canonical files this extension consumes. Hashes are checked against the
# brand kit's own manifest before anything is written.
USED = [
    "raw/palette.json",
    "raw/geometry.json",
    "raw/fonts/Inter.ttf",
    "raw/fonts/OFL.txt",
    "raw/fonts/Manrope.ttf",
    "raw/fonts/OFL-Manrope.txt",
    "assets/logo-on-light.svg",
    "assets/logo-on-light.png",
    "assets/logo-on-dark.svg",
    "assets/logo-on-dark.png",
    "assets/logo-stacked-on-light.png",
    "assets/logo-stacked-on-light.svg",
    "assets/symbol-on-light.png",
    "assets/symbol-on-dark.png",
    "assets/head-on-light.png",
    "assets/icon-1024.png",
    "assets/social-card.png",
    "assets/email-logo.png",
]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


class Brand:
    def __init__(self, root: Path):
        self.root = Path(root).resolve()
        self.palette = json.loads((self.root / "raw/palette.json").read_text("utf-8"))
        self.geometry = json.loads((self.root / "raw/geometry.json").read_text("utf-8"))
        self.checks: list[dict] = []

    # -- guards ---------------------------------------------------------
    def verify(self) -> list[dict]:
        """Assert final palette values and every consumed canonical hash."""
        if not (self.root / "manifest.json").is_file():
            raise SystemExit(f"not a brand kit (manifest.json missing): {self.root}")
        manifest = json.loads((self.root / "manifest.json").read_text("utf-8"))
        for (mode, token), want in EXPECTED.items():
            got = self.palette.get("palette", {}).get(mode, {}).get(token)
            if str(got).lower() != want:
                raise SystemExit(f"palette drift: {mode}.{token} = {got!r}, expected {want!r}")
        if self.geometry.get("approvalRound") != 11 or self.geometry.get("identity") != "SealForge":
            raise SystemExit(f"geometry is not the approved Round 11 identity: "
                             f"{self.geometry.get('identity')!r} round {self.geometry.get('approvalRound')!r}")
        if self.geometry.get("headViewBox") != self.geometry.get("masterViewBox"):
            raise SystemExit("head and master artwork must share one emblem geometry")
        typography = self.palette.get("typography", {})
        if typography != {"brandFamily": "Manrope", "brandWeight": 600, "bodyFamily": "Inter"}:
            raise SystemExit(f"typography contract drift: {typography!r}")
        for rel in USED:
            path = self.root / rel
            if not path.is_file():
                raise SystemExit(f"missing canonical asset: {rel}")
            want = manifest.get(rel)
            if want is None:
                raise SystemExit(f'canonical asset is missing from manifest: {rel}')
            got = sha256(path)
            if want != got:
                raise SystemExit(f"canonical asset hash mismatch: {rel}")
            self.checks.append({"path": rel, "sha256": got, "manifest_match": bool(want)})
        return self.checks

    # -- tokens ---------------------------------------------------------
    def c(self, mode: str, token: str) -> str:
        return self.palette["palette"][mode][token]

    def path(self, rel: str) -> Path:
        return self.root / rel

    # -- SVG ------------------------------------------------------------
    def _svg_text(self, rel: str) -> str:
        text = self.path(rel).read_text("utf-8")
        text = re.sub(r"<\?xml.*?\?>", "", text, flags=re.S)
        return text

    def svg_viewbox(self, rel: str) -> str:
        m = re.search(r'viewBox="([^"]+)"', self._svg_text(rel))
        if not m:
            raise ValueError(f"no viewBox in {rel}")
        return m.group(1)

    def svg_size(self, rel: str) -> tuple[float, float]:
        _, _, w, h = (float(v) for v in self.svg_viewbox(rel).replace(",", " ").split())
        return w, h

    def sized_svg(self, rel: str, x: float, y: float, w: float) -> str:
        """Place a canonical SVG at width w, deriving the height from its viewBox."""
        vw, vh = self.svg_size(rel)
        return self.nested_svg(rel, x, y, w, w * vh / vw)

    def svg_inner(self, rel: str) -> str:
        text = self._svg_text(rel)
        m = re.search(r"<svg\b[^>]*>(.*)</svg>\s*$", text, flags=re.S)
        if not m:
            raise ValueError(f"cannot isolate SVG body: {rel}")
        return m.group(1)

    def nested_svg(self, rel: str, x: float, y: float, w: float, h: float) -> str:
        """Place a canonical SVG inside a millimetre-coordinate parent SVG.

        The nested element carries the original viewBox and the original
        path data verbatim, so geometry and approved fills stay untouched.
        """
        return (
            f'<svg x="{x}" y="{y}" width="{w}" height="{h}" '
            f'viewBox="{self.svg_viewbox(rel)}" preserveAspectRatio="xMidYMid meet">'
            f"{self.svg_inner(rel)}</svg>"
        )
