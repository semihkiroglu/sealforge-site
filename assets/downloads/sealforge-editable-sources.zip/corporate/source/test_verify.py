"""Check actual bilingual card PDFs, including encoded Turkish glyph strings."""
from pathlib import Path
import tempfile
import unittest

import verify

ROOT = Path(__file__).resolve().parents[1]


class PrintChecks(unittest.TestCase):
    def test_encoded_letters_are_not_cmyk_operators(self):
        with tempfile.TemporaryDirectory() as work:
            for language, prefix in (("en", ""), ("tr", "tr/")):
                with self.subTest(language=language):
                    source = ROOT / prefix / "print"
                    report = verify.check_card_pdf(source / "business-card-85x55-RGB.pdf", source, Path(work) / language)
                    self.assertEqual(report["cmyk_operator_hits"], 0)
                    self.assertGreater(report["rgb_operator_hits"], 0)
                    self.assertTrue(report["ok"])


if __name__ == "__main__":
    unittest.main()
