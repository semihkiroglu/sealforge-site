# Where the SealForge website is published

Verified from GitHub repository settings and the exact deployment on
16 November 2026. Re-check the live settings before changing publication.

## Source and settings

- Website repository: <https://github.com/semihkiroglu/sealforge-site> (**public**).
- Published URL: <https://semihkiroglu.github.io/sealforge-site/>.
- Settings: <https://github.com/semihkiroglu/sealforge-site/settings/pages>.
- GitHub Pages mode: **Deploy from a branch** (`build_type: legacy`).
- Source: **`main`**, **`/` (root)**.
- The root `.nojekyll` file makes publication a static file copy. There is no
  application server, custom domain or website framework build.

GitHub supplies the dynamic **pages-build-deployment** workflow. It is not a
checked-in `.github/workflows/*.yml` file, which is why a search for a website
deployment YAML in the product repository does not find it. Website pushes to
`main` publish the root HTML and its local `assets/` files.

## Verified deployment

- Source commit: `5a87b28000f053c27efdc82605ec6b96b904add9`.
- Pages build: `1374783328`, status `built`, no reported build error.
- [Run `43872282976`](https://github.com/semihkiroglu/sealforge-site/actions/runs/43872282976):
  build, deploy and report-build-status jobs all succeeded for that exact commit.
- Run created at `2026-11-16T13:04:16Z`; Pages build finished at
  `2026-11-16T13:04:47Z`.

This records the observed deployment, not a promise that it remains the latest
run indefinitely.

## Branding is a separate source

The private `sealforge-branding` repository owns editable identity sources.
The website owns the public copies under `assets/brand/`, `assets/img/`,
`assets/fonts/` and `assets/downloads/`.

The website currently publishes the brand guide, letterhead, artwork kit,
complete corporate set, stationery, digital kit and editable-source archive.
Making the source repository private does **not** hide those public files,
remove their website history or invalidate previously downloaded copies.

The repository separation does not change Pages settings, remove downloads,
publish the corrected guide or automatically sync future branding changes.
Those are separate publishing decisions.

## Bilingual publication

The current exporter preserves English page/PDF URLs and generates Turkish
pages at `tr/` plus `*-tr.pdf` downloads. Both languages must be copied and
published together with `assets/js/language.js`, localized social/email assets,
all bilingual ZIPs and the updated checksum catalogue. A corrected private PDF
does not prove that the public copy changed: compare the actual public bytes
with the new catalogue after the exact-SHA Pages deployment succeeds.
