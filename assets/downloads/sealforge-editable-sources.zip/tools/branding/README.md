# SealForge brand production

Developer tooling only. The application serves committed SVG/PNG/ICO/font files;
it never generates logos, starts Python, prints documents or sends email.

**SealForge = Seal + Forge.** The seal head preserves both the animal and stamp
meanings of Seal; Forge is the signing workshop. **Cove** is a supporting
coastal association within Seal and the internal name of the selected drawing,
not a rebrand. The [identity story](../../branding-cove/docs/identity-story.md)
explains the name and maps the source, deliverable and runtime directories.

## Current sources

- `source/cove/master.svg`: the single owner-selected Cove head, traced once from
  the approved Round 11 A reference. No full animal, key or press illustration.
- `source/cove/approved-reference.png`: approval reference, not the export source.
- `source/cove/geometry.json`: approval, trace provenance and typography contract.
- `source/cove/palette.json`: unchanged Coast & Copper and semantic tokens.
- `source/cove/Manrope.ttf` and `OFL-Manrope.txt`: licensed brand/display family.
- `source/cove/Inter.ttf` and `OFL.txt`: licensed UI/body family.

Manrope SemiBold 600 carries the wordmark with explicit -0.018 em tracking in
outlined logo exports. Inter remains the interface and long-text font. The same
Cove paths drive horizontal/stacked lockups, the standalone symbol and all icons;
`head` and `symbol` filenames refer to that same emblem, not different characters.
Copper is a separate layout accent, never the warning/error hue.

## Regenerate

Python dependencies are in `requirements.txt`. Document PDFs additionally need
Node, Playwright and Chromium; reuse an existing installation through `NODE_PATH`
and `CHROMIUM_PATH`. Do not install global system tools merely to rebuild artwork.

```bash
python tools/branding/cove.py --assets-only
# Edit branding-cove/docs/*.html; fonts and artwork are local.
python tools/branding/cove.py
python tools/branding/cove.py --assets-only --sync-app /path/to/SealForge
SEALFORGE_APP=/path/to/SealForge python tools/branding/test_branding.py
python corporate/source/generate.py --brand-root branding-cove --output corporate --report-dir /path/to/scratch/evidence
python tools/branding/package_corporate.py --output /path/to/downloads --site ../sealforge-site
SEALFORGE_DOWNLOADS=/path/to/downloads python tools/branding/test_corporate.py
```

The normal exporter prints the nine-page guide and A4 letterhead, then creates
`branding-cove/manifest.json` and `sealforge-brand-kit.zip`. Only `--sync-app`
writes the static app subset to its explicit existing application checkout.
There is no default app path. The app byte-comparison test requires
`SEALFORGE_APP`; without it that one cross-repository check is explicitly skipped.
`--site` requires a complete kit and copies its
exact bytes; neither option commits, deploys a service or publishes a repository.
Native corporate dependencies and actual rendering limits are in `corporate/`.

## English and Turkish

English is the source. Edit `branding-cove/docs/*.html` and the native builders;
edit `locales/tr/documents.json`, `site.json` and `templates.json` for Turkish.
Missing translations fail the build rather than silently leaving English copy.
Code, filenames, font families and `{{tokens}}` remain unchanged.

`cove.py` writes Turkish guide/letterhead HTML/PDF under `docs/tr/` and social/
email outputs under `assets/tr/`. `--site` copies the shared `language.js` and
generates all five static Turkish pages under the website's `tr/`.
Browser negotiation, explicit `?lang=en|tr`, saved preference and the top switch
select the page; no text depends on client-side translation. Manual choices
survive navigation with blocked storage, and switching retains the fragment.
Native generation writes `corporate/tr/`. Packaging includes both languages
and preserves the existing English PDF URLs, adding `*-tr.pdf` downloads.

Run `python corporate/source/test_verify.py` for real bilingual card-PDF checks,
plus the website's `tests/language.test.cjs` and bilingual responsive matrix.

These tools live in the private `sealforge-branding` repository, not in the
application. See [publication details](../../docs/github-pages.md) before
copying anything into the public website.

The prior `mark.py`, source drawing and `branding/` outputs are historical; they
are not current consumers or downloads. Do not run the old exporter as the Cove
pipeline. The current source/kit are deliberately separate from those retained
files and from immutable concept rounds.

## Verification and limits

Checks cover actual format/size matrices, self-contained font-free SVGs,
transparent padding, identical theme alpha, the source/reference trace agreement,
the one-emblem contract, real PNG entries in ICO, both fonts and Turkish glyphs,
sampled contrast, app/site byte identity, document resources/page bounds and
ZIP/manifest integrity. Inspect the real small PNGs enlarged with NEAREST, not a
large logo presented as a tiny-icon test.

The master is a trace of the approved original generated study, not a claim of
hand-authored curves or trademark clearance. Token/fixture evidence is not
whole-app accessibility, production authentication, physical signing, native
Microsoft Office or calibrated CMYK/PDF-X proof.
