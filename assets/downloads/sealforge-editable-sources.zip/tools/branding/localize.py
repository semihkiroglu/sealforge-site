"""Strict Turkish copies of owned HTML and native templates; English remains the source."""
from __future__ import annotations

from html import escape
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import shutil
import zipfile

HERE = Path(__file__).resolve().parent
# HTMLParser lowercases attribute names; inline SVG needs its original casing.
SVG_ATTRIBUTES = {"viewbox": "viewBox", "preserveaspectratio": "preserveAspectRatio"}


def catalog(name: str) -> dict[str, str]:
    return json.loads((HERE / "locales/tr" / f"{name}.json").read_text("utf-8"))


def translate(text: str, words: dict[str, str]) -> str:
    value = text.strip()
    if not value or not any(c.isalpha() for c in value) or re.fullmatch(r"\{\{[^{}]+\}\}", value):
        return text
    if value not in words:
        raise ValueError(f"Missing Turkish translation: {value!r}")
    left, right = len(text) - len(text.lstrip()), len(text) - len(text.rstrip())
    return text[:left] + words[value] + (text[len(text)-right:] if right else "")


class TurkishHTML(HTMLParser):
    def __init__(self, words: dict[str, str], kind: str, filename: str):
        super().__init__(convert_charrefs=True)
        self.words, self.kind, self.filename = words, kind, filename
        self.parts: list[str] = []
        self.stack: list[tuple[str, dict]] = []

    def handle_decl(self, decl):
        self.parts.append(f"<!{decl}>")

    def handle_comment(self, data):
        self.parts.append(f"<!--{data}-->")

    def handle_starttag(self, tag, attributes):
        attrs = {SVG_ATTRIBUTES.get(name, name): value for name, value in attributes}
        original = attrs.copy()
        if tag == "html":
            attrs["lang"] = "tr"
            if self.kind != "email":
                attrs["data-language-root"] = "../"
        for name in ("alt", "title", "aria-label"):
            if attrs.get(name):
                attrs[name] = translate(attrs[name], self.words)
        if tag == "meta" and (attrs.get("name") == "description" or attrs.get("property") in {"og:title", "og:description"}):
            attrs["content"] = translate(attrs["content"], self.words)
        for name in ("href", "src", "content"):
            if not attrs.get(name):
                continue
            value = attrs[name]
            if self.kind == "site":
                if value.startswith("assets/"):
                    value = "../" + value
                value = value.replace("/brand/social-card.png", "/brand/tr/social-card.png")
                value = value.replace("/brand/email-signature.html", "/brand/tr/email-signature.html")
                value = value.replace("sealforge-brand-guidelines.pdf", "sealforge-brand-guidelines-tr.pdf")
                value = value.replace("sealforge-letterhead.pdf", "sealforge-letterhead-tr.pdf")
                if (tag == "link" and original.get("rel") == "canonical") or (tag == "meta" and original.get("property") == "og:url"):
                    value = value.replace("/sealforge-site/", "/sealforge-site/tr/")
            elif self.kind == "document":
                if value.startswith("../assets/"):
                    value = "../" + value
                    value = value.replace("/assets/social-card.png", "/assets/tr/social-card.png")
                if value == "language.js":
                    value = "../language.js"
            elif self.kind == "email" and value == "https://semihkiroglu.github.io/sealforge-site/":
                value += "tr/?lang=tr"
            attrs[name] = value
        if tag == "meta" and attrs.get("property") == "og:locale":
            attrs["content"] = "tr_TR"
        if tag == "a" and original.get("lang") in {"en", "tr"}:
            language = original["lang"]
            attrs["href"] = ("../" if language == "en" else "") + self.filename + "?lang=" + language
            if language == "tr":
                attrs["aria-current"] = "true"
            else:
                attrs.pop("aria-current", None)
        self.parts.append("<" + tag + "".join(" " + name + (f'="{escape(value, quote=True)}"' if value is not None else "") for name, value in attrs.items()) + ">")
        if tag not in {"meta", "link", "img", "br", "hr", "input", "source", "wbr"}:
            self.stack.append((tag, attrs))

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if self.stack and self.stack[-1][0] == tag:
            self.stack.pop()
        self.parts[-1] = self.parts[-1][:-1] + "/>"

    def handle_endtag(self, tag):
        self.parts.append(f"</{tag}>")
        for i in range(len(self.stack)-1, -1, -1):
            if self.stack[i][0] == tag:
                del self.stack[i:]
                break

    def handle_data(self, data):
        if any(tag in {"script", "style"} for tag, _ in self.stack):
            if self.kind == "document" and self.stack[-1][0] == "style":
                data = data.replace('url("fonts/', 'url("../fonts/')
            self.parts.append(data)
        elif any(tag in {"code", "pre"} or "mono" in attrs.get("class", "").split() for tag, attrs in self.stack):
            self.parts.append(escape(data, quote=False))
        else:
            self.parts.append(escape(translate(data, self.words), quote=False))


def html(text: str, words: dict[str, str], kind: str, filename: str) -> str:
    parser = TurkishHTML(words, kind, filename)
    parser.feed(text)
    parser.close()
    return "".join(parser.parts)


def xml(data: bytes, words: dict[str, str]) -> bytes:
    from lxml import etree
    root = etree.fromstring(data, parser=etree.XMLParser(resolve_entities=False))
    text_tags = {"t", "text", "tspan", "title", "subject", "description", "category", "keywords"}
    for node in root.iter():
        if not isinstance(node.tag, str):
            continue
        name = etree.QName(node).localname
        if name in text_tags and node.text:
            node.text = translate(node.text, words)
        if name == "tspan" and node.tail:
            node.tail = translate(node.tail, words)
        for attr in list(node.attrib):
            if etree.QName(attr).localname == "lang" or (name == "lang" and etree.QName(attr).localname in {"val", "eastAsia"}):
                node.set(attr, "tr-TR")
    return etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)


def office(source: Path, target: Path, words: dict[str, str]) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(source) as incoming, zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as outgoing:
        for entry in incoming.infolist():
            data = incoming.read(entry.filename)
            if entry.filename.endswith(".xml"):
                data = xml(data, words)
            outgoing.writestr(entry, data)


def site(root: Path) -> None:
    words = catalog("site")
    (root / "tr").mkdir(exist_ok=True)
    shutil.copyfile(HERE / "language.js", root / "assets/js/language.js")
    for name in ("index", "details", "development", "usage", "brand"):
        filename = name + ".html"
        (root / "tr" / filename).write_text(html((root / filename).read_text("utf-8"), words, "site", filename), "utf-8")
