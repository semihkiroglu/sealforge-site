"""Validate real distributable archives and their native document payloads."""
from io import BytesIO
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import posixpath
import unittest
# This validator reads only locally generated, repository-owned OOXML archives;
# it is not an upload parser for untrusted Office documents.
from xml.etree import ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parents[2]
DOWNLOADS = Path(os.environ.get('SEALFORGE_DOWNLOADS', ROOT / 'corporate-packages'))
MAIN = 'sealforge-corporate-identity.zip'
NS = {'p': 'http://schemas.openxmlformats.org/presentationml/2006/main',
      'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
      'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


class CorporatePackageTests(unittest.TestCase):
    def test_download_inventory_matches_every_real_file(self):
        manifest = json.loads((DOWNLOADS / 'sealforge-downloads.json').read_text())
        expected = {'sealforge-corporate-identity.zip', 'sealforge-brand-kit.zip',
                    'sealforge-stationery.zip', 'sealforge-digital-kit.zip',
                     'sealforge-editable-sources.zip', 'sealforge-brand-guidelines.pdf',
                     'sealforge-letterhead.pdf', 'sealforge-brand-guidelines-tr.pdf',
                     'sealforge-letterhead-tr.pdf'}
        self.assertEqual(set(manifest['files']), expected)
        for name, info in manifest['files'].items():
            data = (DOWNLOADS / name).read_bytes()
            self.assertEqual(len(data), info['bytes'], name)
            self.assertEqual(sha(data), info['sha256'], name)
            if name.endswith('.zip'):
                with zipfile.ZipFile(BytesIO(data)) as archive:
                    self.assertEqual(len(archive.namelist()), info['files'], name)

    def test_each_archive_has_exact_safe_entries_and_hashes(self):
        catalogue = json.loads((DOWNLOADS / 'sealforge-downloads.json').read_text())
        for name in catalogue['files']:
            if not name.endswith('.zip'):
                continue
            file = DOWNLOADS / name
            with zipfile.ZipFile(file) as archive:
                names = archive.namelist()
                self.assertEqual(len(names), len(set(names)), file.name)
                self.assertIsNone(archive.testzip(), file.name)
                manifest = json.loads(archive.read('manifest.json'))
                self.assertEqual(set(names), set(manifest) | {'manifest.json'}, file.name)
                for name in names:
                    p = PurePosixPath(name)
                    self.assertFalse(p.is_absolute() or '..' in p.parts or '\\' in name)
                    self.assertNotIn(p.suffix, {'.zip', '.cs', '.razor', '.csproj', '.key', '.pfx', '.db'})
                    if name != 'manifest.json':
                        self.assertEqual(sha(archive.read(name)), manifest[name], name)
                self.assertTrue(any(n.endswith('/OFL.txt') for n in names), file.name)
                self.assertTrue(any(n.endswith('/OFL-Manrope.txt') for n in names), file.name)
                self.assertFalse(any(n.startswith('corporate/digital/product/') for n in names), file.name)
                self.assertNotIn('corporate/fonts/Inter.ttf', names, file.name)

    def test_complete_set_contains_actual_office_print_digital_and_sources(self):
        with zipfile.ZipFile(DOWNLOADS / MAIN) as archive:
            names = set(archive.namelist())
            for name in ('branding-cove/raw/master.svg', 'branding-cove/raw/head.svg',
                         'branding-cove/docs/brand-guidelines.pdf', 'branding-cove/docs/letterhead.pdf',
                         'corporate/office/sealforge-letterhead.docx',
                         'corporate/office/sealforge-report-template.docx',
                         'corporate/office/sealforge-presentation.pptx',
                         'tools/branding/cove.py', 'tools/branding/source/cove/master.svg',
                         'tools/branding/source/cove/Inter.ttf', 'tools/branding/source/cove/Manrope.ttf', 'README.md'):
                self.assertIn(name, names)
            self.assertTrue(any(n.startswith('corporate/print/') and n.endswith('.pdf') for n in names))
            self.assertTrue(any(n.startswith('corporate/digital/') and n.endswith('.png') for n in names))
            self.assertTrue(any(n.startswith('corporate/digital/') and n.endswith('.html') for n in names))
            self.assertTrue(any(n.startswith('corporate/source/') and n.endswith('.py') for n in names))
            self.assertEqual(archive.read('branding-cove/raw/master.svg'), (ROOT / 'branding-cove/raw/master.svg').read_bytes())
            self.assertEqual(archive.read('branding-cove/raw/head.svg'), (ROOT / 'branding-cove/raw/head.svg').read_bytes())
            self.assertNotIn('tools/branding/source/master.svg', names)
            self.assertIn('branding-cove/raw/fonts/OFL-Manrope.txt', names)

    def test_each_download_category_includes_both_languages(self):
        required = {
            MAIN: ['branding-cove/docs/tr/brand-guidelines.pdf', 'corporate/tr/office/sealforge-letterhead.docx', 'README.tr.md'],
            'sealforge-brand-kit.zip': ['docs/brand-guidelines.pdf', 'docs/tr/brand-guidelines.pdf', 'assets/tr/social-card.png', 'README.tr.md'],
            'sealforge-stationery.zip': ['corporate/office/sealforge-presentation.pptx', 'corporate/tr/office/sealforge-presentation.pptx', 'corporate/tr/print/business-card-85x55-RGB.pdf', 'README.tr.md'],
            'sealforge-digital-kit.zip': ['corporate/digital/email/sealforge-email-signature.html', 'corporate/tr/digital/email/sealforge-email-signature.html', 'branding-cove/assets/tr/social-card.png', 'README.tr.md'],
            'sealforge-editable-sources.zip': ['branding-cove/docs/tr/brand-guidelines.html', 'tools/branding/localize.py', 'tools/branding/language.js', 'tools/branding/locales/tr/documents.json', 'tools/branding/locales/tr/site.json', 'tools/branding/locales/tr/templates.json', 'README.tr.md'],
        }
        for name, entries in required.items():
            with self.subTest(archive=name), zipfile.ZipFile(DOWNLOADS / name) as archive:
                for entry in entries:
                    self.assertIn(entry, archive.namelist())

    def test_turkish_native_files_keep_editable_structure_tokens_and_artwork(self):
        import re
        with zipfile.ZipFile(DOWNLOADS / MAIN) as bundle:
            for filename in ('sealforge-letterhead.docx', 'sealforge-report-template.docx', 'sealforge-presentation.pptx'):
                with self.subTest(file=filename), zipfile.ZipFile(BytesIO(bundle.read('corporate/office/' + filename))) as en, zipfile.ZipFile(BytesIO(bundle.read('corporate/tr/office/' + filename))) as tr:
                    self.check_office_relationships(tr)
                    self.assertEqual(set(en.namelist()), set(tr.namelist()))
                    for name in en.namelist():
                        if '/media/' in name:
                            self.assertEqual(en.read(name), tr.read(name))
                    en_text = '\n'.join(en.read(n).decode() for n in en.namelist() if n.endswith('.xml'))
                    tr_text = '\n'.join(tr.read(n).decode() for n in tr.namelist() if n.endswith('.xml'))
                    self.assertEqual(sorted(re.findall(r'\{\{[^{}]+\}\}', en_text)), sorted(re.findall(r'\{\{[^{}]+\}\}', tr_text)))
                    self.assertIn('tr-TR', tr_text)
                    self.assertNotIn('en-GB', tr_text)
                    self.assertRegex(tr_text, r'İmzalama|RAPOR|Sayın')

    def check_office_relationships(self, archive):
        names = set(archive.namelist())
        self.assertIsNone(archive.testzip())
        for name in names:
            if not name.endswith('.rels'):
                continue
            xml = ET.fromstring(archive.read(name))
            base = '' if name == '_rels/.rels' else posixpath.dirname(posixpath.dirname(name))
            for rel in xml:
                if rel.attrib.get('TargetMode') == 'External':
                    continue
                target = rel.attrib['Target'].split('#', 1)[0]
                resolved = posixpath.normpath(posixpath.join(base, target)).lstrip('/')
                self.assertIn(resolved, names, f'{name}: {target}')

    def test_word_files_reopen_as_real_editable_packages(self):
        with zipfile.ZipFile(DOWNLOADS / MAIN) as outer:
            for name in ('sealforge-letterhead.docx', 'sealforge-report-template.docx'):
                with zipfile.ZipFile(BytesIO(outer.read('corporate/office/' + name))) as doc:
                    self.check_office_relationships(doc)
                    for part in ('[Content_Types].xml', 'word/document.xml', 'word/styles.xml'):
                        ET.fromstring(doc.read(part))
                    xml = ET.fromstring(doc.read('word/document.xml'))
                    words = [n.text for n in xml.findall('.//w:t', NS) if n.text]
                    self.assertTrue(words, name)
                    self.assertTrue(any(n.startswith('word/media/') for n in doc.namelist()), name)

    def test_presentation_is_widescreen_with_editable_text_and_in_bounds_shapes(self):
        with zipfile.ZipFile(DOWNLOADS / MAIN) as outer:
            with zipfile.ZipFile(BytesIO(outer.read('corporate/office/sealforge-presentation.pptx'))) as deck:
                self.check_office_relationships(deck)
                presentation = ET.fromstring(deck.read('ppt/presentation.xml'))
                size = presentation.find('p:sldSz', NS)
                assert size is not None, 'Presentation must declare its slide size'
                width, height = int(size.attrib['cx']), int(size.attrib['cy'])
                self.assertAlmostEqual(width / height, 16 / 9, places=4)
                slides = sorted(n for n in deck.namelist() if n.startswith('ppt/slides/slide') and n.endswith('.xml') and '/_rels/' not in n)
                self.assertGreaterEqual(len(slides), 5)
                self.assertLessEqual(len(slides), 8)
                for name in slides:
                    xml = ET.fromstring(deck.read(name))
                    self.assertTrue(xml.findall('.//a:t', NS), name)
                    for shape in xml.findall('p:cSld/p:spTree/*', NS):
                        xfrm = shape.find('p:spPr/a:xfrm', NS)
                        if xfrm is None:
                            continue
                        off, ext = xfrm.find('a:off', NS), xfrm.find('a:ext', NS)
                        if off is None or ext is None:
                            continue
                        x, y = int(off.attrib['x']), int(off.attrib['y'])
                        w, h = int(ext.attrib['cx']), int(ext.attrib['cy'])
                        self.assertTrue(x >= 0 and y >= 0 and x + w <= width and y + h <= height, (name, x, y, w, h))

    def test_source_archive_is_rebuildable_not_a_stale_full_manifest(self):
        with zipfile.ZipFile(DOWNLOADS / 'sealforge-editable-sources.zip') as archive:
            names = set(archive.namelist())
            self.assertIn('tools/branding/source/cove/Inter.ttf', names)
            self.assertIn('tools/branding/source/cove/Manrope.ttf', names)
            self.assertIn('branding-cove/docs/brand-guidelines.html', names)
            self.assertIn('corporate/office/sealforge-presentation.pptx', names)
            self.assertNotIn('branding-cove/manifest.json', names)
            self.assertNotIn('corporate/manifest.json', names)
            self.assertNotIn('branding-cove/docs/brand-guidelines.pdf', names)
            self.assertFalse(any(n.endswith('.png') and not n.endswith('approved-reference.png') for n in names))


if __name__ == '__main__':
    unittest.main()
