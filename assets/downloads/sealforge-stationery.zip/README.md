# SealForge office and stationery

`corporate/office/`: editable Word letterhead/report and PowerPoint presentation.
`corporate/print/`: business-card artwork and print PDFs.
`branding/docs/`: brand guide, A4 letterhead and editable HTML sources.
Local document images, fonts and corporate generation sources are also included.

Personalise the template fields; no real contact details are invented.
Install branding/raw/fonts/Inter.ttf for consistent Office editing.
Business cards are RGB, not calibrated CMYK, PDF/X or press-proof deliverables.
Read corporate/README.md for usage and native Office rendering limits.
manifest.json hashes every other file in this archive with SHA-256.
