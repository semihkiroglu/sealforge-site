# SealForge corporate identity

This package contains approved SealForge identity files. Depending on the
download, it includes logos, icons, brand guidelines, document templates,
stationery and digital materials. Turkish files are under `tr/`.

Use the brand guidelines to choose artwork and keep the identity consistent.
Install Manrope and Inter when editing Office templates; keep their SIL Open
Font License notices. Replace the placeholder fields before use.

Business-card files are RGB, not press-ready CMYK or PDF/X. Check your final
files in your document application and with your printer before publication.
The package manifest lists the SHA-256 digest of each included file.
