# SealForge office and stationery - Cove

Editable Word/PPT in corporate/office/, business cards in corporate/print/,
brand guide and A4 letterhead in branding-cove/docs/. Font files, both OFL
notices and actual local HTML image resources are included. Install Manrope
and Inter for native editing. Personalise template fields before sending.
RGB print design only, not calibrated CMYK/PDF-X or press proof. See
corporate/README.md for actual render checks. manifest.json hashes every file.
