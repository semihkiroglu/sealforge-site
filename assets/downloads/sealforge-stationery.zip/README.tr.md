# SealForge kurumsal kimliği

Bu pakette onaylı SealForge kimlik dosyaları bulunur. Seçtiğiniz pakete göre
logolar, ikonlar, marka kılavuzu, belge şablonları, basılı ve dijital materyaller
yer alır. Türkçe dosyalar `tr/` klasörlerindedir.

Çizimleri seçerken ve kimliği kullanırken marka kılavuzundan yararlanın.
Office şablonlarını düzenlemek için Manrope ve Inter yazı karakterlerini kurun;
SIL Open Font License bildirimlerini koruyun. Şablonlardaki alanları
kullanmadan önce kişiselleştirin.

Kartvizit dosyaları RGB'dir; baskıya hazır CMYK veya PDF/X değildir. Son
dosyalarınızı yayımlamadan önce belge uygulamanızda ve matbaanızla kontrol edin.
Paket manifestinde her dosyanın SHA-256 özeti bulunur.
