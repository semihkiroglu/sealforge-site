#!/usr/bin/env python3
"""Derive the static editing faces from the two canonical variable fonts.

    python fonts.py --brand-root /path/to/branding-cove --out DIR

The Office templates ask for three named families -- "Manrope SemiBold",
"Inter" and "Inter SemiBold" -- so Word and LibreOffice pick a real weight
instead of synthesising bold from a single variable file. The brand kit is
read-only; nothing here changes the canonical fonts or artwork.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont

# (source file, weight, family, postscript name)
FACES = [
    ("Manrope.ttf", 600, "Manrope SemiBold", "Manrope-SemiBold"),
    ("Inter.ttf", 400, "Inter", "Inter-Regular"),
    ("Inter.ttf", 600, "Inter SemiBold", "Inter-SemiBold"),
]
TEXT_OPSZ = 14  # text-optical Inter instance; the body/UI size range


def _rename(font: TTFont, family: str, ps_name: str) -> None:
    name = font["name"]
    values = {1: family, 2: "Regular", 3: f"{ps_name};SealForge static",
              4: family, 6: ps_name, 16: family, 17: "Regular"}
    for record in list(name.names):
        if record.nameID in values:
            record.string = values[record.nameID]


def build(brand_root: Path, out: Path) -> list[dict]:
    out.mkdir(parents=True, exist_ok=True)
    built = []
    for source, weight, family, ps_name in FACES:
        font = TTFont(brand_root / "raw/fonts" / source, recalcTimestamp=False)
        axes = {"wght": weight}
        if "opsz" in {a.axisTag for a in font["fvar"].axes}:
            axes["opsz"] = TEXT_OPSZ
        static = instantiateVariableFont(font, axes)
        _rename(static, family, ps_name)
        static["OS/2"].usWeightClass = weight
        static["OS/2"].fsSelection = (static["OS/2"].fsSelection & ~0x21) | 0x40
        static["head"].macStyle = 0
        static["post"].italicAngle = 0
        path = out / f"{ps_name}.ttf"
        static.save(path)
        built.append({"file": path.name, "family": family, "weight": weight,
                      "bytes": path.stat().st_size})
    return built


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--brand-root", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    print(json.dumps(build(args.brand_root.resolve(), args.out.resolve()), indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
