#!/usr/bin/env python3
"""Build the SealForge corporate identity extension from the canonical kit.

    python generate.py --brand-root /path/to/branding --output deliverables

The brand root is read-only. All output is written below --output; the
inventory and verification evidence are written to --report-dir.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from importlib import metadata
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from assets import build_business_card, build_email, build_social  # noqa: E402
from brand import Brand  # noqa: E402
from deck import build_deck  # noqa: E402
from office import build_letterhead, build_report  # noqa: E402
import verify  # noqa: E402


PRINT_SPEC = {
    "product": "SealForge business card",
    "trim_mm": [85, 55],
    "bleed_mm": 3,
    "artwork_page_mm": [91, 61],
    "safe_area_mm": [79, 49],
    "safe_inset_from_trim_mm": 3,
    "colour_space": "RGB (DeviceRGB)",
    "cmyk_supplied": False,
    "cmyk_note": ("No CMYK conversion, ICC output intent or commercial CMYK proof is "
                  "supplied. The printer must convert from this RGB file with its own "
                  "press/profile and provide a proof."),
    "fonts": ["Manrope SemiBold (name field)", "Inter Regular", "Inter SemiBold"],
    "font_embedding": ("The print PDF embeds subset static fonts derived from the canonical "
                       "Manrope/Inter sources. The editable SVGs keep text editable and fall back "
                       "to Arial/Helvetica if those families are absent."),
    "guide_sources": [
        "business-card-front-guides.svg",
        "business-card-back-guides.svg",
    ],
    "print_pdf": "business-card-85x55-RGB.pdf",
    "print_pdf_note": ("Two pages: front then back. 91 x 61 mm page with 3 mm bleed. "
                       "No crop marks, trim lines, safe-area lines or annotations."),
    "tokens": ["{{name}}", "{{role}}", "{{email}}", "{{phone}}", "{{website}}"],
}


def _tool(cmd: list[str]) -> str:
    if not shutil.which(cmd[0]):
        return "missing"
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
        return (result.stdout or result.stderr).strip().splitlines()[0]
    except Exception as exc:  # noqa: BLE001
        return f"error: {exc}"


def _versions() -> dict:
    def ver(name):
        try:
            return metadata.version(name)
        except metadata.PackageNotFoundError:
            return "missing"
    return {
        "python": sys.version.split()[0],
        "python-docx": ver("python-docx"),
        "python-pptx": ver("python-pptx"),
        "Pillow": ver("Pillow"),
        "pypdf": ver("pypdf"),
        "lxml": ver("lxml"),
        "libreoffice": _tool(["soffice", "--version"]),
        "rsvg-convert": _tool(["rsvg-convert", "--version"]),
        "pdftoppm": _tool(["pdftoppm", "-v"]),
    }


def _stable_zip(path: Path):
    """Normalise OOXML zip timestamps so repeated builds keep their hashes."""
    import os
    import zipfile

    tmp = path.with_suffix(path.suffix + ".stable")
    with zipfile.ZipFile(path) as zin, zipfile.ZipFile(tmp, "w") as zout:
        for item in zin.infolist():
            info = zipfile.ZipInfo(item.filename, date_time=(2026, 11, 16, 9, 0, 0))
            info.compress_type = item.compress_type
            info.external_attr = item.external_attr
            info.create_system = item.create_system
            info.flag_bits = item.flag_bits
            zout.writestr(info, zin.read(item.filename))
    os.replace(tmp, path)


def _build_fonts(brand: Brand, out: Path, work: Path, font_python: str) -> dict:
    """Derive the static editing faces and isolate their fontconfig.

    The templates name exact families, so the build must render with the same
    faces it ships. Nothing is installed system-wide: fontconfig and the
    LibreOffice profile both live under the report directory.
    """
    static = work / "static-fonts"
    result = subprocess.run([font_python, str(HERE / "fonts.py"),
                             "--brand-root", str(brand.root), "--out", str(static)],
                            capture_output=True, text=True)
    if result.returncode != 0:
        raise SystemExit("static font derivation failed; pass --font-python pointing at a "
                         f"Python with fontTools\n{result.stderr}")
    fonts = out / "fonts"
    fonts.mkdir(parents=True, exist_ok=True)
    faces = json.loads(result.stdout)
    for face in faces:
        shutil.copyfile(static / face["file"], fonts / face["file"])
    for name in ("OFL.txt", "OFL-Manrope.txt"):
        shutil.copyfile(brand.path(f"raw/fonts/{name}"), fonts / name)
    cache = work / "fc-cache"
    cache.mkdir(parents=True, exist_ok=True)
    conf = work / "fonts.conf"
    conf.write_text(
        '<?xml version="1.0"?>\n<!DOCTYPE fontconfig SYSTEM "urn:fontconfig:fonts.dtd">\n'
        "<fontconfig>\n"
        f"  <dir>{static}</dir>\n  <cachedir>{cache}</cachedir>\n"
        '  <include ignore_missing="yes">/etc/fonts/fonts.conf</include>\n</fontconfig>\n', "utf-8")
    os.environ["FONTCONFIG_FILE"] = str(conf)
    return {"faces": faces, "fontconfig": str(conf), "license_files": ["OFL.txt", "OFL-Manrope.txt"]}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--brand-root", required=True, type=Path,
                        help="canonical branding/ directory (read-only)")
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).resolve().parent.parent,
                        help="deliverables root (default: package root)")
    parser.add_argument("--report-dir", type=Path,
                        help="inventory and verification root (default: output parent)")
    parser.add_argument("--font-python", default=sys.executable,
                        help="interpreter with fontTools, used once to derive the static faces")
    args = parser.parse_args()

    out = args.output.resolve()
    report_dir = (args.report_dir or out.parent).resolve()
    brand_root = args.brand_root.resolve()
    if out == brand_root or out.is_relative_to(brand_root) or report_dir.is_relative_to(brand_root):
        parser.error('Output and report paths must not overlap the read-only brand kit')
    report_dir.mkdir(parents=True, exist_ok=True)
    (report_dir / "verification" / "renders").mkdir(parents=True, exist_ok=True)
    (report_dir / "verification" / "work").mkdir(parents=True, exist_ok=True)

    brand = Brand(args.brand_root)
    brand_checks = brand.verify()
    fonts_report = _build_fonts(brand, out, report_dir / "verification" / "work",
                                args.font_python)

    office = out / "office"
    print_dir = out / "print"
    social = out / "digital" / "social"
    email = out / "digital" / "email"
    for d in (office, print_dir, social, email):
        d.mkdir(parents=True, exist_ok=True)

    built = {
        "letterhead": build_letterhead(brand, office / "sealforge-letterhead.docx"),
        "report": build_report(brand, office / "sealforge-report-template.docx"),
        "deck": build_deck(brand, office / "sealforge-presentation.pptx"),
    }
    for key in ("letterhead", "report", "deck"):
        _stable_zip(built[key])
    built["card"] = build_business_card(brand, print_dir)
    built["social"] = build_social(brand, social)
    built["email"] = build_email(brand, email)
    (print_dir / "print-spec.json").write_text(
        json.dumps(PRINT_SPEC, indent=2, ensure_ascii=False) + "\n", "utf-8")

    # The README is part of the distributable, but its source lives with the
    # generator so a fresh build into an empty directory is complete.
    shutil.copyfile(HERE / "README.template.md", out / "README.md")

    docx_reports = {
        p.name: verify.validate_docx(p, brand)
        for p in (built["letterhead"], built["report"])
    }
    pptx_report = verify.validate_pptx(built["deck"], brand)
    card_report = verify.check_card_pdf(print_dir / "business-card-85x55-RGB.pdf",
                                        print_dir,
                                        report_dir / "verification" / "renders" / "print")
    social_report = verify.check_social(social, brand)
    email_report = verify.check_email(email, brand)
    copy_hits = verify.forbidden_copy(out)

    render = verify.render_office(office, report_dir / "verification")
    render_log = render.pop("log", [])

    checks = {
        "generated_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "toolchain": _versions(),
        "fonts": fonts_report,
        "brand": {
            "root": brand.root.name,
            "manifest_verified": all(c.get("manifest_match") for c in brand_checks),
            "assets": brand_checks,
        },
        "docx": docx_reports,
        "pptx": pptx_report,
        "print": card_report,
        "social": social_report,
        "email": email_report,
        "forbidden_copy_hits": copy_hits,
        "render": render,
        "warnings": [
            "LibreOffice render is not a Microsoft Word or PowerPoint render.",
            "The print file is RGB; no CMYK conversion, ICC output intent or commercial proof is supplied.",
            "The business-card PDF contains {{tokens}} until the template is filled.",
            "DOCX/PPTX do not embed fonts; without the supplied Manrope SemiBold/Inter faces an office application substitutes them.",
            "Deliverables are byte-stable in this environment; verification logs and inventory carry timestamps. Opening and saving in Office changes package metadata and hashes.",
        ],
    }
    failures = []
    if not all(r["ok"] for r in docx_reports.values()):
        failures.append("DOCX structural check failed")
    if not pptx_report["ok"]:
        failures.append("PPTX layout/structure check failed")
    if not card_report["ok"]:
        failures.append("Business-card PDF check failed")
    if not social_report["ok"]:
        failures.append("Social asset check failed")
    if not email_report["ok"]:
        failures.append("Email template check failed")
    if copy_hits:
        failures.append("Forbidden commercial/licence copy found")
    if not render.get("rendered", False):
        checks["warnings"].append("Native render skipped: " + ", ".join(render.get("missing", [])))
    checks["status"] = "fail" if failures else ("warn" if not render.get("rendered") else "pass")
    checks["blockers"] = failures

    vdir = report_dir / "verification"
    (vdir / "docx-readback.json").write_text(
        json.dumps(docx_reports, indent=2, ensure_ascii=False) + "\n", "utf-8")
    (vdir / "pptx-readback.json").write_text(
        json.dumps(pptx_report, indent=2, ensure_ascii=False) + "\n", "utf-8")
    (vdir / "print-check.json").write_text(
        json.dumps(card_report, indent=2, ensure_ascii=False) + "\n", "utf-8")
    (vdir / "social-check.json").write_text(
        json.dumps(social_report, indent=2, ensure_ascii=False) + "\n", "utf-8")
    (vdir / "email-check.json").write_text(
        json.dumps(email_report, indent=2, ensure_ascii=False) + "\n", "utf-8")
    (vdir / "forbidden-copy.json").write_text(
        json.dumps(copy_hits, indent=2, ensure_ascii=False) + "\n", "utf-8")
    (vdir / "checks.json").write_text(
        json.dumps(checks, indent=2, ensure_ascii=False) + "\n", "utf-8")

    log_lines = [
        f"SealForge corporate extension verification log",
        f"generated_utc: {checks['generated_utc']}",
        f"python: {sys.version.split()[0]}",
        f"libreoffice: {checks['toolchain']['libreoffice']}",
        f"rsvg-convert: {checks['toolchain']['rsvg-convert']}",
        f"pdftoppm: {checks['toolchain']['pdftoppm']}",
        "",
        "== DOCX ==",
        json.dumps({k: {"ok": v["ok"], "pages_mm": v["page_mm"],
                        "relationships_missing": v["relationship_targets_missing"],
                        "tokens": v["tokens"]} for k, v in docx_reports.items()},
                   indent=2, ensure_ascii=False),
        "",
        "== PPTX ==",
        json.dumps({"ok": pptx_report["ok"], "slide_count": pptx_report["slide_count"],
                    "slide_size_in": pptx_report["slide_size_in"],
                    "theme_fonts": pptx_report["theme_fonts"],
                    "out_of_bounds": pptx_report["out_of_bounds"],
                    "text_overflow": pptx_report["text_overflow"]},
                   indent=2, ensure_ascii=False),
        "",
        "== PRINT ==",
        json.dumps({k: card_report[k] for k in
                    ("ok", "pages", "page_sizes_pt", "cmyk_operator_hits",
                     "rgb_operator_hits", "fonts", "guide_pixels")},
                   indent=2, ensure_ascii=False),
        "",
        "== RENDER ==",
        json.dumps(render, indent=2, ensure_ascii=False),
        "",
        "== TOOL LOG ==",
        *render_log,
    ]
    (vdir / "render.log").write_text("\n".join(log_lines) + "\n", "utf-8")

    inventory = verify.write_inventory(out, report_dir / "inventory.json", checks, brand)
    with (vdir / "sha256sums.txt").open("w", encoding="utf-8") as fh:
        for entry in inventory["files"]:
            fh.write(f"{entry['sha256']}  {entry['path']}\n")

    # Keep the source tree clean for archiving; the inventory excludes caches.
    shutil.rmtree(HERE / "__pycache__", ignore_errors=True)

    print(json.dumps({
        "status": checks["status"],
        "output": str(out),
        "report_dir": str(report_dir),
        "files": inventory["file_count"],
        "docx": {k: v["ok"] for k, v in docx_reports.items()},
        "pptx": pptx_report["ok"],
        "print": card_report["ok"],
        "social": social_report["ok"],
        "email": email_report["ok"],
        "render": render.get("rendered", False),
        "blockers": failures,
    }, indent=2))
    return 0 if checks["status"] != "fail" else 1


if __name__ == "__main__":
    raise SystemExit(main())
